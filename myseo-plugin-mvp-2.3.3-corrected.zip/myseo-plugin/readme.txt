=== MySEO ===
Contributors: myseo
Tags: seo, metadata, search
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 2.0.0
License: GPLv2 or later

A lightweight SEO plugin MVP foundation.

== MVP features in this starter ==
* Custom SEO title field for public post types.
* Custom meta description field.
* One focus keyphrase field and up to five optional related keyphrases.
* Custom SEO title output through WordPress document title filtering.
* Meta description output in the document head, with excerpt fallback.
* Basic plugin settings page.
* Live focus keyphrase checks for title, description, slug, introduction, headings, and article body.
* Live readability checks for sentence length, paragraph length, likely passive voice, transition words, and repeated sentence openings.
* Heading structure analysis for missing/multiple H1, empty headings, skipped heading levels, and a heading outline.
* Image SEO analysis for missing alt attributes and empty alt values, with Media Library edit links when an attachment ID is available.
* Basic JSON-LD structured data: BlogPosting for standard posts and WebPage for other singular public content.
* Structured data output setting and duplicate-output avoidance when selected SEO plugins are active.
* React-powered WordPress admin dashboard with overview metrics, navigation, and settings management via authenticated REST API.
* Paginated Content Audit for published public content: missing custom SEO titles, meta descriptions, focus keyphrases, and duplicate custom titles/descriptions.

== Dashboard ==
The MySEO dashboard provides an overview of published content, configured SEO titles and meta descriptions, schema status, and settings. Content Audit is implemented with paginated results. Content Health and SEO Performance remain roadmap placeholders. Image and Technical SEO audits scan saved content in paginated post batches.

== Installation ==
1. Upload the myseo-plugin folder to /wp-content/plugins/.
2. Activate MySEO from the WordPress Plugins screen.
3. Edit a post or page and find the “MySEO – Search appearance” panel.
4. Enter an SEO title, meta description, and focus keyphrase.

== Important compatibility note ==
If another SEO plugin or theme is already generating title and description metadata, duplicate output may occur. For this first starter, test on a staging site with other SEO plugins disabled. Compatibility detection and output arbitration are planned before a production release.

== Version 1.0.1 ==
* Fixed Image Audit handling of image source attributes to prevent an array-to-string fatal error.
* Added defensive handling for unexpected or missing image source values.
* Updated dashboard descriptions to reflect implemented Content, Image and Technical SEO audits.

== Version 2.0.0 ==
* Added up to five related keyphrases per post/page, saved as post metadata.
* Added live related-keyphrase checks in the editor analysis panel.
* Expanded the transparent SEO checklist with optional related phrase coverage and a cautious phrase-frequency review signal.
* Improved internal-link suggestion relevance using exact phrase matches, title weighting, meaningful token filtering and term coverage.
* Scoring remains an editorial heuristic, not a search-engine ranking score or target keyword-density recommendation.

== Version 1.9.2 ==
* Fixed static homepage metadata resolution using the page selected in WordPress Reading Settings.
* Homepage page-level SEO title and description now take priority over homepage fallback settings.
* Homepage social title and description now honor the selected page's social and SEO metadata before global defaults.
* Homepage social image now checks the selected page's social image and featured image before the global social image.
* Document title and meta description output now use the configured static front-page page as a metadata source.

== Version 1.9.1 ==
* Fixed Settings REST response to return all global settings fields.
* Fixed settings update defaults handling and restored default template values when blank.
* Corrected social metadata priority: per-content social values, then per-content SEO values, then global social defaults, then generic fallbacks.
* Retained homepage-specific social metadata priority.

== Version 1.9.0 ==
* Added global SEO title and meta description fallback templates with supported tokens.
* Added homepage SEO title and description settings.
* Added default social title, description and image settings.
* Expanded REST settings endpoint and dashboard Settings UI.
* Added homepage meta description and social metadata output.
* Per-content SEO and social overrides retain priority according to documented fallback order.

== Version 1.8.0 ==
* Added social image fit controls: Cover and Contain.
* Added image position controls: Center, Top, Bottom, Left and Right.
* Added accessible state updates for fit controls.
* Preview-only controls do not modify the saved social image URL or generated social metadata.

== Version 1.7.1 ==
* Added selectable compact Facebook/LinkedIn-style and large-image social card previews.
* Added accessible pressed-state updates for social preview layout controls.
* Retained the existing compact preview as the default.

== Version 1.7.0 ==
* Added a live Google-style search appearance preview in the post editor.
* Added desktop and mobile preview modes.
* Added live character counts and estimated title/description pixel widths.
* Added a social sharing card preview that updates from social metadata and image fields.
* Clearly labels previews and pixel widths as estimates; actual search/social platform displays may differ.

== Version 1.6.0 ==
* Added per-post social sharing title, description and image overrides.
* Added WordPress Media Library image selection and preview in the post editor.
* Outputs Open Graph metadata for compatible social sharing platforms.
* Outputs Twitter/X summary or summary_large_image card metadata.
* Falls back to MySEO SEO title/description and the WordPress featured image.
* Suppresses MySEO social tags when selected supported SEO plugins are detected to reduce duplicate metadata.

== Version 1.5.0 ==
* Implemented the Content Health dashboard with freshness, short-content and featured-image review signals.
* Scans up to 500 published public content items and lists up to 100 review candidates.
* Adds authenticated REST endpoint `/wp-json/myseo/v1/content-health`.
* Clearly labels thresholds as editorial heuristics, not ranking factors.

== Version 1.4.0 ==
* Improved internal-link recommendations with suggested anchor text drawn from the source article context.
* Explains why each destination is recommended using matched terms.
* Detects links already present in the source content and disables duplicate insertion.
* Existing destination links are listed as Already linked rather than recommended for another insertion.

== Version 1.3.1 ==
* Fixed a JavaScript ReferenceError in the Technical SEO dashboard that prevented the screen from rendering.
* The site-wide internal link structure panel now reads from the component's REST response state safely.

== Version 1.3.0 ==
* Added a site-wide internal link structure report to Technical SEO.
* Reports published posts with no incoming internal links (orphaned-content candidates).
* Reports published posts with no outgoing internal links.
* Shows incoming/outgoing counts and edit links for reviewed content.
* Limits the topology scan to 1,000 published content items and reports when the scan is partial.
* Counts only saved-content links that resolve to another scanned published WordPress item; navigation, widgets, theme output, archives and dynamically injected links are not included.

== Version 1.2.0 ==
* Added related internal-link suggestions in the post editor using published WordPress content.
* Suggestions use the current focus keyphrase, exclude the current post and show matching terms and excerpts.
* Editors can insert a suggested link as a paragraph block or copy its URL.
* Suggestions are read-only and require permission to edit the source post.

== Version 1.1.0 ==
* Added a live editor-side Content SEO Checklist Score based on ten transparent editorial checks.
* Score updates while editing the focus keyphrase, SEO title, meta description, slug, article content, headings and image alt text.
* Clearly labels the score as an editorial checklist, not a Google score or ranking prediction.

== Version 1.0.2 ==
* Improved sitemap auditing by checking the sitemap endpoint, XML structure and one child sitemap when available.
* Improved canonical auditing by inspecting the rendered HTML of one published content item for missing, duplicate or mismatched canonical tags.
* Local development hostnames now receive a review notice rather than a production HTTPS action warning.

== Development status ==
This is an early MVP foundation, not a finished SEO product. Gutenberg sidebar UI, advanced schema types, and automated tests are not included yet.
