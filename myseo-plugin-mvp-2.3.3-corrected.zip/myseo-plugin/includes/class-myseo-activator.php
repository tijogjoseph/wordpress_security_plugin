<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Activator
{
    public static function activate(): void
    {
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            deactivate_plugins(plugin_basename(MYSEO_FILE));
            wp_die(
                esc_html__('MySEO requires PHP 8.0 or newer.', 'myseo'),
                esc_html__('Plugin activation error', 'myseo'),
                ['back_link' => true]
            );
        }

        if (get_option('myseo_settings', false) === false) {
            add_option('myseo_settings', [
                'enable_meta_output' => 1,
                'enable_schema_output' => 1,
            ]);
        }

        add_option('myseo_version', MYSEO_VERSION);
    }
}
