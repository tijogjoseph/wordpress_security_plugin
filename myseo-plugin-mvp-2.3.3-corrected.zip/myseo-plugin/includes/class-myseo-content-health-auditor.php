<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Editorial content-health checks based on saved published content.
 *
 * These are review signals, not ranking factors or proof that a page is poor.
 */
final class MySEO_Content_Health_Auditor
{
    public function audit(): array
    {
        $post_types = array_values(array_diff(get_post_types(['public' => true], 'names'), ['attachment']));
        $limit = 500;
        $query = new WP_Query([
            'post_type' => $post_types ?: 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'paged' => 1,
            'orderby' => 'modified',
            'order' => 'ASC',
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        $now = current_time('timestamp', true);
        $items = [];
        $summary = [
            'posts_analyzed' => 0,
            'stale_content' => 0,
            'thin_content' => 0,
            'missing_featured_image' => 0,
            'posts_with_issues' => 0,
        ];

        foreach ($query->posts as $post) {
            $summary['posts_analyzed']++;
            $content = strip_shortcodes((string) $post->post_content);
            $plain = wp_strip_all_tags($content);
            $plain = html_entity_decode($plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $word_count = preg_match_all('/[\p{L}\p{N}]+/u', $plain, $matches);
            if ($word_count === false) {
                $word_count = str_word_count($plain);
            }

            $modified = $post->post_modified_gmt && $post->post_modified_gmt !== '0000-00-00 00:00:00'
                ? strtotime($post->post_modified_gmt . ' UTC')
                : strtotime($post->post_date_gmt . ' UTC');
            $age_days = $modified ? max(0, (int) floor(($now - $modified) / DAY_IN_SECONDS)) : 0;

            $flags = [];
            if ($age_days >= 365) {
                $flags[] = 'stale';
                $summary['stale_content']++;
            }
            if ($word_count < 300) {
                $flags[] = 'thin';
                $summary['thin_content']++;
            }
            if (!has_post_thumbnail($post->ID)) {
                $flags[] = 'no_featured_image';
                $summary['missing_featured_image']++;
            }
            if ($flags) {
                $summary['posts_with_issues']++;
                $items[] = [
                    'id' => (int) $post->ID,
                    'title' => get_the_title($post) ?: '(Untitled)',
                    'type' => (string) $post->post_type,
                    'word_count' => (int) $word_count,
                    'age_days' => $age_days,
                    'modified' => get_post_modified_time('Y-m-d', true, $post),
                    'flags' => $flags,
                    'edit_url' => get_edit_post_link($post->ID, 'raw'),
                ];
            }
        }

        usort($items, static function ($a, $b) {
            $score_a = count($a['flags']);
            $score_b = count($b['flags']);
            if ($score_a !== $score_b) {
                return $score_b <=> $score_a;
            }
            return $b['age_days'] <=> $a['age_days'];
        });

        return [
            'summary' => $summary,
            'items' => array_slice($items, 0, 100),
            'post_limit' => $limit,
            'analysis_limited' => (int) $query->found_posts > $limit,
            'thresholds' => [
                'stale_after_days' => 365,
                'thin_content_below_words' => 300,
            ],
        ];
    }
}
