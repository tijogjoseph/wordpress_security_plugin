<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Analyzes heading structure in post content.
 *
 * Checks the content's own H1-H6 elements. Theme-generated page titles are
 * outside post_content and are intentionally not counted by this analyzer.
 */
final class MySEO_Heading_Analyzer
{
    /**
     * @return array<string, mixed>
     */
    public function analyze(string $content): array
    {
        $headings = $this->extract_headings($content);
        $counts = array_fill_keys(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], 0);

        foreach ($headings as $heading) {
            $counts[$heading['level']]++;
        }

        $issues = [];
        if ($counts['h1'] === 0) {
            $issues[] = [
                'code' => 'missing_h1',
                'severity' => 'warning',
                'message' => 'No H1 heading was found inside the article content. Check whether your theme already outputs the post title as the page H1.',
            ];
        } elseif ($counts['h1'] > 1) {
            $issues[] = [
                'code' => 'multiple_h1',
                'severity' => 'notice',
                'message' => sprintf('Found %d H1 headings in the article content. Review whether one clear main heading would be more appropriate.', $counts['h1']),
            ];
        }

        foreach ($headings as $index => $heading) {
            if ($heading['text'] === '') {
                $issues[] = [
                    'code' => 'empty_heading',
                    'severity' => 'warning',
                    'message' => sprintf('Heading %d (H%d) is empty.', $index + 1, $heading['level_number']),
                ];
            }

            if ($index > 0) {
                $previous = $headings[$index - 1]['level_number'];
                $current = $heading['level_number'];

                if ($current > $previous + 1) {
                    $issues[] = [
                        'code' => 'skipped_level',
                        'severity' => 'notice',
                        'message' => sprintf(
                            'Heading hierarchy jumps from H%d to H%d%s.',
                            $previous,
                            $current,
                            $heading['text'] !== '' ? ' before “' . $heading['text'] . '”' : ''
                        ),
                    ];
                }
            }
        }

        return [
            'counts' => $counts,
            'total' => count($headings),
            'headings' => $headings,
            'issues' => $issues,
            'status' => empty($issues) ? 'good' : 'needs_review',
        ];
    }

    /**
     * @return array<int, array{level:string,level_number:int,text:string}>
     */
    private function extract_headings(string $content): array
    {
        $content = strip_shortcodes($content);
        $content = preg_replace('/<!--.*?-->/s', ' ', $content) ?? $content;

        if (!class_exists('DOMDocument')) {
            return $this->extract_headings_fallback($content);
        }

        $headings = [];
        $previous = libxml_use_internal_errors(true);
        $dom = new DOMDocument();

        $loaded = $dom->loadHTML(
            '<?xml encoding="utf-8" ?><div>' . $content . '</div>',
            LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING
        );

        if ($loaded) {
            foreach ($dom->getElementsByTagName('*') as $node) {
                if (!preg_match('/^h([1-6])$/i', $node->nodeName, $match)) {
                    continue;
                }

                $level = (int) $match[1];
                $text = trim(preg_replace('/\s+/u', ' ', $node->textContent) ?? $node->textContent);

                $headings[] = [
                    'level' => 'h' . $level,
                    'level_number' => $level,
                    'text' => sanitize_text_field($text),
                ];
            }
        }

        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        return $headings;
    }

    /**
     * Conservative fallback for hosts without PHP DOM extension.
     */
    private function extract_headings_fallback(string $content): array
    {
        $headings = [];
        if (preg_match_all('/<h([1-6])\b[^>]*>(.*?)<\/h\1\s*>/is', $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $level = (int) $match[1];
                $text = trim(wp_strip_all_tags($match[2]));
                $headings[] = [
                    'level' => 'h' . $level,
                    'level_number' => $level,
                    'text' => sanitize_text_field($text),
                ];
            }
        }
        return $headings;
    }
}
