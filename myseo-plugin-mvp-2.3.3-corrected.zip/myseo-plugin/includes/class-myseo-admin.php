<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Admin
{
    public function register_hooks(): void
    {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_dashboard_assets']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    public function register_menu(): void
    {
        add_menu_page(
            __('MySEO', 'myseo'),
            __('MySEO', 'myseo'),
            'manage_options',
            'myseo',
            [$this, 'render_dashboard'],
            'dashicons-search',
            58
        );
    }

    public function register_settings(): void
    {
        register_setting('myseo_settings_group', 'myseo_settings', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => ['enable_meta_output' => 1, 'enable_schema_output' => 1],
        ]);
    }

    public function sanitize_settings($input): array
    {
        $input = is_array($input) ? $input : [];
        return [
            'enable_meta_output' => !empty($input['enable_meta_output']) ? 1 : 0,
            'enable_schema_output' => !empty($input['enable_schema_output']) ? 1 : 0,
            'title_template' => (trim(sanitize_text_field($input['title_template'] ?? '')) !== '')
                ? sanitize_text_field($input['title_template'])
                : '{title} | {site_name}',
            'description_template' => (trim(sanitize_textarea_field($input['description_template'] ?? '')) !== '')
                ? sanitize_textarea_field($input['description_template'])
                : '{excerpt}',
            'homepage_title' => sanitize_text_field($input['homepage_title'] ?? ''),
            'homepage_description' => sanitize_textarea_field($input['homepage_description'] ?? ''),
            'social_default_title' => sanitize_text_field($input['social_default_title'] ?? ''),
            'social_default_description' => sanitize_textarea_field($input['social_default_description'] ?? ''),
            'social_default_image' => esc_url_raw($input['social_default_image'] ?? ''),
        ];
    }

    public function enqueue_dashboard_assets(string $hook): void
    {
        if ($hook !== 'toplevel_page_myseo') {
            return;
        }

        wp_enqueue_script(
            'myseo-dashboard',
            MYSEO_URL . 'assets/js/myseo-dashboard.js',
            ['wp-element', 'wp-api-fetch'],
            MYSEO_VERSION,
            true
        );
        wp_enqueue_style('myseo-dashboard', MYSEO_URL . 'assets/css/myseo-dashboard.css', [], MYSEO_VERSION);
        wp_localize_script('myseo-dashboard', 'myseoDashboardConfig', [
            'apiRoot' => esc_url_raw(rest_url('myseo/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
            'version' => MYSEO_VERSION,
        ]);
    }

    public function register_rest_routes(): void
    {
        register_rest_route('myseo/v1', '/pro-crawler', [
            [ 'methods' => WP_REST_Server::READABLE, 'callback' => [$this, 'get_crawler_results'], 'permission_callback' => [$this, 'can_manage_myseo'] ],
            [ 'methods' => WP_REST_Server::CREATABLE, 'callback' => [$this, 'run_crawler'], 'permission_callback' => [$this, 'can_manage_myseo'] ],
        ]);

        register_rest_route('myseo/v1', '/dashboard', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_dashboard_data'],
            'permission_callback' => [$this, 'can_manage_myseo'],
        ]);

        register_rest_route('myseo/v1', '/technical-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_technical_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/image-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_image_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/link-suggestions', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_link_suggestions'],
            'permission_callback' => [$this, 'can_edit_suggestion_source'],
            'args' => [
                'post_id' => ['required' => true, 'sanitize_callback' => 'absint'],
                'keyphrase' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/content-health', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_content_health'],
            'permission_callback' => [$this, 'can_manage_myseo'],
        ]);

        register_rest_route('myseo/v1', '/content-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_content_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/settings', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_settings'],
                'permission_callback' => [$this, 'can_manage_myseo'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_settings'],
                'permission_callback' => [$this, 'can_manage_myseo'],
                'args' => [
                    'enable_meta_output' => ['type' => 'boolean', 'required' => true],
                    'enable_schema_output' => ['type' => 'boolean', 'required' => true],
                    'title_template' => ['type' => 'string', 'required' => false],
                    'description_template' => ['type' => 'string', 'required' => false],
                    'homepage_title' => ['type' => 'string', 'required' => false],
                    'homepage_description' => ['type' => 'string', 'required' => false],
                    'social_default_title' => ['type' => 'string', 'required' => false],
                    'social_default_description' => ['type' => 'string', 'required' => false],
                    'social_default_image' => ['type' => 'string', 'required' => false],
                ],
            ],
        ]);
    }

    public function get_crawler_results(): WP_REST_Response
    {
        $data = get_option('myseo_last_crawl', false);
        return new WP_REST_Response($data ?: ['summary'=>null,'results'=>[]]);
    }

    public function run_crawler(WP_REST_Request $request): WP_REST_Response
    {
        $crawler = new MySEO_Pro_Crawler();
        return new WP_REST_Response($crawler->crawl(20));
    }

    public function get_technical_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Technical_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function get_image_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Site_Image_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function get_content_health(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Content_Health_Auditor();
        return new WP_REST_Response($auditor->audit());
    }

    public function get_content_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Content_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function can_edit_suggestion_source(WP_REST_Request $request): bool
    {
        $post_id = absint($request->get_param('post_id'));
        return $post_id > 0 && current_user_can('edit_post', $post_id);
    }

    public function get_link_suggestions(WP_REST_Request $request): WP_REST_Response
    {
        $post_id = absint($request->get_param('post_id'));
        $keyphrase = sanitize_text_field((string) $request->get_param('keyphrase'));
        $source = get_post($post_id);

        if (!$source || !current_user_can('edit_post', $post_id)) {
            return new WP_REST_Response(['message' => __('You cannot edit this content.', 'myseo')], 403);
        }

        $source_content = (string) $source->post_content;
        $source_text = wp_strip_all_tags(strip_shortcodes($source_content));
        $terms = preg_split('/\s+/', trim($keyphrase), -1, PREG_SPLIT_NO_EMPTY);
        if (!$terms) {
            $terms = preg_split('/\s+/', wp_strip_all_tags(get_the_title($source)), -1, PREG_SPLIT_NO_EMPTY);
        }
        $stop_words = ['a','an','and','are','as','at','be','by','for','from','in','is','it','of','on','or','the','to','with'];
        $terms = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $terms), static function ($term) use ($stop_words) {
            $term = trim((string) $term);
            $length = function_exists('mb_strlen') ? mb_strlen($term) : strlen($term);
            return $length > 2 && !in_array(strtolower($term), $stop_words, true);
        })));
        if (!$terms) {
            return new WP_REST_Response(['items' => [], 'message' => __('Add a focus keyphrase to find related content.', 'myseo')]);
        }

        // Resolve existing links from the source content so duplicate suggestions can be suppressed.
        $already_linked_ids = [];
        if (preg_match_all('/<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $source_content, $link_matches, PREG_SET_ORDER)) {
            foreach ($link_matches as $link_match) {
                $href = html_entity_decode(
                    $link_match[1] !== '' ? $link_match[1] : ($link_match[2] !== '' ? $link_match[2] : ($link_match[3] ?? '')),
                    ENT_QUOTES | ENT_HTML5,
                    'UTF-8'
                );
                $target_id = url_to_postid($href);
                if ($target_id && $target_id !== $post_id) {
                    $already_linked_ids[$target_id] = true;
                }
            }
        }

        $public_types = array_values(array_diff(get_post_types(['public' => true], 'names'), ['attachment']));
        $query = new WP_Query([
            'post_type' => $public_types,
            'post_status' => 'publish',
            'posts_per_page' => 50,
            'post__not_in' => [$post_id],
            's' => $keyphrase !== '' ? $keyphrase : implode(' ', $terms),
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        if (!$query->posts && count($terms) > 1) {
            $query = new WP_Query([
                'post_type' => $public_types,
                'post_status' => 'publish',
                'posts_per_page' => 50,
                'post__not_in' => [$post_id],
                's' => implode(' ', array_slice($terms, 0, 3)),
                'orderby' => 'date',
                'order' => 'DESC',
                'no_found_rows' => true,
                'ignore_sticky_posts' => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]);
        }

        $source_lower = function_exists('mb_strtolower') ? mb_strtolower($source_text) : strtolower($source_text);
        $items = [];
        foreach ($query->posts as $candidate) {
            $title = get_the_title($candidate);
            $content = wp_strip_all_tags(strip_shortcodes((string) $candidate->post_content));
            $candidate_haystack = function_exists('mb_strtolower') ? mb_strtolower($title . ' ' . $content) : strtolower($title . ' ' . $content);
            $candidate_title = function_exists('mb_strtolower') ? mb_strtolower($title) : strtolower($title);
            $score = 0;
            $matched = [];
            $matched_title_terms = 0;

            foreach ($terms as $term) {
                $needle = function_exists('mb_strtolower') ? mb_strtolower($term) : strtolower($term);
                if ($needle !== '' && strpos($candidate_haystack, $needle) !== false) {
                    if (strpos($candidate_title, $needle) !== false) {
                        $score += 4;
                        $matched_title_terms++;
                    } else {
                        $score += 1;
                    }
                    $matched[] = $term;
                }
            }

            $normalized_keyphrase = function_exists('mb_strtolower') ? mb_strtolower(trim($keyphrase)) : strtolower(trim($keyphrase));
            $exact_phrase_match = $normalized_keyphrase !== '' && strpos($candidate_haystack, $normalized_keyphrase) !== false;
            if ($exact_phrase_match) {
                $score += 5;
            }
            $coverage = count($terms) > 0 ? count($matched) / count($terms) : 0;
            $score += (int) round($coverage * 3);

            if ($score === 0 || !$matched) {
                continue;
            }

            // Prefer anchor phrases that already occur in the source article.
            $anchor_text = '';
            if ($keyphrase !== '' && strpos($source_lower, function_exists('mb_strtolower') ? mb_strtolower($keyphrase) : strtolower($keyphrase)) !== false) {
                $anchor_text = $keyphrase;
            } elseif (stripos($source_text, $title) !== false) {
                $anchor_text = $title;
            } elseif (!empty($matched)) {
                $anchor_text = implode(' ', array_slice($matched, 0, 4));
            }
            if ($anchor_text === '') {
                $anchor_text = $title;
            }

            $excerpt = has_excerpt($candidate)
                ? get_the_excerpt($candidate)
                : wp_trim_words($content, 24, '…');

            $items[] = [
                'id' => (int) $candidate->ID,
                'title' => $title,
                'url' => get_permalink($candidate),
                'type' => get_post_type_object($candidate->post_type)->labels->singular_name ?? $candidate->post_type,
                'excerpt' => wp_strip_all_tags($excerpt),
                'relevance' => min(100, (int) round(($score / max(1, count($terms) * 4 + 8)) * 100)),
                'matched_terms' => $matched,
                'anchor_text' => $anchor_text,
                'reason' => sprintf(
                    /* translators: %s: matched keyphrase terms */
                    __('Related because destination title/content match these terms: %s', 'myseo'),
                    implode(', ', $matched)
                ),
                'already_linked' => isset($already_linked_ids[(int) $candidate->ID]),
            ];
        }

        usort($items, static function ($a, $b) {
            if ($a['already_linked'] !== $b['already_linked']) {
                return $a['already_linked'] <=> $b['already_linked'];
            }
            return $b['relevance'] <=> $a['relevance'];
        });

        return new WP_REST_Response([
            'items' => array_slice($items, 0, 8),
            'message' => $items ? '' : __('No related published content was found. Try a broader focus keyphrase or publish more related posts.', 'myseo'),
        ]);
    }

    public function can_manage_myseo(): bool
    {
        return current_user_can('manage_options');
    }

    public function get_dashboard_data(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $post_counts = wp_count_posts('post');
        $page_counts = wp_count_posts('page');
        $published_posts = isset($post_counts->publish) ? (int) $post_counts->publish : 0;
        $published_pages = isset($page_counts->publish) ? (int) $page_counts->publish : 0;

        $public_types = get_post_types(['public' => true], 'names');
        $placeholders = implode(',', array_fill(0, count($public_types), '%s'));
        $title_count = 0;
        $description_count = 0;

        if ($public_types) {
            $title_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                WHERE p.post_status = 'publish' AND p.post_type IN ($placeholders)
                AND pm.meta_key = %s AND pm.meta_value <> ''";
            $title_args = array_merge(array_values($public_types), [MySEO_Meta_Manager::META_TITLE]);
            $title_count = (int) $wpdb->get_var($wpdb->prepare($title_sql, $title_args));

            $description_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                WHERE p.post_status = 'publish' AND p.post_type IN ($placeholders)
                AND pm.meta_key = %s AND pm.meta_value <> ''";
            $description_args = array_merge(array_values($public_types), [MySEO_Meta_Manager::META_DESCRIPTION]);
            $description_count = (int) $wpdb->get_var($wpdb->prepare($description_sql, $description_args));
        }

        $settings = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
            'title_template' => '{title} | {site_name}',
            'description_template' => '{excerpt}',
            'homepage_title' => '',
            'homepage_description' => '',
            'social_default_title' => '',
            'social_default_description' => '',
            'social_default_image' => '',
        ]);

        return new WP_REST_Response([
            'published_posts' => $published_posts,
            'published_pages' => $published_pages,
            'published_content' => $published_posts + $published_pages,
            'seo_titles_configured' => $title_count,
            'meta_descriptions_configured' => $description_count,
            'meta_output_enabled' => !empty($settings['enable_meta_output']),
            'schema_output_enabled' => !empty($settings['enable_schema_output']),
            'schema_plugin_conflict' => $this->has_known_seo_plugin_active(),
            'version' => MYSEO_VERSION,
        ]);
    }

    public function get_settings(WP_REST_Request $request): WP_REST_Response
    {
        $settings = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
            'title_template' => '{title} | {site_name}',
            'description_template' => '{excerpt}',
            'homepage_title' => '',
            'homepage_description' => '',
            'social_default_title' => '',
            'social_default_description' => '',
            'social_default_image' => '',
        ]);
        if (trim((string) $settings['title_template']) === '') {
            $settings['title_template'] = '{title} | {site_name}';
        }
        if (trim((string) $settings['description_template']) === '') {
            $settings['description_template'] = '{excerpt}';
        }
        return new WP_REST_Response([
            'enable_meta_output' => (bool) $settings['enable_meta_output'],
            'enable_schema_output' => (bool) $settings['enable_schema_output'],
            'title_template' => (string) $settings['title_template'],
            'description_template' => (string) $settings['description_template'],
            'homepage_title' => (string) $settings['homepage_title'],
            'homepage_description' => (string) $settings['homepage_description'],
            'social_default_title' => (string) $settings['social_default_title'],
            'social_default_description' => (string) $settings['social_default_description'],
            'social_default_image' => (string) $settings['social_default_image'],
        ]);
    }

    public function update_settings(WP_REST_Request $request): WP_REST_Response
    {
        $existing = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
            'title_template' => '{title} | {site_name}',
            'description_template' => '{excerpt}',
            'homepage_title' => '',
            'homepage_description' => '',
            'social_default_title' => '',
            'social_default_description' => '',
            'social_default_image' => '',
        ]);
        $input = $request->get_params();
        $settings = $this->sanitize_settings(array_merge($existing, $input));
        update_option('myseo_settings', $settings);
        $settings['enable_meta_output'] = (bool) $settings['enable_meta_output'];
        $settings['enable_schema_output'] = (bool) $settings['enable_schema_output'];
        return new WP_REST_Response(array_merge(['saved' => true], $settings));
    }

    private function has_known_seo_plugin_active(): bool
    {
        $known = [
            'wordpress-seo/wp-seo.php',
            'seo-by-rank-math/rank-math.php',
            'all-in-one-seo-pack/all_in_one_seo_pack.php',
            'wp-seopress/seopress.php',
            'slim-seo/slim-seo.php',
        ];
        $active = (array) get_option('active_plugins', []);
        if (is_multisite()) {
            $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', [])));
        }
        return (bool) array_intersect($known, $active);
    }

    public function render_dashboard(): void
    {
        if (!$this->can_manage_myseo()) {
            wp_die(esc_html__('You do not have permission to access MySEO.', 'myseo'));
        }
        ?>
        <div class="wrap myseo-dashboard-wrap">
            <div id="myseo-dashboard-root">
                <div class="myseo-loading">
                    <span class="spinner is-active"></span>
                    <p><?php esc_html_e('Loading MySEO dashboard…', 'myseo'); ?></p>
                </div>
            </div>
            <noscript><?php esc_html_e('MySEO dashboard requires JavaScript to be enabled.', 'myseo'); ?></noscript>
        </div>
        <?php
    }
}
