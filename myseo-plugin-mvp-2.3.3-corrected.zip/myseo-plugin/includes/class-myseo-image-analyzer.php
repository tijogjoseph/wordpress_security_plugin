<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Inspects image elements stored in a post's editor content.
 * Images injected by themes, shortcodes, or dynamic blocks are outside this MVP scan.
 */
final class MySEO_Image_Analyzer
{
    public function analyze(int $post_id): array
    {
        $post = get_post($post_id);
        if (!$post instanceof WP_Post) {
            return ['total' => 0, 'missing_alt' => 0, 'empty_alt' => 0, 'images' => []];
        }

        $images = $this->extract_images((string) $post->post_content);
        $missing = 0;
        $empty = 0;

        foreach ($images as &$image) {
            if (!$image['has_alt']) {
                $image['status'] = 'missing_alt';
                $missing++;
            } elseif ($image['alt'] === '') {
                $image['status'] = 'empty_alt';
                $empty++;
            } else {
                $image['status'] = 'good';
            }
        }
        unset($image);

        return [
            'total' => count($images),
            'missing_alt' => $missing,
            'empty_alt' => $empty,
            'images' => $images,
        ];
    }

    private function extract_images(string $html): array
    {
        $images = [];

        if (class_exists('DOMDocument')) {
            $previous = libxml_use_internal_errors(true);
            $dom = new DOMDocument();
            $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
            libxml_clear_errors();
            libxml_use_internal_errors($previous);

            if ($loaded) {
                foreach ($dom->getElementsByTagName('img') as $node) {
                    $src = (string) $node->getAttribute('src');
                    $has_alt = $node->hasAttribute('alt');
                    $images[] = $this->make_image(
                        $src,
                        $has_alt,
                        $has_alt ? (string) $node->getAttribute('alt') : '',
                        (string) $node->getAttribute('class'),
                        (string) $node->getAttribute('data-id')
                    );
                }
                return $images;
            }
        }

        if (preg_match_all('/<img\b[^>]*>/i', $html, $matches)) {
            foreach ($matches[0] as $tag) {
                $attrs = [];
                preg_match_all('/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/u', $tag, $attribute_matches, PREG_SET_ORDER);
                foreach ($attribute_matches as $match) {
                    $value = $match[2] !== '' ? $match[2] : ($match[3] !== '' ? $match[3] : ($match[4] ?? ''));
                    $attrs[strtolower($match[1])] = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                }
                $images[] = $this->make_image(
                    $attrs['src'] ?? '',
                    array_key_exists('alt', $attrs),
                    $attrs['alt'] ?? '',
                    $attrs['class'] ?? '',
                    $attrs['data-id'] ?? ''
                );
            }
        }

        return $images;
    }

    private function make_image(string $src, bool $has_alt, string $alt, string $class, string $data_id): array
    {
        $attachment_id = 0;
        if (preg_match('/\bwp-image-(\d+)\b/', $class, $match)) {
            $attachment_id = (int) $match[1];
        } elseif (ctype_digit($data_id)) {
            $attachment_id = (int) $data_id;
        }

        $path = (string) wp_parse_url($src, PHP_URL_PATH);
        $filename = $path !== '' ? basename($path) : __('Image without a filename', 'myseo');

        return [
            'src' => $src,
            'filename' => sanitize_text_field(rawurldecode($filename)),
            'has_alt' => $has_alt,
            'alt' => sanitize_text_field($alt),
            'attachment_id' => $attachment_id,
            'status' => 'good',
        ];
    }
}
