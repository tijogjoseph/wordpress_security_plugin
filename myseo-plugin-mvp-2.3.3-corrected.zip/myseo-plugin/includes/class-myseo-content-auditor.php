<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paginated audit of published public content metadata.
 * This checks saved MySEO fields; WordPress title/excerpt fallbacks may still
 * produce frontend metadata when custom fields are blank.
 */
final class MySEO_Content_Auditor
{
    public function audit(int $page = 1, int $per_page = 20, string $search = ''): array
    {
        global $wpdb;

        $page = max(1, $page);
        $per_page = min(50, max(1, $per_page));
        $post_types = array_values(get_post_types(['public' => true], 'names'));

        if (!$post_types) {
            return $this->empty_result($page, $per_page);
        }

        $type_placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        $base_sql = "FROM {$wpdb->posts} p WHERE p.post_status = 'publish' AND p.post_type IN ($type_placeholders)";
        $base_args = $post_types;

        $total_sql = "SELECT COUNT(*) $base_sql";
        $total = (int) $wpdb->get_var($wpdb->prepare($total_sql, $base_args));

        $missing_title = $this->count_missing_meta(MySEO_Meta_Manager::META_TITLE, $post_types);
        $missing_description = $this->count_missing_meta(MySEO_Meta_Manager::META_DESCRIPTION, $post_types);
        $missing_keyphrase = $this->count_missing_meta(MySEO_Meta_Manager::META_KEYPHRASE, $post_types);

        $duplicate_titles = $this->get_duplicate_values(MySEO_Meta_Manager::META_TITLE, $post_types);
        $duplicate_descriptions = $this->get_duplicate_values(MySEO_Meta_Manager::META_DESCRIPTION, $post_types);

        $args = [
            'post_type' => $post_types,
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'orderby' => 'date',
            'order' => 'DESC',
            's' => $search,
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
        ];
        $query = new WP_Query($args);
        $items = [];

        foreach ($query->posts as $post) {
            $seo_title = trim((string) get_post_meta($post->ID, MySEO_Meta_Manager::META_TITLE, true));
            $description = trim((string) get_post_meta($post->ID, MySEO_Meta_Manager::META_DESCRIPTION, true));
            $keyphrase = trim((string) get_post_meta($post->ID, MySEO_Meta_Manager::META_KEYPHRASE, true));

            $issues = [];
            if ($seo_title === '') {
                $issues[] = 'missing_seo_title';
            }
            if ($description === '') {
                $issues[] = 'missing_meta_description';
            }
            if ($keyphrase === '') {
                $issues[] = 'missing_focus_keyphrase';
            }
            if ($seo_title !== '' && isset($duplicate_titles[$seo_title])) {
                $issues[] = 'duplicate_seo_title';
            }
            if ($description !== '' && isset($duplicate_descriptions[$description])) {
                $issues[] = 'duplicate_meta_description';
            }

            $items[] = [
                'id' => (int) $post->ID,
                'title' => get_the_title($post),
                'post_type' => $post->post_type,
                'edit_url' => get_edit_post_link($post->ID, 'raw'),
                'permalink' => get_permalink($post),
                'seo_title' => $seo_title,
                'meta_description' => $description,
                'focus_keyphrase' => $keyphrase,
                'issues' => $issues,
                'issue_count' => count($issues),
            ];
        }

        return [
            'summary' => [
                'total_content' => $total,
                'missing_seo_title' => $missing_title,
                'missing_meta_description' => $missing_description,
                'missing_focus_keyphrase' => $missing_keyphrase,
                'duplicate_seo_title_groups' => count($duplicate_titles),
                'duplicate_meta_description_groups' => count($duplicate_descriptions),
                'content_with_issues' => $this->count_content_with_issues($post_types),
            ],
            'items' => $items,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total_items' => (int) $query->found_posts,
                'total_pages' => (int) $query->max_num_pages,
            ],
        ];
    }

    private function count_missing_meta(string $meta_key, array $post_types): int
    {
        global $wpdb;
        $type_placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        $sql = "SELECT COUNT(*) FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm
                ON pm.post_id = p.ID AND pm.meta_key = %s AND pm.meta_value <> ''
            WHERE p.post_status = 'publish'
              AND p.post_type IN ($type_placeholders)
              AND pm.post_id IS NULL";
        $args = array_merge([$meta_key], $post_types);
        return (int) $wpdb->get_var($wpdb->prepare($sql, $args));
    }

    private function get_duplicate_values(string $meta_key, array $post_types): array
    {
        global $wpdb;
        $type_placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        $sql = "SELECT pm.meta_value, COUNT(DISTINCT p.ID) AS item_count
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = %s
              AND pm.meta_value <> ''
              AND p.post_status = 'publish'
              AND p.post_type IN ($type_placeholders)
            GROUP BY pm.meta_value
            HAVING COUNT(DISTINCT p.ID) > 1";
        $args = array_merge([$meta_key], $post_types);
        $rows = $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
        $duplicates = [];
        foreach ((array) $rows as $row) {
            $duplicates[(string) $row['meta_value']] = (int) $row['item_count'];
        }
        return $duplicates;
    }

    private function count_content_with_issues(array $post_types): int
    {
        // Count published content with at least one missing custom MySEO field.
        // Duplicate issues are summarized separately above.
        global $wpdb;
        $type_placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        $sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} t ON t.post_id = p.ID AND t.meta_key = %s AND t.meta_value <> ''
            LEFT JOIN {$wpdb->postmeta} d ON d.post_id = p.ID AND d.meta_key = %s AND d.meta_value <> ''
            LEFT JOIN {$wpdb->postmeta} k ON k.post_id = p.ID AND k.meta_key = %s AND k.meta_value <> ''
            WHERE p.post_status = 'publish' AND p.post_type IN ($type_placeholders)
              AND (t.post_id IS NULL OR d.post_id IS NULL OR k.post_id IS NULL)";
        $args = array_merge([
            MySEO_Meta_Manager::META_TITLE,
            MySEO_Meta_Manager::META_DESCRIPTION,
            MySEO_Meta_Manager::META_KEYPHRASE,
        ], $post_types);
        return (int) $wpdb->get_var($wpdb->prepare($sql, $args));
    }

    private function empty_result(int $page, int $per_page): array
    {
        return [
            'summary' => [
                'total_content' => 0,
                'missing_seo_title' => 0,
                'missing_meta_description' => 0,
                'missing_focus_keyphrase' => 0,
                'duplicate_seo_title_groups' => 0,
                'duplicate_meta_description_groups' => 0,
                'content_with_issues' => 0,
            ],
            'items' => [],
            'pagination' => ['page' => $page, 'per_page' => $per_page, 'total_items' => 0, 'total_pages' => 0],
        ];
    }
}
