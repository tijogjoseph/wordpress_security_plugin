<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Lightweight rule-based readability analysis for the MySEO MVP.
 *
 * Heuristic checks are suggestions only. They are not a formal readability
 * grade and should not be treated as a ranking score.
 */
final class MySEO_Readability_Analyzer
{
    private const LONG_SENTENCE_WORDS = 25;
    private const LONG_PARAGRAPH_WORDS = 120;

    private const TRANSITION_WORDS = [
        'however', 'therefore', 'additionally', 'also', 'furthermore',
        'moreover', 'for example', 'for instance', 'in addition',
        'as a result', 'consequently', 'meanwhile', 'instead',
        'first', 'second', 'finally', 'although', 'because',
        'in contrast', 'on the other hand', 'next',
    ];

    private const PASSIVE_PARTICIPLES = [
        'made', 'done', 'written', 'known', 'seen', 'given', 'taken',
        'built', 'found', 'used', 'created', 'designed', 'developed',
        'implemented', 'supported', 'managed', 'provided', 'required',
        'published', 'updated', 'configured', 'generated', 'installed',
        'selected', 'chosen', 'sent', 'shown', 'stored', 'checked',
        'approved', 'completed', 'added', 'removed', 'considered',
    ];

    /**
     * @return array<string, array{status:string,message:string,details?:array}>
     */
    public function analyze(string $content): array
    {
        $plain = $this->to_plain_text($content);
        $sentences = $this->sentences($plain);
        $paragraphs = $this->paragraphs($content);
        $sentence_lengths = array_map([$this, 'word_count'], $sentences);
        $paragraph_lengths = array_map([$this, 'word_count'], $paragraphs);

        $long_sentences = [];
        foreach ($sentences as $index => $sentence) {
            if (($sentence_lengths[$index] ?? 0) > self::LONG_SENTENCE_WORDS) {
                $long_sentences[] = [
                    'sentence' => $sentence,
                    'words' => $sentence_lengths[$index],
                ];
            }
        }

        $long_paragraphs = [];
        foreach ($paragraphs as $index => $paragraph) {
            $count = $paragraph_lengths[$index] ?? 0;
            if ($count > self::LONG_PARAGRAPH_WORDS) {
                $long_paragraphs[] = ['paragraph' => $index + 1, 'words' => $count];
            }
        }

        $passive_sentences = [];
        foreach ($sentences as $sentence) {
            if ($this->looks_passive($sentence)) {
                $passive_sentences[] = $sentence;
            }
        }

        $transition_count = $this->count_transition_sentences($sentences);
        $repeated_starts = $this->repeated_sentence_starts($sentences);

        $avg_sentence = $sentence_lengths
            ? round(array_sum($sentence_lengths) / count($sentence_lengths), 1)
            : 0;

        return [
            'summary' => [
                'status' => 'info',
                'message' => sprintf(
                    'Found %d words across %d sentences and %d paragraphs. Average sentence length: %s words.',
                    $this->word_count($plain),
                    count($sentences),
                    count($paragraphs),
                    number_format($avg_sentence, 1)
                ),
            ],
            'sentence_length' => [
                'status' => empty($long_sentences) ? 'good' : 'needs_work',
                'message' => empty($long_sentences)
                    ? 'No sentences exceed the suggested 25-word review threshold.'
                    : sprintf('%d sentence(s) exceed %d words. Consider splitting them for easier reading.', count($long_sentences), self::LONG_SENTENCE_WORDS),
                'details' => $long_sentences,
            ],
            'paragraph_length' => [
                'status' => empty($long_paragraphs) ? 'good' : 'needs_work',
                'message' => empty($long_paragraphs)
                    ? 'No paragraphs exceed the suggested 120-word review threshold.'
                    : sprintf('%d paragraph(s) exceed %d words. Consider breaking them into smaller sections.', count($long_paragraphs), self::LONG_PARAGRAPH_WORDS),
                'details' => $long_paragraphs,
            ],
            'passive_voice' => [
                'status' => empty($passive_sentences) ? 'good' : 'needs_review',
                'message' => empty($passive_sentences)
                    ? 'No likely passive-voice patterns were detected.'
                    : sprintf('%d sentence(s) may use passive voice. Review whether active voice would be clearer.', count($passive_sentences)),
                'details' => $passive_sentences,
            ],
            'transition_words' => [
                'status' => (count($sentences) < 3 || $transition_count > 0) ? 'good' : 'needs_review',
                'message' => count($sentences) < 3
                    ? 'Add connecting words where they improve the flow between ideas.'
                    : ($transition_count > 0
                        ? sprintf('Found transition words in %d sentence(s). Use them where they clarify relationships between ideas.', $transition_count)
                        : 'Consider adding transition words such as “however”, “therefore”, or “for example” where appropriate.'),
            ],
            'consecutive_starts' => [
                'status' => empty($repeated_starts) ? 'good' : 'needs_review',
                'message' => empty($repeated_starts)
                    ? 'No repeated consecutive sentence openings were detected.'
                    : sprintf('%d consecutive sentence pair(s) begin with the same word. Vary sentence openings where possible.', count($repeated_starts)),
                'details' => $repeated_starts,
            ],
        ];
    }

    private function to_plain_text(string $content): string
    {
        $content = strip_shortcodes($content);
        $content = preg_replace('/<!--.*?-->/s', ' ', $content) ?? $content;
        $content = preg_replace('/<\/(p|div|li|h[1-6]|blockquote)>/i', "\n", $content) ?? $content;
        return trim(wp_strip_all_tags($content));
    }

    private function paragraphs(string $content): array
    {
        $content = strip_shortcodes($content);
        $content = preg_replace('/<!--.*?-->/s', ' ', $content) ?? $content;

        if (preg_match_all('/<p\b[^>]*>(.*?)<\/p>/is', $content, $matches)) {
            $items = [];
            foreach ($matches[1] as $html) {
                $text = trim(wp_strip_all_tags($html));
                if ($text !== '') {
                    $items[] = $text;
                }
            }
            if ($items) {
                return $items;
            }
        }

        $plain = $this->to_plain_text($content);
        return array_values(array_filter(array_map('trim', preg_split('/\R+/u', $plain) ?: [])));
    }

    private function sentences(string $text): array
    {
        $parts = preg_split('/(?<=[.!?])\s+(?=[\p{L}\p{N}"“(])/u', $text) ?: [];
        return array_values(array_filter(array_map('trim', $parts), static function ($part) {
            return $part !== '';
        }));
    }

    private function word_count(string $text): int
    {
        return preg_match_all('/[\p{L}\p{N}]+(?:[\'’_-][\p{L}\p{N}]+)*/u', $text, $matches) ?: 0;
    }

    private function looks_passive(string $sentence): bool
    {
        $normalized = strtolower($sentence);
        $auxiliary = '(?:am|is|are|was|were|be|been|being|get|gets|got)';
        $participles = implode('|', array_map(static function ($word) {
            return preg_quote($word, '/');
        }, self::PASSIVE_PARTICIPLES));

        return preg_match('/\b' . $auxiliary . '\s+(?:\w+\s+){0,2}(?:' . $participles . ')\b/i', $normalized) === 1
            || preg_match('/\b' . $auxiliary . '\s+\w+ed\b/i', $normalized) === 1;
    }

    private function count_transition_sentences(array $sentences): int
    {
        $count = 0;
        foreach ($sentences as $sentence) {
            $sentence = strtolower(trim($sentence));
            foreach (self::TRANSITION_WORDS as $word) {
                if (preg_match('/\b' . preg_quote($word, '/') . '\b/i', $sentence)) {
                    $count++;
                    break;
                }
            }
        }
        return $count;
    }

    private function repeated_sentence_starts(array $sentences): array
    {
        $repeated = [];
        for ($i = 1, $total = count($sentences); $i < $total; $i++) {
            preg_match('/^[\s"“\'(]*([\p{L}\p{N}]+)/u', $sentences[$i - 1], $previous);
            preg_match('/^[\s"“\'(]*([\p{L}\p{N}]+)/u', $sentences[$i], $current);

            if (!empty($previous[1]) && !empty($current[1])
                && strtolower($previous[1]) === strtolower($current[1])) {
                $repeated[] = [
                    'word' => $previous[1],
                    'first' => $sentences[$i - 1],
                    'second' => $sentences[$i],
                ];
            }
        }
        return $repeated;
    }
}
