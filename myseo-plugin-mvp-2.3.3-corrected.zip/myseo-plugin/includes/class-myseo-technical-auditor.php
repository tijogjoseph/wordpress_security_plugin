<?php
/**
 * Technical SEO audit for site configuration and published content.
 */
if (!defined('ABSPATH')) {
    exit;
}

class MySEO_Technical_Auditor
{
    public function audit(int $page = 1, int $per_page = 20, string $search = ''): array
    {
        $page = max(1, $page);
        $per_page = min(50, max(1, $per_page));
        $post_types = array_values(array_diff(get_post_types(['public' => true], 'names'), ['attachment']));
        $query = new WP_Query([
            'post_type' => $post_types ?: 'post',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            's' => sanitize_text_field($search),
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        $home_url = home_url('/');
        $home_host = strtolower((string) wp_parse_url($home_url, PHP_URL_HOST));
        $https = strtolower((string) wp_parse_url($home_url, PHP_URL_SCHEME)) === 'https';
        $local_environment = $this->is_local_development_host($home_host);
        $public = (string) get_option('blog_public', '1') === '1';
        $sitemap_check = $this->check_sitemap();
        $canonical_check = $this->check_rendered_canonical($query->posts);

        $site_checks = [
            [
                'id' => 'https',
                'label' => 'HTTPS site URL',
                'status' => $https ? 'good' : ($local_environment ? 'review' : 'issue'),
                'detail' => $https
                    ? 'The WordPress home URL uses HTTPS.'
                    : ($local_environment
                        ? 'This appears to be a local development domain. HTTP is common locally; configure HTTPS before launching the site publicly.'
                        : 'The WordPress home URL does not use HTTPS. Configure SSL and update the WordPress Address and Site Address where appropriate.'),
                'url' => $home_url,
            ],
            [
                'id' => 'visibility',
                'label' => 'Search engine visibility',
                'status' => $public ? 'good' : 'issue',
                'detail' => $public ? 'WordPress is not configured to discourage search engines.' : 'WordPress is configured to discourage search engines from indexing this site. Check Settings → Reading.',
                'url' => admin_url('options-reading.php'),
            ],
            [
                'id' => 'sitemap',
                'label' => 'XML sitemap',
                'status' => $sitemap_check['status'],
                'detail' => $sitemap_check['detail'],
                'url' => home_url('/wp-sitemap.xml'),
            ],
            [
                'id' => 'canonical',
                'label' => 'Rendered canonical tag',
                'status' => $canonical_check['status'],
                'detail' => $canonical_check['detail'],
                'url' => $canonical_check['url'],
            ],
        ];

        $items = [];
        $summary = ['posts_in_batch' => count($query->posts), 'posts_with_internal_links' => 0, 'internal_link_occurrences' => 0, 'mixed_content_links' => 0, 'unresolved_internal_links' => 0];
        $posts_with_links = [];

        foreach ($query->posts as $post) {
            $content = (string) $post->post_content;
            if (!preg_match_all('/<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $content, $matches, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($matches as $match) {
                if (count($items) >= 500) {
                    break 2;
                }
                $href = html_entity_decode($match[1] !== '' ? $match[1] : ($match[2] !== '' ? $match[2] : ($match[3] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $href = trim($href);
                if ($href === '' || str_starts_with($href, '#') || preg_match('/^(mailto:|tel:|javascript:|data:)/i', $href)) {
                    continue;
                }
                $absolute = (string) (wp_parse_url($href, PHP_URL_SCHEME) ? $href : (str_starts_with($href, '//') ? (is_ssl() ? 'https:' : 'http:') . $href : home_url($href)));
                $host = strtolower((string) wp_parse_url($absolute, PHP_URL_HOST));
                $site_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
                if (!$host || $host !== $site_host) {
                    continue;
                }

                $summary['internal_link_occurrences']++;
                $posts_with_links[(int) $post->ID] = true;
                $mixed = $https && strtolower((string) wp_parse_url($absolute, PHP_URL_SCHEME)) === 'http';
                if ($mixed) {
                    $summary['mixed_content_links']++;
                }
                $path = (string) wp_parse_url($absolute, PHP_URL_PATH);
                $is_home = untrailingslashit($path) === untrailingslashit((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
                $target_id = $is_home ? 1 : url_to_postid($absolute);
                $unresolved = !$is_home && !$target_id;
                if ($unresolved) {
                    $summary['unresolved_internal_links']++;
                }

                $items[] = [
                    'key' => (int) $post->ID . '-' . count($items),
                    'post_id' => (int) $post->ID,
                    'post_title' => get_the_title($post) ?: '(Untitled)',
                    'post_type' => (string) $post->post_type,
                    'href' => esc_url_raw($absolute),
                    'mixed_content' => $mixed,
                    'unresolved' => $unresolved,
                    'post_edit_url' => get_edit_post_link($post->ID, 'raw'),
                ];
            }
        }
        $summary['posts_with_internal_links'] = count($posts_with_links);
        $link_topology = $this->analyze_link_topology($post_types);

        return [
            'site_checks' => $site_checks,
            'items' => $items,
            'summary' => $summary,
            'link_topology' => $link_topology,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total_posts' => (int) $query->found_posts,
                'total_pages' => max(1, (int) $query->max_num_pages),
            ],
        ];
    }

    /**
     * Build a site-wide internal-link map from saved content.
     *
     * The scan is deliberately capped to keep admin requests bounded. It counts
     * links that resolve to published WordPress content; custom routes and
     * archive URLs remain outside this post-to-post map.
     */
    private function analyze_link_topology(array $post_types): array
    {
        $limit = 1000;
        $query = new WP_Query([
            'post_type' => $post_types ?: 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'paged' => 1,
            'orderby' => 'ID',
            'order' => 'ASC',
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
            'fields' => 'all',
        ]);

        $posts = [];
        $incoming = [];
        $outgoing = [];
        $unique_targets = [];
        foreach ($query->posts as $post) {
            $id = (int) $post->ID;
            $posts[$id] = [
                'id' => $id,
                'title' => get_the_title($post) ?: '(Untitled)',
                'type' => (string) $post->post_type,
                'edit_url' => get_edit_post_link($id, 'raw'),
                'permalink' => get_permalink($post),
            ];
            $incoming[$id] = 0;
            $outgoing[$id] = 0;
            $unique_targets[$id] = [];
        }

        $site_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        $link_occurrences = 0;

        foreach ($query->posts as $post) {
            $source_id = (int) $post->ID;
            $content = (string) $post->post_content;
            if (!preg_match_all('/<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $content, $matches, PREG_SET_ORDER)) {
                continue;
            }

            foreach ($matches as $match) {
                if ($link_occurrences >= 10000) {
                    break 2;
                }
                $href = html_entity_decode(
                    $match[1] !== '' ? $match[1] : ($match[2] !== '' ? $match[2] : ($match[3] ?? '')),
                    ENT_QUOTES | ENT_HTML5,
                    'UTF-8'
                );
                $href = trim($href);
                if ($href === '' || str_starts_with($href, '#')
                    || preg_match('/^(mailto:|tel:|javascript:|data:)/i', $href)) {
                    continue;
                }

                $scheme = wp_parse_url($href, PHP_URL_SCHEME);
                $absolute = $scheme
                    ? $href
                    : (str_starts_with($href, '//')
                        ? (is_ssl() ? 'https:' : 'http:') . $href
                        : home_url($href));
                $host = strtolower((string) wp_parse_url($absolute, PHP_URL_HOST));
                if (!$host || $host !== $site_host) {
                    continue;
                }

                $target_id = url_to_postid($absolute);
                if (!$target_id || !isset($posts[$target_id]) || $target_id === $source_id) {
                    continue;
                }

                $link_occurrences++;
                $outgoing[$source_id]++;
                $incoming[$target_id]++;
                $unique_targets[$source_id][$target_id] = true;
            }
        }

        $rows = [];
        $orphaned = [];
        $low_outgoing = [];
        foreach ($posts as $id => $post_data) {
            $row = $post_data + [
                'incoming_links' => $incoming[$id],
                'outgoing_links' => $outgoing[$id],
                'unique_outgoing_targets' => count($unique_targets[$id]),
            ];
            $rows[] = $row;
            if ($incoming[$id] === 0) {
                $orphaned[] = $row;
            }
            if ($outgoing[$id] === 0) {
                $low_outgoing[] = $row;
            }
        }

        usort($orphaned, static function ($a, $b) {
            return strcasecmp($a['title'], $b['title']);
        });
        usort($low_outgoing, static function ($a, $b) {
            return strcasecmp($a['title'], $b['title']);
        });

        return [
            'posts_analyzed' => count($posts),
            'post_limit' => $limit,
            'analysis_limited' => (int) $query->found_posts > $limit,
            'internal_link_occurrences' => $link_occurrences,
            'orphaned_posts_count' => count($orphaned),
            'posts_without_outgoing_links_count' => count($low_outgoing),
            'orphaned_posts' => array_slice($orphaned, 0, 50),
            'posts_without_outgoing_links' => array_slice($low_outgoing, 0, 50),
            'rows' => array_slice($rows, 0, 100),
        ];
    }

    /**
     * Identify common local development hostnames to avoid production-only HTTPS warnings.
     */
    private function is_local_development_host(string $host): bool
    {
        $host = strtolower(trim($host, '[]'));
        if ($host === '' || $host === 'localhost' || str_ends_with($host, '.localhost')
            || str_ends_with($host, '.local') || str_ends_with($host, '.test')
            || str_ends_with($host, '.invalid')) {
            return true;
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $host === '127.0.0.1' || $host === '::1'
                || (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
                    && str_starts_with($host, '192.168.'))
                || (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
                    && str_starts_with($host, '10.'));
        }

        return false;
    }

    /**
     * Check the sitemap endpoint and, for sitemap indexes, one child sitemap.
     * A failed loopback HTTP request is reported as inconclusive rather than absent.
     */
    private function check_sitemap(): array
    {
        $sitemap_url = home_url('/wp-sitemap.xml');
        $core_enabled = function_exists('wp_sitemaps_enabled') ? (bool) wp_sitemaps_enabled() : null;
        $response = wp_remote_get($sitemap_url, [
            'timeout' => 4,
            'redirection' => 3,
            'limit_response_size' => 1048576,
            'headers' => ['Accept' => 'application/xml,text/xml,*/*'],
        ]);

        if (is_wp_error($response)) {
            $core_text = $core_enabled === true
                ? ' WordPress core sitemap generation is enabled.'
                : '';
            return [
                'status' => 'review',
                'detail' => 'The sitemap URL could not be verified from the server (' . sanitize_text_field($response->get_error_message()) . ').' . $core_text . ' Open the sitemap in a browser to confirm availability.',
            ];
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        if ($status_code < 200 || $status_code >= 300 || trim($body) === '') {
            return [
                'status' => 'review',
                'detail' => 'The sitemap URL returned HTTP ' . $status_code . ' or an empty response. Check the sitemap endpoint and any caching or security rules.',
            ];
        }

        $xml = $this->parse_sitemap_xml($body);
        if (!$xml) {
            return [
                'status' => 'review',
                'detail' => 'The sitemap URL responded, but its body could not be verified as valid XML. Review the response for HTML, redirects or malformed XML.',
            ];
        }

        $root_name = strtolower($xml['root']);
        if (!in_array($root_name, ['sitemapindex', 'urlset'], true)) {
            return [
                'status' => 'review',
                'detail' => 'The sitemap URL returned XML, but the document root is not a standard sitemap index or URL set.',
            ];
        }

        if ($root_name === 'sitemapindex' && !empty($xml['first_child'])) {
            $child_url = $xml['first_child'];
            $home_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
            $child_host = strtolower((string) wp_parse_url($child_url, PHP_URL_HOST));
            if ($child_host !== $home_host) {
                return [
                    'status' => 'review',
                    'detail' => 'The sitemap index is valid, but its first child sitemap points to a different host and was not fetched automatically.',
                ];
            }

            $child_response = wp_remote_get($child_url, [
                'timeout' => 4,
                'redirection' => 3,
                'limit_response_size' => 1048576,
                'headers' => ['Accept' => 'application/xml,text/xml,*/*'],
            ]);
            if (is_wp_error($child_response)) {
                return [
                    'status' => 'review',
                    'detail' => 'The sitemap index is valid, but the first child sitemap could not be checked from the server. Open the child sitemap manually to confirm it.',
                ];
            }
            $child_code = (int) wp_remote_retrieve_response_code($child_response);
            $child_xml = $child_code >= 200 && $child_code < 300
                ? $this->parse_sitemap_xml((string) wp_remote_retrieve_body($child_response))
                : false;
            if (!$child_xml || !in_array(strtolower($child_xml['root']), ['urlset', 'sitemapindex'], true)) {
                return [
                    'status' => 'review',
                    'detail' => 'The sitemap index is valid, but its first child sitemap did not return a valid sitemap XML response (HTTP ' . $child_code . ').',
                ];
            }

            return [
                'status' => 'good',
                'detail' => 'The sitemap index returned valid XML (HTTP ' . $status_code . '), and its first child sitemap also returned valid XML (HTTP ' . $child_code . ').' . ($core_enabled === true ? ' WordPress core sitemap support is enabled.' : ' A working sitemap was detected even though the WordPress core sitemap flag is not enabled; it may be supplied by another component.'),
            ];
        }

        return [
            'status' => 'good',
            'detail' => 'The sitemap URL returned a valid XML ' . ($root_name === 'urlset' ? 'URL set' : 'sitemap index') . ' (HTTP ' . $status_code . ').' . ($core_enabled === true ? ' WordPress core sitemap support is enabled.' : ' A working sitemap was detected even though the WordPress core sitemap flag is not enabled; it may be supplied by another component.'),
        ];
    }

    /**
     * Parse the sitemap XML root and first child location without loading external entities.
     */
    private function parse_sitemap_xml(string $body)
    {
        if (class_exists('SimpleXMLElement')) {
            $previous = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($body, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
            if ($xml instanceof SimpleXMLElement) {
                $root = strtolower((string) $xml->getName());
                $first_child = '';
                if ($root === 'sitemapindex' && isset($xml->sitemap[0]->loc)) {
                    $first_child = esc_url_raw((string) $xml->sitemap[0]->loc);
                }
                return ['root' => $root, 'first_child' => $first_child];
            }
            return false;
        }

        if (!preg_match('/<([a-z0-9:_-]+)\b[^>]*>/i', $body, $root_match)) {
            return false;
        }
        $root = strtolower(substr(strrchr(':' . $root_match[1], ':'), 1));
        if (!in_array($root, ['sitemapindex', 'urlset'], true)) {
            return false;
        }
        $first_child = '';
        if ($root === 'sitemapindex' && preg_match('/<loc>\s*(.*?)\s*<\/loc>/is', $body, $loc_match)) {
            $first_child = esc_url_raw(html_entity_decode($loc_match[1], ENT_QUOTES | ENT_XML1, 'UTF-8'));
        }
        return ['root' => $root, 'first_child' => $first_child];
    }

    /**
     * Fetch one published page and inspect its rendered canonical link tags.
     */
    private function check_rendered_canonical(array $posts): array
    {
        if (!$posts) {
            return [
                'status' => 'review',
                'detail' => 'No published content was available in this batch to inspect for a rendered canonical tag.',
                'url' => '',
            ];
        }

        $post = $posts[0];
        $page_url = get_permalink($post);
        if (!$page_url) {
            return [
                'status' => 'review',
                'detail' => 'A sample published page URL could not be generated, so rendered canonical output could not be checked.',
                'url' => '',
            ];
        }

        $response = wp_remote_get($page_url, [
            'timeout' => 4,
            'redirection' => 3,
            'limit_response_size' => 2097152,
            'headers' => ['Accept' => 'text/html'],
        ]);
        if (is_wp_error($response)) {
            return [
                'status' => 'review',
                'detail' => 'The sample page could not be fetched from the server (' . sanitize_text_field($response->get_error_message()) . '). Canonical output could not be verified automatically; inspect the rendered page source.',
                'url' => '',
            ];
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        $html = (string) wp_remote_retrieve_body($response);
        if ($status_code < 200 || $status_code >= 300 || $html === '') {
            return [
                'status' => 'review',
                'detail' => 'The sample page returned HTTP ' . $status_code . ', so its rendered canonical tag could not be verified.',
                'url' => '',
            ];
        }

        preg_match_all('/<link\b[^>]*>/i', $html, $link_tags);
        $canonicals = [];
        foreach ($link_tags[0] as $tag) {
            $rel = $this->html_attribute($tag, 'rel');
            if ($rel !== '' && preg_match('/(?:^|\s)canonical(?:\s|$)/i', trim($rel))) {
                $href = $this->html_attribute($tag, 'href');
                if ($href !== '') {
                    $canonicals[] = esc_url_raw(html_entity_decode($href, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                }
            }
        }

        if (count($canonicals) > 1) {
            return [
                'status' => 'issue',
                'detail' => 'The rendered sample page contains ' . count($canonicals) . ' canonical link tags. Keep a single canonical tag to avoid conflicting signals.',
                'url' => $page_url,
            ];
        }
        if (count($canonicals) === 0) {
            return [
                'status' => 'review',
                'detail' => 'No canonical link tag was found in the rendered sample page HTML. A plugin, theme or cache may alter the output; inspect the page source.',
                'url' => $page_url,
            ];
        }

        $actual = untrailingslashit((string) $canonicals[0]);
        $expected = untrailingslashit((string) $page_url);
        if ($actual !== $expected) {
            return [
                'status' => 'review',
                'detail' => 'One canonical tag was rendered, but its URL differs from the sample page permalink. Review the canonical URL for intentional overrides or incorrect output.',
                'url' => $page_url,
            ];
        }

        return [
            'status' => 'good',
            'detail' => 'Exactly one canonical tag was found in the rendered sample page HTML, and its URL matches the page permalink. Sample checked: ' . $page_url,
            'url' => $page_url,
        ];
    }

    /**
     * Read a quoted or unquoted HTML attribute from a tag.
     */
    private function html_attribute(string $tag, string $name): string
    {
        $pattern = '/(?:^|\s)' . preg_quote($name, '/') . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i';
        if (!preg_match($pattern, $tag, $matches)) {
            return '';
        }
        return (string) ($matches[1] ?? ($matches[2] ?? ($matches[3] ?? '')));
    }

}
