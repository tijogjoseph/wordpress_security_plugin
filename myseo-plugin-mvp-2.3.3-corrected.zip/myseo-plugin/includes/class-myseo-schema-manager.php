<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Emits a conservative Article/BlogPosting or WebPage JSON-LD graph.
 * Avoids output when a commonly used SEO plugin is active to reduce duplicates.
 */
final class MySEO_Schema_Manager
{
    private const KNOWN_SEO_PLUGINS = [
        'wordpress-seo/wp-seo.php',
        'seo-by-rank-math/rank-math.php',
        'all-in-one-seo-pack/all_in_one_seo_pack.php',
        'wp-seopress/seopress.php',
        'slim-seo/slim-seo.php',
    ];

    public function register_hooks(): void
    {
        add_action('wp_head', [$this, 'render_schema'], 30);
    }

    public function render_schema(): void
    {
        if (is_admin() || !is_singular() || is_feed() || is_preview()) {
            return;
        }

        $settings = get_option('myseo_settings', []);
        if (array_key_exists('enable_schema_output', $settings) && empty($settings['enable_schema_output'])) {
            return;
        }

        if ($this->has_known_seo_plugin_active()) {
            return;
        }

        $post_id = get_queried_object_id();
        $post = get_post($post_id);
        if (!$post instanceof WP_Post || $post->post_status !== 'publish') {
            return;
        }

        $schema = $this->build_schema($post);
        $schema = apply_filters('myseo_schema_data', $schema, $post);

        if (!is_array($schema) || empty($schema['@type'])) {
            return;
        }

        $json = wp_json_encode(
            $schema,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );

        if (!is_string($json) || $json === '') {
            return;
        }

        echo "\n<script type=\"application/ld+json\" class=\"myseo-schema\">\n";
        echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON is encoded with wp_json_encode and JSON_HEX_* flags.
        echo "\n</script>\n";
    }

    private function build_schema(WP_Post $post): array
    {
        $url = get_permalink($post);
        if (!$url) {
            return [];
        }

        $is_article = $post->post_type === 'post';
        $description = get_post_meta($post->ID, MySEO_Meta_Manager::META_DESCRIPTION, true);
        if ($description === '') {
            $description = wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_excerpt ?: $post->post_content)), 35, '');
        }

        $headline = get_post_meta($post->ID, MySEO_Meta_Manager::META_TITLE, true);
        if ($headline === '') {
            $headline = get_the_title($post);
        }

        $schema = [
            '@context' => 'https://schema.org',
            '@type' => $is_article ? 'BlogPosting' : 'WebPage',
            '@id' => trailingslashit($url) . ($is_article ? '#article' : '#webpage'),
            'url' => $url,
            'name' => $headline,
            'headline' => $headline,
            'description' => wp_strip_all_tags((string) $description),
            'datePublished' => get_post_time('c', true, $post),
            'dateModified' => get_post_modified_time('c', true, $post),
            'inLanguage' => get_bloginfo('language'),
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => $url,
            ],
        ];

        if ($is_article) {
            $author_id = (int) $post->post_author;
            $author_name = get_the_author_meta('display_name', $author_id);
            if ($author_name !== '') {
                $schema['author'] = [
                    '@type' => 'Person',
                    'name' => $author_name,
                ];
            }
        }

        $image_id = get_post_thumbnail_id($post);
        if ($image_id) {
            $image = wp_get_attachment_image_src($image_id, 'full');
            if (is_array($image) && !empty($image[0])) {
                $schema['image'] = [
                    '@type' => 'ImageObject',
                    'url' => esc_url_raw($image[0]),
                ];
                if (!empty($image[1])) {
                    $schema['image']['width'] = (int) $image[1];
                }
                if (!empty($image[2])) {
                    $schema['image']['height'] = (int) $image[2];
                }
            }
        }

        $site_name = get_bloginfo('name');
        if ($site_name !== '') {
            $schema['publisher'] = [
                '@type' => 'Organization',
                'name' => $site_name,
            ];

            $logo_id = (int) get_theme_mod('custom_logo');
            if ($logo_id) {
                $logo = wp_get_attachment_image_src($logo_id, 'full');
                if (is_array($logo) && !empty($logo[0])) {
                    $schema['publisher']['logo'] = [
                        '@type' => 'ImageObject',
                        'url' => esc_url_raw($logo[0]),
                    ];
                }
            }
        }

        return $schema;
    }

    private function has_known_seo_plugin_active(): bool
    {
        $active_plugins = (array) get_option('active_plugins', []);
        if (is_multisite()) {
            $network_plugins = (array) get_site_option('active_sitewide_plugins', []);
            $active_plugins = array_merge($active_plugins, array_keys($network_plugins));
        }

        return (bool) array_intersect(self::KNOWN_SEO_PLUGINS, $active_plugins);
    }
}
