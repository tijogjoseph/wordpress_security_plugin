<?php
/**
 * Site-wide image usage audit.
 */
if (!defined('ABSPATH')) {
    exit;
}

class MySEO_Site_Image_Auditor
{
    public function audit(int $page = 1, int $per_page = 20, string $search = ''): array
    {
        $page = max(1, $page);
        $per_page = min(50, max(1, $per_page));
        $post_types = array_values(array_diff(get_post_types(['public' => true], 'names'), ['attachment']));
        if (!$post_types) {
            return ['items' => [], 'summary' => $this->empty_summary(), 'pagination' => ['page' => 1, 'per_page' => $per_page, 'total_posts' => 0, 'total_pages' => 1]];
        }

        $query = new WP_Query([
            'post_type' => $post_types,
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            's' => sanitize_text_field($search),
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        $items = [];
        $summary = $this->empty_summary();
        foreach ($query->posts as $post) {
            preg_match_all('/<img\b[^>]*>/i', (string) $post->post_content, $matches);
            foreach ($matches[0] as $tag) {
                $src_attr = $this->attribute($tag, 'src');
                $src_value = $src_attr['value'] ?? '';
                $src = ($src_attr['found'] ?? false) && is_scalar($src_value) ? (string) $src_value : '';
                $alt = $this->attribute($tag, 'alt');
                $has_alt = $alt['found'];
                $alt_text = $has_alt ? trim(html_entity_decode($alt['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8')) : '';
                $attachment_id = $this->attachment_id($tag);
                $filename = $src ? basename((string) wp_parse_url($src, PHP_URL_PATH)) : '(source unavailable)';
                $status = !$has_alt ? 'missing' : ($alt_text === '' ? 'empty' : 'ok');

                $summary['image_occurrences']++;
                if ($status === 'missing') {
                    $summary['missing_alt']++;
                } elseif ($status === 'empty') {
                    $summary['empty_alt']++;
                } else {
                    $summary['with_alt']++;
                }

                $items[] = [
                    'key' => (int) $post->ID . '-' . count($items),
                    'post_id' => (int) $post->ID,
                    'post_title' => get_the_title($post) ?: '(Untitled)',
                    'post_type' => (string) $post->post_type,
                    'filename' => sanitize_text_field(rawurldecode($filename)),
                    'src' => $src !== '' ? esc_url_raw($src) : '',
                    'alt' => $alt_text,
                    'status' => $status,
                    'attachment_id' => $attachment_id,
                    'post_edit_url' => get_edit_post_link($post->ID, 'raw'),
                    'attachment_edit_url' => $attachment_id ? get_edit_post_link($attachment_id, 'raw') : '',
                ];
            }
        }

        $summary['posts_in_batch'] = count($query->posts);
        $summary['posts_with_images'] = count(array_unique(array_column($items, 'post_id')));

        return [
            'items' => $items,
            'summary' => $summary,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total_posts' => (int) $query->found_posts,
                'total_pages' => max(1, (int) $query->max_num_pages),
            ],
        ];
    }

    private function attribute(string $tag, string $name): array
    {
        $pattern = '/(?:^|\s)' . preg_quote($name, '/') . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i';
        if (!preg_match($pattern, $tag, $matches)) {
            return ['found' => false, 'value' => ''];
        }
        return ['found' => true, 'value' => $matches[1] ?? ($matches[2] ?? ($matches[3] ?? ''))];
    }

    private function attachment_id(string $tag): int
    {
        $data_id = $this->attribute($tag, 'data-id');
        if ($data_id['found'] && absint($data_id['value'])) {
            return absint($data_id['value']);
        }
        $class = $this->attribute($tag, 'class');
        if ($class['found'] && preg_match('/(?:^|\s)wp-image-(\d+)(?:\s|$)/', $class['value'], $match)) {
            return absint($match[1]);
        }
        return 0;
    }

    private function empty_summary(): array
    {
        return ['posts_in_batch' => 0, 'posts_with_images' => 0, 'image_occurrences' => 0, 'missing_alt' => 0, 'empty_alt' => 0, 'with_alt' => 0];
    }
}
