<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Plugin
{
    private static ?self $instance = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function init(): void
    {
        (new MySEO_Meta_Manager())->register_hooks();
        (new MySEO_Schema_Manager())->register_hooks();
        (new MySEO_Admin())->register_hooks();
    }

    private function __construct()
    {
    }
}
