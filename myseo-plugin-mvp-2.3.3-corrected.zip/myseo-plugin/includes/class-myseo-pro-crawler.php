<?php
if (!defined('ABSPATH')) { exit; }

final class MySEO_Pro_Crawler {
    public function crawl(int $limit = 20): array {
        $start = home_url('/');
        $host = strtolower((string) wp_parse_url($start, PHP_URL_HOST));
        $queue = [$start]; $seen = []; $results = []; $link_map = []; $limit = min(20, max(1, $limit));
        while ($queue && count($results) < $limit) {
            $url = array_shift($queue); $url = $this->normalize($url);
            if (!$url || isset($seen[$url])) continue;
            $seen[$url] = true;
            $parsed = wp_parse_url($url);
            if (!$parsed || strtolower((string)($parsed['host'] ?? '')) !== $host) continue;
            $response = wp_safe_remote_get($url, [
                'timeout' => 5, 'redirection' => 1, 'limit_response_size' => 500000,
                'headers' => ['User-Agent' => 'MySEO-Crawler/2.1.0 (+WordPress SEO audit)'],
            ]);
            if (is_wp_error($response)) {
                $results[] = ['url'=>$url,'status'=>0,'title'=>'','description'=>'','canonical'=>'','noindex'=>false,'h1'=>0,'issues'=>['Fetch error: '.$response->get_error_message()]];
                continue;
            }
            $status = (int) wp_remote_retrieve_response_code($response);
            $body = (string) wp_remote_retrieve_body($response);
            $ctype = (string) wp_remote_retrieve_header($response, 'content-type');
            $item = ['url'=>$url,'status'=>$status,'title'=>'','description'=>'','canonical'=>'','noindex'=>false,'h1'=>0,'issues'=>[]];
            if (stripos($ctype, 'text/html') !== false || preg_match('/<html\b/i', $body)) {
                if (preg_match('/<title\b[^>]*>(.*?)<\/title>/is', $body, $m)) $item['title'] = trim(wp_strip_all_tags(html_entity_decode($m[1], ENT_QUOTES|ENT_HTML5, 'UTF-8')));
                if (preg_match('/<meta\b[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\']/i', $body, $m) || preg_match('/<meta\b[^>]*content=["\']([^"\']*)["\'][^>]*name=["\']description["\']/i', $body, $m)) $item['description'] = trim(html_entity_decode($m[1], ENT_QUOTES|ENT_HTML5, 'UTF-8'));
                if (preg_match('/<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']*)["\']/i', $body, $m) || preg_match('/<link\b[^>]*href=["\']([^"\']*)["\'][^>]*rel=["\']canonical["\']/i', $body, $m)) $item['canonical'] = esc_url_raw($m[1]);
                $item['noindex'] = (bool) preg_match('/<meta\b[^>]*name=["\']robots["\'][^>]*content=["\'][^"\']*noindex/i', $body);
                $item['h1'] = preg_match_all('/<h1\b/i', $body);
                if ($item['title'] === '') $item['issues'][] = 'Missing title';
                if ($item['description'] === '') $item['issues'][] = 'Missing meta description';
                if (!$item['canonical']) $item['issues'][] = 'Missing canonical';
                if ($item['noindex']) $item['issues'][] = 'Noindex detected';
                if ($item['h1'] === 0) $item['issues'][] = 'Missing H1';
                if ($item['h1'] > 1) $item['issues'][] = 'Multiple H1';
                $title_len = function_exists('mb_strlen') ? mb_strlen($item['title']) : strlen($item['title']);
                $desc_len = function_exists('mb_strlen') ? mb_strlen($item['description']) : strlen($item['description']);
                if ($item['title'] !== '' && $title_len < 30) $item['issues'][] = 'Title may be too short';
                if ($item['title'] !== '' && $title_len > 60) $item['issues'][] = 'Title may be too long';
                if ($item['description'] !== '' && $desc_len < 70) $item['issues'][] = 'Meta description may be too short';
                if ($item['description'] !== '' && $desc_len > 160) $item['issues'][] = 'Meta description may be too long';
                if (preg_match('/<h1\b[^>]*>\s*<\/h1>/i', $body)) $item['issues'][] = 'Empty H1';
                if (preg_match('/<h([1-6])\b/i', $body, $hm) && (int)$hm[1] > 1 && !preg_match('/<h1\b/i', $body)) $item['issues'][] = 'Heading hierarchy starts below H1';
                if ($status >= 400) $item['issues'][] = 'HTTP error';
                // Discover only same-host HTTP(S) links; subsequent requests are independently checked with wp_safe_remote_get.
                if (preg_match_all('/<a\b([^>]*)href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $body, $links, PREG_SET_ORDER)) {
                    foreach ($links as $link) {
                        $href = $link[2];
                        $anchor = trim(wp_strip_all_tags($link[3]));
                        $candidate = $this->resolve($href, $url);
                        if (!$candidate) continue;
                        if (!isset($link_map[$candidate])) $link_map[$candidate] = [];
                        // One source-page association per destination; collect distinct anchor texts.
                        $source_key = $url;
                        if (!isset($link_map[$candidate][$source_key])) $link_map[$candidate][$source_key] = ['source'=>$url,'anchors'=>[]];
                        if ($anchor !== '' && !in_array($anchor, $link_map[$candidate][$source_key]['anchors'], true)) $link_map[$candidate][$source_key]['anchors'][] = $anchor;
                        $ch = strtolower((string) wp_parse_url($candidate, PHP_URL_HOST));
                        if ($ch === $host && !isset($seen[$candidate]) && count($queue) < 100) $queue[] = $candidate;
                    }
                }
            } else { $item['issues'][] = 'Non-HTML response'; }
            $results[] = $item;
        }
        // Flag duplicate titles and descriptions across pages crawled in this run.
        $title_groups = []; $description_groups = [];
        foreach ($results as $idx => $r) {
            if (!empty($r['title'])) { $key = strtolower(trim($r['title'])); $title_groups[$key][] = $idx; }
            if (!empty($r['description'])) { $key = strtolower(trim($r['description'])); $description_groups[$key][] = $idx; }
        }
        $duplicate_titles = 0; $duplicate_descriptions = 0;
        foreach ($title_groups as $group) if (count($group) > 1) { $duplicate_titles += count($group); foreach ($group as $idx) $results[$idx]['issues'][] = 'Duplicate title'; }
        foreach ($description_groups as $group) if (count($group) > 1) { $duplicate_descriptions += count($group); foreach ($group as $idx) $results[$idx]['issues'][] = 'Duplicate meta description'; }
        // Check a bounded set of unique discovered link targets (internal and external).
        $link_checks = []; $link_errors = 0; $redirect_links = 0; $checked_links = 0;
        foreach (array_slice(array_keys($link_map), 0, 40) as $target) {
            // Validate HTTP(S) targets with WordPress' validator. Avoid the additional
            // FILTER_VALIDATE_URL check, which can reject URLs WordPress can safely handle.
            // wp_safe_remote_get remains the request layer and retains SSRF safeguards.
            $target_parts = wp_parse_url($target);
            $basic_valid = is_array($target_parts)
                && !empty($target_parts['host'])
                && isset($target_parts['scheme'])
                && in_array(strtolower($target_parts['scheme']), ['http', 'https'], true);
            $validated_target = $basic_valid && function_exists('wp_http_validate_url')
                ? wp_http_validate_url($target)
                : ($basic_valid ? $target : false);
            if (!$basic_valid) {
                $resp = new WP_Error('myseo_invalid_link_url', 'Invalid URL: expected an HTTP(S) URL with a host.');
            } elseif (!$validated_target) {
                $resp = new WP_Error('myseo_url_blocked', 'URL rejected by WordPress URL validation (may be unsafe or restricted).');
            } else {
                $resp = wp_safe_remote_get($validated_target, [
                    'timeout' => 5,
                    'redirection' => 0,
                    'limit_response_size' => 1000,
                    'headers' => ['User-Agent' => 'MySEO-Crawler/2.3.3 (+WordPress SEO audit)'],
                ]);
            }
            $link_status = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
            $link_error = is_wp_error($resp) ? $resp->get_error_message() : '';
            $is_redirect = $link_status >= 300 && $link_status < 400;
            if ($link_status === 0 || $link_status >= 400) $link_errors++;
            if ($is_redirect) $redirect_links++;
            $checked_links++;
            $location = is_wp_error($resp) ? '' : (string) wp_remote_retrieve_header($resp, 'location');
            $redirect_to = $location ? $this->resolve($location, $target) : '';
            $sources = array_values($link_map[$target]);
            $link_checks[] = ['url'=>$target,'status'=>$link_status,'error'=>$link_error,'redirect'=>$is_redirect,'redirect_to'=>$redirect_to,'sources'=>$sources,'source_count'=>count($sources)];
        }
        // Attach simple broken-link issue counts to page findings, without treating redirects as broken.
        foreach ($link_checks as $lc) {
            if ($lc['status'] === 0 || $lc['status'] >= 400) {
                foreach ($lc['sources'] as $src) {
                    foreach ($results as &$page) { if ($page['url'] === $src['source']) $page['issues'][] = 'Broken link: '.$lc['url']; }
                    unset($page);
                }
            }
        }
        $summary = ['pages_crawled'=>count($results),'issues'=>0,'missing_titles'=>0,'missing_descriptions'=>0,'http_errors'=>0,'noindex'=>0,'duplicate_titles'=>$duplicate_titles,'duplicate_descriptions'=>$duplicate_descriptions,'links_checked'=>$checked_links,'broken_links'=>$link_errors,'redirect_links'=>$redirect_links];
        foreach ($results as $r) { $summary['issues'] += count($r['issues']); if (in_array('Missing title',$r['issues'],true)) $summary['missing_titles']++; if (in_array('Missing meta description',$r['issues'],true)) $summary['missing_descriptions']++; if ($r['status'] >= 400 || $r['status']===0) $summary['http_errors']++; if ($r['noindex']) $summary['noindex']++; }
        update_option('myseo_last_crawl', ['time'=>current_time('mysql'),'summary'=>$summary,'results'=>$results,'link_checks'=>$link_checks], false);
        return ['summary'=>$summary,'results'=>$results,'link_checks'=>$link_checks,'crawl_time'=>current_time('mysql')];
    }
    private function normalize(string $url): string { $url=trim($url); if (!$url) return ''; $url=esc_url_raw($url); $p=wp_parse_url($url); if (!$p || empty($p['scheme']) || !in_array(strtolower($p['scheme']),['http','https'],true) || empty($p['host'])) return ''; $url=preg_replace('/#.*$/','',$url); return rtrim($url,'/') ?: $url; }
    private function resolve(string $href,string $base): string { $href=trim(html_entity_decode($href,ENT_QUOTES|ENT_HTML5,'UTF-8')); if ($href===''||preg_match('/^(mailto:|tel:|javascript:|data:)/i',$href)) return ''; if (strpos($href,'//')===0) { $scheme=wp_parse_url($base,PHP_URL_SCHEME); $href=$scheme.':'.$href; } elseif (!preg_match('/^https?:\/\//i',$href)) { $bp=wp_parse_url($base); $origin=($bp['scheme']??'https').'://'.($bp['host']??''); if (isset($bp['port'])) $origin.=':'.$bp['port']; if (strpos($href,'/')===0) $href=$origin.$href; else { $path=$bp['path']??'/'; $dir=substr($path,0,strrpos($path,'/')+1); $href=$origin.$dir.$href; } } return $this->normalize($href); }
}
