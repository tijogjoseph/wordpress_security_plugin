<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Meta_Manager
{
    public const META_TITLE = '_myseo_title';
    public const META_DESCRIPTION = '_myseo_description';
    public const META_KEYPHRASE = '_myseo_focus_keyphrase';
    public const META_RELATED_KEYPHRASES = '_myseo_related_keyphrases';
    public const META_SOCIAL_TITLE = '_myseo_social_title';
    public const META_SOCIAL_DESCRIPTION = '_myseo_social_description';
    public const META_SOCIAL_IMAGE = '_myseo_social_image';

    public function register_hooks(): void
    {
        add_action('add_meta_boxes', [$this, 'register_meta_box']);
        add_action('save_post', [$this, 'save_meta_box'], 10, 2);
        add_filter('pre_get_document_title', [$this, 'filter_document_title'], 20);
        add_action('wp_head', [$this, 'render_meta_description'], 2);
        add_action('wp_head', [$this, 'render_social_metadata'], 3);

        add_action('init', [$this, 'register_meta_for_rest']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_editor_assets']);
    }

    public function enqueue_editor_assets(string $hook): void
    {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) { return; }
        $screen = get_current_screen();
        if (!$screen || $screen->base !== 'post') { return; }
        wp_enqueue_script('myseo-keyphrase-analysis', MYSEO_URL . 'assets/js/myseo-keyphrase.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_style('myseo-admin', MYSEO_URL . 'assets/css/myseo-admin.css', [], MYSEO_VERSION);
        wp_enqueue_script('myseo-heading-analysis', MYSEO_URL . 'assets/js/myseo-heading.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-readability-analysis', MYSEO_URL . 'assets/js/myseo-readability.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-image-analysis', MYSEO_URL . 'assets/js/myseo-image.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-seo-score', MYSEO_URL . 'assets/js/myseo-seo-score.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-link-suggestions', MYSEO_URL . 'assets/js/myseo-link-suggestions.js', ['wp-api-fetch', 'wp-data', 'wp-blocks', 'wp-block-editor'], MYSEO_VERSION, true);
        wp_enqueue_media();
        wp_enqueue_script('myseo-social-preview', MYSEO_URL . 'assets/js/myseo-social-preview.js', ['jquery'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-serp-preview', MYSEO_URL . 'assets/js/myseo-serp-preview.js', ['jquery'], MYSEO_VERSION, true);
        wp_localize_script('myseo-link-suggestions', 'myseoLinkSuggestions', [
            'restPath' => '/myseo/v1/link-suggestions',
            'editPostUrl' => admin_url('post.php'),
        ]);
        wp_localize_script('myseo-image-analysis', 'myseoImageSettings', [
            'mediaEditBase' => admin_url('post.php'),
        ]);
    }

    public function register_meta_for_rest(): void
    {
        $post_types = get_post_types(['public' => true], 'names');

        foreach ($post_types as $post_type) {
            register_post_meta($post_type, self::META_TITLE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_DESCRIPTION, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_textarea_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_KEYPHRASE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);
            register_post_meta($post_type, self::META_RELATED_KEYPHRASES, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_SOCIAL_TITLE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_SOCIAL_DESCRIPTION, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_textarea_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_SOCIAL_IMAGE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'esc_url_raw',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);
        }
    }

    public function register_meta_box(): void
    {
        $post_types = get_post_types(['public' => true], 'names');

        foreach ($post_types as $post_type) {
            add_meta_box(
                'myseo-seo-fields',
                __('MySEO – Search appearance', 'myseo'),
                [$this, 'render_meta_box'],
                $post_type,
                'normal',
                'high'
            );
        }
    }

    public function render_meta_box(WP_Post $post): void
    {
        wp_nonce_field('myseo_save_post_meta', 'myseo_nonce');

        $seo_title = get_post_meta($post->ID, self::META_TITLE, true);
        $description = get_post_meta($post->ID, self::META_DESCRIPTION, true);
        $keyphrase = get_post_meta($post->ID, self::META_KEYPHRASE, true);
        $related_keyphrases = get_post_meta($post->ID, self::META_RELATED_KEYPHRASES, true);
        ?>
        <p>
            <label for="myseo_title"><strong><?php esc_html_e('SEO title', 'myseo'); ?></strong></label>
            <input type="text" id="myseo_title" name="myseo_title" class="widefat"
                   maxlength="200" value="<?php echo esc_attr($seo_title); ?>"
                   placeholder="<?php echo esc_attr(get_the_title($post)); ?>">
            <span class="description"><?php esc_html_e('Leave blank to use the WordPress post title.', 'myseo'); ?></span>
        </p>
        <p>
            <label for="myseo_description"><strong><?php esc_html_e('Meta description', 'myseo'); ?></strong></label>
            <textarea id="myseo_description" name="myseo_description" class="widefat"
                      rows="3" maxlength="320"><?php echo esc_textarea($description); ?></textarea>
            <span class="description"><?php esc_html_e('A concise summary of this page. Suggested working range: around 150–160 characters; this is not a Google ranking rule.', 'myseo'); ?></span>
        </p>
        <p>
            <label for="myseo_keyphrase"><strong><?php esc_html_e('Focus keyphrase', 'myseo'); ?></strong></label>
            <input type="text" id="myseo_keyphrase" name="myseo_keyphrase" class="widefat"
                   maxlength="200" value="<?php echo esc_attr($keyphrase); ?>">
            <span class="description"><?php esc_html_e('The single phrase this article is being optimized for.', 'myseo'); ?></span>
        </p>
        <p>
            <label for="myseo_related_keyphrases"><strong><?php esc_html_e('Related keyphrases', 'myseo'); ?></strong></label>
            <input type="text" id="myseo_related_keyphrases" name="myseo_related_keyphrases" class="widefat"
                   maxlength="500" value="<?php echo esc_attr(is_array($related_keyphrases) ? implode(', ', $related_keyphrases) : $related_keyphrases); ?>"
                   placeholder="<?php esc_attr_e('e.g. machine learning, neural networks, deep learning', 'myseo'); ?>">
            <span class="description"><?php esc_html_e('Enter up to 5 related phrases separated by commas. Use natural variations; do not repeat keywords unnaturally.', 'myseo'); ?></span>
        </p>
        <div class="myseo-serp-preview" id="myseo-serp-preview"
             data-default-title="<?php echo esc_attr(get_the_title($post)); ?>"
             data-page-url="<?php echo esc_url(get_permalink($post)); ?>">
            <div class="myseo-preview-heading">
                <div>
                    <h4><?php esc_html_e('Search appearance preview', 'myseo'); ?></h4>
                    <p class="description"><?php esc_html_e('Estimated preview based on your current metadata. Search engines may display a different title or snippet.', 'myseo'); ?></p>
                </div>
                <div class="myseo-preview-tabs" role="group" aria-label="<?php esc_attr_e('Search preview device', 'myseo'); ?>">
                    <button type="button" class="button is-active" data-preview-device="desktop" aria-pressed="true"><?php esc_html_e('Desktop', 'myseo'); ?></button>
                    <button type="button" class="button" data-preview-device="mobile" aria-pressed="false"><?php esc_html_e('Mobile', 'myseo'); ?></button>
                </div>
            </div>
            <div class="myseo-google-preview is-desktop" id="myseo-google-preview">
                <div class="myseo-google-site">
                    <span class="myseo-google-favicon" aria-hidden="true"><?php echo esc_html(mb_substr(get_bloginfo('name'), 0, 1)); ?></span>
                    <span>
                        <strong><?php echo esc_html(get_bloginfo('name')); ?></strong>
                        <small id="myseo-preview-breadcrumb"><?php echo esc_html(wp_parse_url(get_permalink($post), PHP_URL_HOST) . wp_parse_url(get_permalink($post), PHP_URL_PATH)); ?></small>
                    </span>
                </div>
                <a href="#" class="myseo-google-title" id="myseo-preview-title" tabindex="-1"><?php echo esc_html($seo_title !== '' ? $seo_title : get_the_title($post)); ?></a>
                <p class="myseo-google-description" id="myseo-preview-description"><?php echo esc_html($description !== '' ? $description : wp_trim_words(wp_strip_all_tags(get_the_excerpt($post)), 30, '')); ?></p>
                <div class="myseo-preview-measurements">
                    <span id="myseo-title-measure">Title: —</span>
                    <span id="myseo-description-measure">Description: —</span>
                </div>
            </div>
            <p class="myseo-preview-disclaimer"><?php esc_html_e('This is an approximate editorial preview, not a Google result simulator or ranking prediction. Pixel widths are estimates and actual snippets can vary by query, device and search engine.', 'myseo'); ?></p>
        </div>
        <div class="myseo-social-fields">
            <h4><?php esc_html_e('Social sharing appearance', 'myseo'); ?></h4>
            <p class="description"><?php esc_html_e('Optional overrides for Open Graph and Twitter/X sharing cards. Blank fields use your SEO metadata and featured image as fallbacks.', 'myseo'); ?></p>
            <p>
                <label for="myseo_social_title"><strong><?php esc_html_e('Social title', 'myseo'); ?></strong></label>
                <input type="text" id="myseo_social_title" name="myseo_social_title" class="widefat"
                       maxlength="200" value="<?php echo esc_attr(get_post_meta($post->ID, self::META_SOCIAL_TITLE, true)); ?>">
            </p>
            <p>
                <label for="myseo_social_description"><strong><?php esc_html_e('Social description', 'myseo'); ?></strong></label>
                <textarea id="myseo_social_description" name="myseo_social_description" class="widefat"
                          rows="3" maxlength="320"><?php echo esc_textarea(get_post_meta($post->ID, self::META_SOCIAL_DESCRIPTION, true)); ?></textarea>
            </p>
            <p>
                <label for="myseo_social_image"><strong><?php esc_html_e('Social sharing image URL', 'myseo'); ?></strong></label>
                <input type="url" id="myseo_social_image" name="myseo_social_image" class="widefat"
                       value="<?php echo esc_attr(get_post_meta($post->ID, self::META_SOCIAL_IMAGE, true)); ?>"
                       placeholder="<?php esc_attr_e('Select an image or enter its URL', 'myseo'); ?>">
                <button type="button" class="button" id="myseo_select_social_image"><?php esc_html_e('Select image', 'myseo'); ?></button>
                <button type="button" class="button" id="myseo_remove_social_image"><?php esc_html_e('Remove image', 'myseo'); ?></button>
                <span class="description"><?php esc_html_e('Recommended: a landscape image suitable for social sharing. The featured image is used when this is blank.', 'myseo'); ?></span>
                <div id="myseo_social_image_preview" class="myseo-social-image-preview">
                    <?php $social_image = get_post_meta($post->ID, self::META_SOCIAL_IMAGE, true); ?>
                    <?php if ($social_image) : ?>
                        <img src="<?php echo esc_url($social_image); ?>" alt="" style="max-width:320px;height:auto;">
                    <?php endif; ?>
                </div>
            </p>
        </div>
        <div class="myseo-analysis myseo-score-panel">
            <h4><?php esc_html_e('Content SEO checklist score', 'myseo'); ?></h4>
            <div id="myseo-seo-score" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Enter a focus keyphrase and add content to calculate your checklist score.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis myseo-link-suggestions-panel">
            <h4><?php esc_html_e('Internal linking suggestions', 'myseo'); ?></h4>
            <p class="description"><?php esc_html_e('Find related published content and choose a link to insert into this article.', 'myseo'); ?></p>
            <div id="myseo-link-suggestions" data-post-id="<?php echo esc_attr((string) $post->ID); ?>" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Enter a focus keyphrase to find related published content.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Readability analysis', 'myseo'); ?></h4>
            <div id="myseo-readability-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add article content to see readability suggestions.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Heading structure analysis', 'myseo'); ?></h4>
            <div id="myseo-heading-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add headings to your article to see the structure analysis.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Image SEO analysis', 'myseo'); ?></h4>
            <div id="myseo-image-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add images to your article to check their alternative text.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Focus keyphrase recommendations', 'myseo'); ?></h4>
            <div id="myseo-keyphrase-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Enter a focus keyphrase to see recommendations.', 'myseo'); ?></p>
            </div>
        </div>
        <?php
    }

    public function save_meta_box(int $post_id, WP_Post $post): void
    {
        if (
            !isset($_POST['myseo_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['myseo_nonce'])), 'myseo_save_post_meta')
        ) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
            return;
        }

        $fields = [
            'myseo_title' => self::META_TITLE,
            'myseo_description' => self::META_DESCRIPTION,
            'myseo_keyphrase' => self::META_KEYPHRASE,
        ];

        foreach ($fields as $request_key => $meta_key) {
            if (!isset($_POST[$request_key])) {
                continue;
            }

            $value = sanitize_text_field(wp_unslash($_POST[$request_key]));

            if ($value === '') {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, $value);
            }
        }

        if (isset($_POST['myseo_related_keyphrases'])) {
            $raw_related = sanitize_text_field(wp_unslash($_POST['myseo_related_keyphrases']));
            $parts = preg_split('/[,;\\n]+/', $raw_related, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            $parts = array_slice(array_values(array_unique(array_filter(array_map('trim', $parts)))), 0, 5);
            $related_value = implode(', ', $parts);
            if ($related_value === '') {
                delete_post_meta($post_id, self::META_RELATED_KEYPHRASES);
            } else {
                update_post_meta($post_id, self::META_RELATED_KEYPHRASES, $related_value);
            }
        }

        $social_fields = [
            'myseo_social_title' => [self::META_SOCIAL_TITLE, 'sanitize_text_field'],
            'myseo_social_description' => [self::META_SOCIAL_DESCRIPTION, 'sanitize_textarea_field'],
            'myseo_social_image' => [self::META_SOCIAL_IMAGE, 'esc_url_raw'],
        ];

        foreach ($social_fields as $request_key => $config) {
            if (!isset($_POST[$request_key])) {
                continue;
            }
            $raw = wp_unslash($_POST[$request_key]);
            $value = call_user_func($config[1], $raw);
            if ($value === '') {
                delete_post_meta($post_id, $config[0]);
            } else {
                update_post_meta($post_id, $config[0], $value);
            }
        }
    }

    public function filter_document_title(string $title): string
    {
        if (is_admin()) {
            return $title;
        }

        $settings = $this->get_global_settings();

        if (is_front_page()) {
            $front_page_id = $this->get_front_page_id();
            if ($front_page_id) {
                $page_seo_title = trim((string) get_post_meta($front_page_id, self::META_TITLE, true));
                if ($page_seo_title !== '') {
                    return $page_seo_title;
                }
            }

            $home_title = trim((string) $settings['homepage_title']);
            if ($home_title !== '') {
                return $home_title;
            }

            if ($front_page_id) {
                return $this->apply_title_template(
                    (string) $settings['title_template'],
                    get_the_title($front_page_id),
                    get_bloginfo('description')
                );
            }

            return $this->apply_title_template(
                (string) $settings['title_template'],
                get_bloginfo('name'),
                get_bloginfo('description')
            );
        }

        if (!is_singular()) {
            return $title;
        }

        $post_id = get_queried_object_id();
        if (!$post_id) {
            return $title;
        }

        $custom_title = get_post_meta($post_id, self::META_TITLE, true);
        if ($custom_title !== '') {
            return $custom_title;
        }

        return $this->apply_title_template(
            (string) $settings['title_template'],
            get_the_title($post_id),
            get_bloginfo('description')
        );
    }

    private function get_front_page_id(): int
    {
        if (get_option('show_on_front') !== 'page') {
            return 0;
        }

        $front_page_id = absint(get_option('page_on_front'));
        return $front_page_id > 0 ? $front_page_id : 0;
    }

    private function get_global_settings(): array
    {
        $settings = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
            'title_template' => '{title} | {site_name}',
            'description_template' => '{excerpt}',
            'homepage_title' => '',
            'homepage_description' => '',
            'social_default_title' => '',
            'social_default_description' => '',
            'social_default_image' => '',
        ]);
        if (trim((string) $settings['title_template']) === '') {
            $settings['title_template'] = '{title} | {site_name}';
        }
        if (trim((string) $settings['description_template']) === '') {
            $settings['description_template'] = '{excerpt}';
        }
        return $settings;
    }

    private function apply_title_template(string $template, string $title, string $tagline = ''): string
    {
        $output = strtr($template, [
            '{title}' => $title,
            '{site_name}' => get_bloginfo('name'),
            '{tagline}' => $tagline,
        ]);
        return trim(preg_replace('/\s*\|\s*\|\s*/', ' | ', $output), " \t\n\r\0\x0B|");
    }

    private function get_post_description(int $post_id, string $template): string
    {
        $custom = trim((string) get_post_meta($post_id, self::META_DESCRIPTION, true));
        if ($custom !== '') {
            return $custom;
        }
        $excerpt = get_the_excerpt($post_id);
        $excerpt = wp_trim_words(wp_strip_all_tags($excerpt), 30, '');
        $content = wp_trim_words(wp_strip_all_tags(strip_shortcodes((string) get_post_field('post_content', $post_id))), 30, '');
        $source = $excerpt !== '' ? $excerpt : $content;
        return trim(strtr($template, [
            '{excerpt}' => $source,
            '{title}' => get_the_title($post_id),
            '{site_name}' => get_bloginfo('name'),
        ]));
    }

    public function render_meta_description(): void
    {
        if (is_admin()) {
            return;
        }

        $settings = $this->get_global_settings();
        if (empty($settings['enable_meta_output'])) {
            return;
        }

        $description = '';
        if (is_front_page()) {
            $front_page_id = $this->get_front_page_id();
            if ($front_page_id) {
                $description = trim((string) get_post_meta($front_page_id, self::META_DESCRIPTION, true));
            }

            if ($description === '') {
                $description = trim((string) $settings['homepage_description']);
            }

            if ($description === '' && $front_page_id) {
                $description = $this->get_post_description($front_page_id, (string) $settings['description_template']);
            }

            if ($description === '') {
                $description = wp_trim_words(wp_strip_all_tags(get_bloginfo('description')), 30, '');
            }
        } elseif (is_singular()) {
            $post_id = get_queried_object_id();
            if ($post_id) {
                $description = $this->get_post_description($post_id, (string) $settings['description_template']);
            }
        }

        if ($description !== '') {
            printf("<meta name=\"description\" content=\"%s\" />\n", esc_attr($description));
        }
    }

    /**
     * Render Open Graph and Twitter/X metadata with per-field fallbacks.
     * Avoid duplicate social metadata when a supported SEO plugin is active.
     */
    public function render_social_metadata(): void
    {
        if (is_admin() || (!is_singular() && !is_front_page())) {
            return;
        }

        if ($this->has_supported_seo_plugin()) {
            return;
        }

        $settings = $this->get_global_settings();
        $is_home = is_front_page();
        $post_id = $is_home ? $this->get_front_page_id() : get_queried_object_id();
        $post = $post_id ? get_post($post_id) : null;
        if (!$is_home && !$post) {
            return;
        }
        if ($is_home && $post_id && !$post) {
            $post_id = 0;
        }

        $social_title = $post_id ? trim((string) get_post_meta($post_id, self::META_SOCIAL_TITLE, true)) : '';
        $seo_title = $post_id ? trim((string) get_post_meta($post_id, self::META_TITLE, true)) : '';
        if ($social_title !== '') {
            $title = $social_title;
        } elseif ($seo_title !== '') {
            $title = $seo_title;
        } elseif ($is_home && trim((string) $settings['homepage_title']) !== '') {
            $title = (string) $settings['homepage_title'];
        } elseif (trim((string) $settings['social_default_title']) !== '') {
            $title = (string) $settings['social_default_title'];
        } else {
            $title = $post ? get_the_title($post) : get_bloginfo('name');
        }

        $social_description = $post_id ? trim((string) get_post_meta($post_id, self::META_SOCIAL_DESCRIPTION, true)) : '';
        $seo_description = $post_id ? trim((string) get_post_meta($post_id, self::META_DESCRIPTION, true)) : '';
        if ($social_description !== '') {
            $description = $social_description;
        } elseif ($seo_description !== '') {
            $description = $seo_description;
        } elseif ($is_home && trim((string) $settings['homepage_description']) !== '') {
            $description = (string) $settings['homepage_description'];
        } elseif (trim((string) $settings['social_default_description']) !== '') {
            $description = (string) $settings['social_default_description'];
        } elseif ($post_id) {
            $description = $this->get_post_description($post_id, (string) $settings['description_template']);
        } else {
            $description = get_bloginfo('description');
        }

        $image = $post_id ? get_post_meta($post_id, self::META_SOCIAL_IMAGE, true) : '';
        if ($image === '' && $post_id) {
            $thumbnail_id = get_post_thumbnail_id($post_id);
            if ($thumbnail_id) {
                $image_data = wp_get_attachment_image_src($thumbnail_id, 'full');
                $image = $image_data ? $image_data[0] : '';
            }
        }
        if ($image === '') {
            $image = (string) $settings['social_default_image'];
        }

        $url = $is_home ? home_url('/') : get_permalink($post_id);
        $site_name = get_bloginfo('name');
        $type = (!$is_home && get_post_type($post_id) === 'post') ? 'article' : 'website';

        $tags = [
            'og:locale' => get_locale(),
            'og:type' => $type,
            'og:site_name' => $site_name,
            'og:title' => $title,
            'og:url' => $url,
            'twitter:card' => $image !== '' ? 'summary_large_image' : 'summary',
            'twitter:title' => $title,
        ];

        if ($description !== '') {
            $tags['og:description'] = $description;
            $tags['twitter:description'] = $description;
        }
        if ($image !== '') {
            $tags['og:image'] = $image;
            $tags['twitter:image'] = $image;
        }

        foreach ($tags as $property => $content) {
            if ($content === '') {
                continue;
            }
            $attribute = str_starts_with($property, 'og:') ? 'property' : 'name';
            printf(
                "<meta %s=\"%s\" content=\"%s\" />\n",
                esc_attr($attribute),
                esc_attr($property),
                esc_attr($content)
            );
        }
    }

    private function has_supported_seo_plugin(): bool
    {
        return defined('WPSEO_VERSION')
            || defined('RANK_MATH_VERSION')
            || defined('AIOSEO_VERSION')
            || defined('SEOPRESS_VERSION')
            || defined('SLIM_SEO_VERSION');
    }

}
