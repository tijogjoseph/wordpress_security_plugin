<?php
if (!defined('ABSPATH')) { exit; }

/** Rule-based keyphrase checks. These are editorial hints, not ranking predictions. */
final class MySEO_Keyphrase_Analyzer
{
    public function analyze(int $post_id, string $keyphrase): array
    {
        $post = get_post($post_id);
        $phrase = $this->normalize($keyphrase);
        if (!$post || $phrase === '') { return []; }

        $content = (string) $post->post_content;
        $plain = $this->plain_text($content);
        $title = (string) get_post_meta($post_id, MySEO_Meta_Manager::META_TITLE, true);
        if ($title === '') { $title = (string) get_the_title($post_id); }
        $description = (string) get_post_meta($post_id, MySEO_Meta_Manager::META_DESCRIPTION, true);
        if ($description === '') { $description = (string) get_the_excerpt($post_id); }

        $intro = implode(' ', array_slice(preg_split('/\s+/u', $plain) ?: [], 0, 60));
        $headings = implode(' ', $this->extract_headings($content));
        $slug = str_replace('-', ' ', (string) $post->post_name);
        $count = $this->count_occurrences($plain, $phrase);
        $words = preg_match_all('/[\p{L}\p{N}]+/u', $plain, $matches) ?: 0;

        return [
            'title' => $this->result($this->contains($title, $phrase), 'Keyphrase found in SEO title.', 'Add the keyphrase to the SEO title where natural.'),
            'description' => $this->result($this->contains($description, $phrase), 'Keyphrase found in meta description.', 'Consider including the keyphrase in the meta description.'),
            'slug' => $this->result($this->contains($slug, $phrase), 'Keyphrase found in URL slug.', 'Consider including the keyphrase in the URL slug, if appropriate.'),
            'introduction' => $this->result($this->contains($intro, $phrase), 'Keyphrase found near the beginning.', 'Consider mentioning the keyphrase naturally near the beginning.'),
            'headings' => $this->result($headings !== '' && $this->contains($headings, $phrase), 'Keyphrase found in a heading.', 'Consider using the keyphrase or a natural variation in a relevant heading.'),
            'content' => $this->result($count > 0, sprintf('Keyphrase appears %d time(s) in the article body.', $count), 'Keyphrase not found in the article body. Use it naturally if relevant.'),
            'length' => ['status' => $words >= 100 ? 'good' : 'info', 'message' => sprintf('Approximately %d words. There is no universal ideal word count.', $words)],
        ];
    }

    private function normalize(string $text): string
    {
        $text = strtolower(wp_strip_all_tags($text));
        $text = preg_replace('/[^\p{L}\p{N}\s-]/u', ' ', $text) ?? $text;
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }

    private function plain_text(string $html): string
    {
        $html = strip_shortcodes($html);
        $html = preg_replace('/<!--.*?-->/s', ' ', $html) ?? $html;
        return $this->normalize(wp_strip_all_tags($html));
    }

    private function contains(string $text, string $phrase): bool
    {
        $text = $this->normalize($text);
        return $text !== '' && $phrase !== ''
            && preg_match('/(?<![\p{L}\p{N}])' . preg_quote($phrase, '/') . '(?![\p{L}\p{N}])/u', $text) === 1;
    }

    private function count_occurrences(string $text, string $phrase): int
    {
        if ($text === '' || $phrase === '') { return 0; }
        return preg_match_all('/(?<![\p{L}\p{N}])' . preg_quote($phrase, '/') . '(?![\p{L}\p{N}])/u', $text, $matches) ?: 0;
    }

    private function extract_headings(string $html): array
    {
        if (!class_exists('DOMDocument')) { return []; }
        $items = [];
        $previous = libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        if ($loaded) {
            foreach ($dom->getElementsByTagName('*') as $node) {
                if (preg_match('/^h[1-6]$/i', $node->nodeName)) {
                    $value = trim($node->textContent);
                    if ($value !== '') { $items[] = $value; }
                }
            }
        }
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        return $items;
    }

    private function result(bool $ok, string $success, string $advice): array
    {
        return ['status' => $ok ? 'good' : 'needs_work', 'message' => $ok ? $success : $advice];
    }
}
