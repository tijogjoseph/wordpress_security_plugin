<?php
/**
 * Plugin Name: MySEO
 * Description: A lightweight WordPress SEO toolkit with a React-powered admin dashboard, metadata, content analysis, image checks, and basic structured data.
 * Version: 2.3.3
 * Requires at least: 6.2
 * Requires PHP: 8.0
 * Author: MySEO
 * Text Domain: myseo
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MYSEO_VERSION', '2.3.3');
define('MYSEO_FILE', __FILE__);
define('MYSEO_PATH', plugin_dir_path(__FILE__));
define('MYSEO_URL', plugin_dir_url(__FILE__));

require_once MYSEO_PATH . 'includes/class-myseo-activator.php';
require_once MYSEO_PATH . 'includes/class-myseo-meta-manager.php';
require_once MYSEO_PATH . 'includes/class-myseo-keyphrase-analyzer.php';
require_once MYSEO_PATH . 'includes/class-myseo-readability-analyzer.php';
require_once MYSEO_PATH . 'includes/class-myseo-heading-analyzer.php';
require_once MYSEO_PATH . 'includes/class-myseo-image-analyzer.php';
require_once MYSEO_PATH . 'includes/class-myseo-schema-manager.php';
require_once MYSEO_PATH . 'includes/class-myseo-content-auditor.php';
require_once MYSEO_PATH . 'includes/class-myseo-content-health-auditor.php';
require_once MYSEO_PATH . 'includes/class-myseo-site-image-auditor.php';
require_once MYSEO_PATH . 'includes/class-myseo-technical-auditor.php';
require_once MYSEO_PATH . 'includes/class-myseo-pro-crawler.php';
require_once MYSEO_PATH . 'includes/class-myseo-admin.php';
require_once MYSEO_PATH . 'includes/class-myseo-plugin.php';

register_activation_hook(__FILE__, ['MySEO_Activator', 'activate']);

add_action('plugins_loaded', static function () {
    MySEO_Plugin::instance()->init();
});
