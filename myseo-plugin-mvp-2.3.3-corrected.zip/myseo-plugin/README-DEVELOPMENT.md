# MySEO MVP – development notes

## Current starter scope
- WordPress plugin bootstrap and activation.
- OOP classes with a small, explicit initialization flow.
- Post editor fields for SEO title, meta description, and one focus keyphrase.
- REST exposure for registered post metadata.
- Live editor-side focus keyphrase checks for title, description, slug, introduction, headings, and article body.
- PHP readability analyzer service and live editor-side readability recommendations.
- PHP heading structure analyzer and live editor-side heading outline/issues.
- PHP image analyzer and live editor-side image alt audit, including attachment edit links when the image ID is available.
- JSON-LD schema manager for BlogPosting/WebPage, using post metadata, dates, author, featured image, site name, and optional site logo.
- Schema output toggle and conservative duplicate avoidance for common SEO plugins.
- Frontend title filtering and meta description output.
- React-powered admin dashboard using the WordPress wp.element runtime (no separate build toolchain).
- Capability-protected REST endpoints for dashboard metrics and MySEO settings.
- Dashboard navigation with clearly marked roadmap placeholders for future site-wide audit modules.
- Paginated site-wide Content Audit with summary counts for missing custom MySEO metadata and duplicate custom SEO title/description groups.

## Local setup
1. Copy `myseo-plugin` into `wp-content/plugins/`.
2. Activate it in WordPress.
3. Edit a post/page and use the MySEO meta box.
4. View the published page source to inspect the title and description.

## Important next steps
1. Add automated tests for REST permissions, dashboard metrics, and settings persistence.
2. Add compatibility arbitration so MySEO does not duplicate output from another SEO plugin.
3. Add Gutenberg sidebar integration.
4. Add automated tests for keyphrase, readability, heading, and image analysis.
5. Expand schema coverage only after testing the current Article/WebPage output and duplicate-schema safeguards.
6. Add nonce/capability-protected REST endpoints for analysis.

## Design notes
- Uses WordPress post meta and options; no custom tables in this MVP foundation.
- Does not delete SEO metadata on uninstall.
- Does not call external services.
- The focus keyphrase is stored but is not yet analyzed.
- Structured data generation is not yet implemented.


## Image analysis notes
- Missing `alt` attributes are flagged as issues.
- Empty `alt=""` values are shown for review, not automatically treated as errors; they are appropriate for decorative images.
- The editor-side scan reads image tags in the post content. Theme-generated images, shortcode output, and some dynamic block output are not covered.
- Media Library edit links are shown only when a WordPress attachment ID can be identified from the image class or `data-id`.


## Structured data notes
- Standard WordPress posts emit `BlogPosting`; other singular published content emits `WebPage`.
- Uses SEO title/description metadata when available, with WordPress title/excerpt fallbacks.
- Includes publication/modification dates, language, page URL, post author (for posts), featured image, and site publisher/logo where available.
- Output is controlled by the **Structured data (JSON-LD)** setting on the MySEO dashboard.
- MySEO skips its schema output when Yoast SEO, Rank Math, All in One SEO, SEOPress, or Slim SEO is active. This is a conservative safeguard, not a universal schema-conflict detector.
- Developers can customize the schema array with the `myseo_schema_data` filter.
- Validate output on a staging site with Google's Rich Results Test and Schema.org Validator. Structured data does not guarantee rich-result display or improved rankings.


## Dashboard UI (v0.7.0)
- Admin page is mounted into `#myseo-dashboard-root` and rendered with WordPress `wp.element`.
- Dashboard JavaScript and CSS are enqueued only on the MySEO admin screen.
- REST endpoints: `GET /wp-json/myseo/v1/dashboard`, `GET /wp-json/myseo/v1/settings`, and `POST /wp-json/myseo/v1/settings`.
- Endpoints require the `manage_options` capability; the dashboard uses the WordPress REST nonce middleware.
- Overview metrics show published post/page counts and counts of published content with saved MySEO title/description metadata.
- Settings are persisted in the existing `myseo_settings` option.
- Audit/performance navigation items are visual placeholders and do not claim to run scans or provide Search Console data yet.


## Content Audit (v0.8.0)
- REST endpoint: `GET /wp-json/myseo/v1/content-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; query arguments are sanitized and page size is capped at 50.
- Audits published public post types, with paginated content rows and global summary counts.
- Checks missing saved MySEO SEO title, meta description, and focus keyphrase values, plus duplicate non-empty custom SEO titles and descriptions.
- The audit reports missing *custom MySEO fields*. The frontend may still output WordPress title/excerpt fallbacks; blank custom fields do not necessarily mean no title/description is rendered.
- Search filters the displayed list; summary totals describe all published public content, not only the filtered search results.
- This is a metadata completeness audit, not a ranking score or Google Search Console report.


## Site-wide Image Audit (v0.9.0)
- REST endpoint: `GET /wp-json/myseo/v1/image-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; page size is capped at 50 published content records per request.
- Scans saved `post_content` for `<img>` tags across published public post types (attachments are excluded).
- Reports each image occurrence with its parent content, filename/source URL, alt attribute status, and edit links.
- Missing `alt` is an issue; `alt=""` is a review item because empty alt is appropriate for decorative images; non-empty alt is marked as set.
- Summary counts apply only to the current post batch, not the entire site. Pagination is over posts, not individual images.
- Does not scan theme templates, CSS background images, shortcode output, or dynamically rendered image markup. It does not infer alt text from Media Library attachment metadata.


## Technical SEO Audit (v1.0.0)
- REST endpoint: `GET /wp-json/myseo/v1/technical-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; scans a paginated batch of published public post types, with a maximum of 50 posts per request and 500 link occurrences processed per request.
- Site configuration checks include HTTPS in the WordPress home URL, the `blog_public` search visibility option, WordPress core sitemap support, and whether core `rel_canonical` is registered on `wp_head`.
- Content checks inspect saved anchor markup for internal links, HTTP links on HTTPS sites, and internal URLs that `url_to_postid()` cannot map to a post.
- Unresolved internal URLs are review candidates, not confirmed broken links. Archive routes, custom rewrite rules, multilingual paths, and other non-post URLs can be legitimate.
- Does not crawl rendered pages, test every URL with HTTP requests, inspect robots.txt directives, or validate the actual rendered canonical tag. Sitemap support means core sitemap generation is enabled; it does not prove external reachability or search engine submission.
- Summary counts apply to the currently displayed post batch.


## Content SEO checklist score (v1.1.0)
- Adds a live editor-side score based on ten equally weighted editorial checks: keyphrase in title, description, slug, introduction, headings and body; title length; description length; body word count; and descriptive alt text on content images.
- Score is available when a focus keyphrase is entered and updates while editing.
- The score is an editorial checklist only. It is not a Google score, ranking prediction, or guarantee of search performance.
- Length and word-count thresholds are practical editorial prompts, not universal search-engine requirements.
- Image checks inspect image markup in the editor content and cannot reliably judge whether alt text is contextually descriptive or whether an image is decorative.


## Internal linking suggestions (v1.2.0)
- REST endpoint: GET `/wp-json/myseo/v1/link-suggestions?post_id=<id>&keyphrase=<phrase>`.
- Permission is scoped to `current_user_can('edit_post', post_id)`.
- Finds related published public post types, excludes the current post, scores title matches above body matches, and returns up to eight suggestions.
- The editor UI supports inserting a linked paragraph block in Gutenberg, TinyMCE insertion in Classic Editor, or copying the URL.
- Suggestions are heuristic matches, not semantic relevance guarantees. Editors should review the context before inserting links.


## Site-wide internal link structure (v1.3.0)
- Technical audit response now includes `link_topology`.
- Scans up to 1,000 published public post-type items and up to 10,000 resolved internal-link occurrences.
- Computes incoming and outgoing links between scanned published content items.
- Lists up to 50 posts with no incoming links and up to 50 with no outgoing links.
- A link is counted only when `url_to_postid()` resolves it to another scanned published item; self-links are excluded.
- This is a saved-content analysis, not a rendered-site crawl. It excludes navigation menus, widgets, theme-generated and dynamically injected links, archives, and custom routes.
- "No incoming links" is a review candidate, not an automatic SEO error.


## v1.3.1 hotfix
- Fixed the TechnicalAudit component reading `data.link_topology` even though its loaded REST response is stored in the `result` state variable.
- All topology UI reads now safely access `result && result.link_topology`.


## Internal-link recommendation improvements (v1.4.0)
- Link suggestion REST results now include `anchor_text`, `reason`, and `already_linked`.
- Anchor text prefers the source focus keyphrase when it appears in source content, then the destination title if present in source content, then matched terms, with title fallback.
- Existing source-content anchors are resolved with `url_to_postid()` and flagged to prevent duplicate insertion.
- The editor shows the match rationale and proposed anchor text.
- Suggestions remain keyword-based heuristics and should be reviewed for contextual relevance.


## Content Health (v1.5.0)
- New `MySEO_Content_Health_Auditor` scans up to 500 published public post types.
- Signals: modified at least 365 days ago, fewer than 300 words in saved post content, and no featured image.
- REST endpoint: `GET /wp-json/myseo/v1/content-health`, protected by `manage_options`.
- Returns summary counts, up to 100 review candidates, modified date, word count, flags and edit URL.
- This is editorial triage only. It does not assess factual accuracy, search performance, rendered output, or ranking factors.
- The 300-word and 365-day thresholds are configurable in code in a future release; currently fixed heuristics.


## Social metadata (v1.6.0)
- Per-post meta keys: `_myseo_social_title`, `_myseo_social_description`, `_myseo_social_image`.
- Fields are exposed in REST for editors and saved through the existing nonce/capability-checked post meta box.
- Social image picker uses the WordPress Media Library (`wp.media`) and stores the selected image URL.
- Frontend emits Open Graph (`og:*`) and Twitter/X (`twitter:*`) tags on singular pages.
- Fallbacks: custom social values -> MySEO SEO title/description -> WordPress title/excerpt; social image -> featured image.
- Uses `summary_large_image` when an image exists, otherwise `summary`.
- Suppresses MySEO social tags when Yoast, Rank Math, AIOSEO, SEOPress or Slim SEO constants are detected. This detection is best-effort; validate plugin compatibility on the target site.
- No social preview crawler/API validation is performed by this plugin.


## SEO and social preview (v1.7.0)
- Editor preview is rendered in the existing MySEO post meta box.
- Google-style preview reads live SEO title and meta description fields; blank SEO title falls back to the post title.
- Desktop/mobile controls adjust the preview container presentation.
- Character counts and canvas-measured pixel widths are estimates, not platform guarantees.
- Social card preview reads social title/description/image with SEO metadata fallbacks; image may fall back to the editor's visible featured image.
- Preview is client-side only; no Google API, SERP scraping, crawler simulation or ranking prediction is performed.


## Social preview layouts (v1.7.1)
- Added two client-side preview layouts: compact horizontal card and large-image card.
- Compact layout remains the default to preserve v1.7.0 behavior.
- Layout switcher updates the preview only; it does not alter stored metadata or generated Open Graph/Twitter tags.
- These are approximate editorial layouts, not exact simulations of any social platform.


## Social image preview controls (v1.8.0)
- Added client-side Cover/Contain fit selector for the preview image.
- Added Center/Top/Bottom/Left/Right background-position selector.
- Controls affect only CSS presentation in the editor preview; they do not alter media metadata, saved social image URL, or frontend Open Graph/Twitter output.
- Cover may crop; Contain preserves the complete image but may leave empty space around it.


## Global metadata settings (v1.9.0)
- Stored in the existing `myseo_settings` option; no custom tables or migration.
- SEO title template tokens: `{title}`, `{site_name}`, `{tagline}`.
- Meta description fallback tokens: `{excerpt}`, `{title}`, `{site_name}`.
- Homepage title/description can be set independently.
- Social default title/description/image act as site-wide fallbacks after per-content social values; content SEO title/description and featured image are fallback sources when no global social default is configured.
- Settings REST endpoint retains `manage_options` permission and sanitizes each field.
- Frontend homepage metadata output is implemented for the WordPress front page. SEO plugin coexistence still requires testing on a site with each supported plugin.


## v1.9.1 fixes
- Settings GET endpoint returns every field used by the Settings UI, not only the two toggles.
- Settings update merges against a real defaults array.
- Empty SEO template fields normalize to the documented defaults.
- Social metadata fallback order: per-content social override > per-content SEO override > homepage/global social default > generic title/description fallback.


## Static homepage metadata (v1.9.2)
- Resolves the static front page through `show_on_front` and `page_on_front`.
- SEO document title priority: selected page SEO title, Homepage SEO title setting, global title template using the selected page title.
- Meta description priority: selected page SEO description, Homepage description setting, selected page description fallback, WordPress tagline.
- Social title priority: selected page social title, selected page SEO title, Homepage SEO title, global social title, selected page title.
- Social description priority: selected page social description, selected page SEO description, Homepage description, global social description, selected page content fallback.
- Social image priority: selected page social image, selected page featured image, global social image.
- When the site uses latest posts rather than a static page, the helper returns zero and existing homepage fallbacks remain in use.


## SEO analysis improvements (v2.0.0)
- Related keyphrases are stored in `_myseo_related_keyphrases` as a comma-separated string, limited to five entries on save.
- Related phrases are checked live against editor content and included as optional checklist coverage.
- The checklist adds a cautious focus-phrase frequency review signal. This is not a recommended density target and is not represented as a ranking factor.
- Internal-link candidate relevance weights exact phrase matches, title matches and coverage of meaningful query terms. Common stop words and very short tokens are ignored.
- All analysis remains heuristic and should be reviewed by an editor.
