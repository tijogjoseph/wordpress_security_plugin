(function ($) {
    'use strict';

    $(function () {
        var frame;
        var $field = $('#myseo_social_image');
        var $preview = $('#myseo_social_image_preview');

        $('#myseo_select_social_image').on('click', function (event) {
            event.preventDefault();
            if (frame) {
                frame.open();
                return;
            }

            frame = wp.media({
                title: 'Choose a social sharing image',
                button: { text: 'Use this image' },
                library: { type: 'image' },
                multiple: false
            });

            frame.on('select', function () {
                var attachment = frame.state().get('selection').first().toJSON();
                $field.val(attachment.url).trigger('change');
                $preview.empty().append(
                    $('<img>', {
                        src: attachment.url,
                        alt: '',
                        css: { maxWidth: '320px', height: 'auto' }
                    })
                );
            });

            frame.open();
        });

        $('#myseo_remove_social_image').on('click', function (event) {
            event.preventDefault();
            $field.val('');
            $preview.empty();
        });

        $field.on('change input', function () {
            var url = $.trim($field.val());
            if (!url) {
                $preview.empty();
                return;
            }
            if ($preview.find('img').attr('src') !== url) {
                $preview.empty().append(
                    $('<img>', {
                        src: url,
                        alt: '',
                        css: { maxWidth: '320px', height: 'auto' }
                    })
                );
            }
        });
    });
})(jQuery);
