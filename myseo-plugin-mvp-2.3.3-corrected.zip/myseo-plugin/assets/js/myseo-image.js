(function () {
    'use strict';

    function getContent() {
        if (window.wp && wp.data && wp.data.select) {
            var editor = wp.data.select('core/editor');
            if (editor && typeof editor.getEditedPostContent === 'function') {
                return editor.getEditedPostContent();
            }
        }
        var classic = document.getElementById('content');
        return classic ? classic.value : '';
    }

    function create(tag, className, text) {
        var element = document.createElement(tag);
        if (className) element.className = className;
        if (text !== undefined) element.textContent = text;
        return element;
    }

    function render() {
        var output = document.getElementById('myseo-image-results');
        if (!output) return;

        var wrapper = document.createElement('div');
        wrapper.innerHTML = getContent() || '';
        var nodes = Array.prototype.slice.call(wrapper.querySelectorAll('img'));
        var images = nodes.map(function (node, index) {
            var src = node.getAttribute('src') || node.getAttribute('data-src') || '';
            var path = src.split('?')[0].split('#')[0];
            var filename = path ? decodeURIComponent(path.split('/').pop() || '') : 'Image ' + (index + 1);
            var className = node.getAttribute('class') || '';
            var idMatch = className.match(/\bwp-image-(\d+)\b/);
            var dataId = node.getAttribute('data-id') || '';
            var attachmentId = idMatch ? idMatch[1] : (/^\d+$/.test(dataId) ? dataId : '');
            var hasAlt = node.hasAttribute('alt');
            var alt = hasAlt ? (node.getAttribute('alt') || '').trim() : '';
            return {
                filename: filename || ('Image ' + (index + 1)),
                attachmentId: attachmentId,
                hasAlt: hasAlt,
                alt: alt,
                status: !hasAlt ? 'missing_alt' : (alt === '' ? 'empty_alt' : 'good')
            };
        });

        output.textContent = '';
        var missing = images.filter(function (image) { return image.status === 'missing_alt'; }).length;
        var empty = images.filter(function (image) { return image.status === 'empty_alt'; }).length;

        var summary = create('p', 'myseo-readability-summary',
            images.length + ' image(s) found · ' + missing + ' missing alt · ' + empty + ' empty alt');
        output.appendChild(summary);

        if (!images.length) {
            output.appendChild(create('p', 'myseo-empty', 'No images were found in the current article content.'));
        } else {
            var list = create('ul', 'myseo-image-list');
            images.forEach(function (image, index) {
                var item = create('li', 'myseo-image-item myseo-image-' + image.status);
                var heading = create('div', 'myseo-image-item-heading');
                var name = create('strong', 'myseo-image-filename', image.filename);
                var statusText = image.status === 'missing_alt'
                    ? 'Missing alt attribute'
                    : (image.status === 'empty_alt' ? 'Empty alt text' : 'Alt text added');
                var status = create('span', 'myseo-image-status ' + image.status, statusText);
                heading.append(name, status);
                item.appendChild(heading);

                if (image.status === 'missing_alt') {
                    item.appendChild(create('p', 'myseo-image-guidance', 'Add concise alternative text that explains the image’s purpose or meaningful content.'));
                } else if (image.status === 'empty_alt') {
                    item.appendChild(create('p', 'myseo-image-guidance', 'An empty alt value can be correct for a decorative image. If this image conveys information, add descriptive alt text.'));
                } else {
                    item.appendChild(create('p', 'myseo-image-guidance', 'Alt: ' + image.alt));
                }

                if (image.attachmentId && window.myseoImageSettings && myseoImageSettings.mediaEditBase) {
                    var link = create('a', 'myseo-image-edit-link', 'Edit image details in Media Library');
                    var url = new URL(myseoImageSettings.mediaEditBase, window.location.href);
                    url.searchParams.set('post', image.attachmentId);
                    url.searchParams.set('action', 'edit');
                    link.href = url.toString();
                    item.appendChild(link);
                }
                list.appendChild(item);
            });
            output.appendChild(list);
        }

        output.appendChild(create('p', 'myseo-analysis-note',
            'This checks image tags present in the editor content. Images added by themes, shortcodes, or dynamic blocks may not appear here. Empty alt text is not automatically an error because decorative images should use alt="".'));
    }

    function init() {
        var classic = document.getElementById('content');
        if (classic) classic.addEventListener('input', render);

        if (window.wp && wp.data && wp.data.subscribe) {
            var pending = false;
            wp.data.subscribe(function () {
                if (pending) return;
                pending = true;
                window.setTimeout(function () {
                    pending = false;
                    render();
                }, 300);
            });
        }
        render();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
