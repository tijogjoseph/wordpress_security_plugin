(function (wp) {
    'use strict';

    if (!wp || !wp.element || !wp.apiFetch) return;

    var el = wp.element.createElement;
    var useState = wp.element.useState;
    var useEffect = wp.element.useEffect;
    var apiFetch = wp.apiFetch;
    var config = window.myseoDashboardConfig || {};
    apiFetch.use(apiFetch.createNonceMiddleware(config.nonce));

    function Icon(props) {
        return el('span', { className: 'dashicons ' + (props.name || '') + ' myseo-icon', 'aria-hidden': 'true' });
    }

    var navItems = [
        { id: 'overview', label: 'Overview', icon: 'dashicons-dashboard' },
        { id: 'content', label: 'Content Audit', icon: 'dashicons-media-document' },
        { id: 'images', label: 'Image Audit', icon: 'dashicons-format-image' },
        { id: 'technical', label: 'Technical SEO', icon: 'dashicons-admin-tools' },
        { id: 'crawler', label: 'Pro Crawler', icon: 'dashicons-search' },
        { id: 'health', label: 'Content Health', icon: 'dashicons-clock' },
        { id: 'performance', label: 'SEO Performance', icon: 'dashicons-chart-area' },
        { id: 'settings', label: 'Settings', icon: 'dashicons-admin-settings' }
    ];

    function MetricCard(props) {
        return el('div', { className: 'myseo-metric-card' },
            el('div', { className: 'myseo-metric-top' },
                el('span', { className: 'myseo-metric-label' }, props.label),
                el(Icon, { name: props.icon })
            ),
            el('div', { className: 'myseo-metric-value' }, props.value),
            el('p', { className: 'myseo-metric-help' }, props.help)
        );
    }

    function Notice(props) {
        return el('div', { className: 'myseo-notice ' + (props.type || 'info'), role: 'status' },
            el('strong', null, props.title),
            el('p', null, props.children)
        );
    }

    function Overview(props) {
        var data = props.data || {};
        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'SEO overview'),
                    el('p', null, 'A quick view of your WordPress SEO setup and content metadata.')
                ),
                el('span', { className: 'myseo-version-pill' }, 'MySEO v' + (data.version || config.version || '0.9.0'))
            ),
            data.schema_plugin_conflict ? el(Notice, {
                type: 'warning',
                title: 'Another SEO plugin is active',
                children: 'MySEO detects a supported SEO plugin. MySEO schema output is suppressed to reduce duplicate structured data.'
            }) : null,
            el('div', { className: 'myseo-metric-grid' },
                el(MetricCard, { label: 'Published content', value: number(data.published_content), icon: 'dashicons-admin-page', help: number(data.published_posts) + ' posts · ' + number(data.published_pages) + ' pages' }),
                el(MetricCard, { label: 'SEO titles configured', value: number(data.seo_titles_configured), icon: 'dashicons-editor-textcolor', help: 'Published content with a custom SEO title' }),
                el(MetricCard, { label: 'Meta descriptions configured', value: number(data.meta_descriptions_configured), icon: 'dashicons-text', help: 'Published content with a custom description' }),
                el(MetricCard, { label: 'Schema output', value: data.schema_output_enabled ? 'Enabled' : 'Disabled', icon: 'dashicons-code-standards', help: data.schema_plugin_conflict ? 'Suppressed while another SEO plugin is active' : 'Article and WebPage JSON-LD setting' })
            ),
            el('div', { className: 'myseo-content-grid' },
                el('section', { className: 'myseo-panel' },
                    el('div', { className: 'myseo-panel-heading' }, el('h2', null, 'SEO setup'), el('span', { className: 'myseo-status-dot' })),
                    el('div', { className: 'myseo-setting-row' },
                        el('span', null, 'Meta description output'),
                        el('strong', { className: data.meta_output_enabled ? 'myseo-state-on' : 'myseo-state-off' }, data.meta_output_enabled ? 'Enabled' : 'Disabled')
                    ),
                    el('div', { className: 'myseo-setting-row' },
                        el('span', null, 'Structured data output'),
                        el('strong', { className: data.schema_output_enabled ? 'myseo-state-on' : 'myseo-state-off' }, data.schema_output_enabled ? 'Enabled' : 'Disabled')
                    ),
                    el('button', { className: 'button button-primary', onClick: props.openSettings }, 'Manage settings')
                ),
                el('section', { className: 'myseo-panel' },
                    el('h2', null, 'Continue improving your site'),
                    el('p', null, 'Use the post editor for live keyphrase, readability, heading and image checks. Review published content, image alt attributes and technical SEO from the audit sections.'),
                    el('a', { className: 'button', href: config.adminUrl + 'edit.php' }, 'View posts'),
                    el('a', { className: 'button myseo-button-gap', href: config.adminUrl + 'edit.php?post_type=page' }, 'View pages')
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Dashboard counts are based on published WordPress content and saved MySEO metadata. This is not an SEO score or a Google ranking report.')
        );
    }

    function ContentAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedSearchState = useState('');
        var appliedSearch = appliedSearchState[0], setAppliedSearch = appliedSearchState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            var path = '/myseo/v1/content-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '');
            apiFetch({ path: path }).then(function (data) {
                setResult(data);
                setPage(nextPage);
            }).catch(function (err) {
                setError(err && err.message ? err.message : 'Unable to load content audit.');
            }).finally(function () { setLoading(false); });
        }

        useEffect(function () { load(1, ''); }, []);

        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var labels = {
            missing_seo_title: 'Missing SEO title',
            missing_meta_description: 'Missing meta description',
            missing_focus_keyphrase: 'Missing focus keyphrase',
            duplicate_seo_title: 'Duplicate SEO title',
            duplicate_meta_description: 'Duplicate meta description'
        };

        function issueBadges(issues) {
            if (!issues || !issues.length) {
                return el('span', { className: 'myseo-audit-clean' }, 'No field issues');
            }
            return el('div', { className: 'myseo-audit-issue-list' }, issues.map(function (issue) {
                return el('span', { key: issue, className: 'myseo-audit-issue' }, labels[issue] || issue);
            }));
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Content audit'),
                    el('p', null, 'Review saved MySEO metadata across published public content.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, appliedSearch); } }, 'Refresh audit')
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Published content', value: number(summary.total_content), icon: 'dashicons-admin-page', help: 'All published public post types' }),
                el(MetricCard, { label: 'Missing SEO titles', value: number(summary.missing_seo_title), icon: 'dashicons-editor-textcolor', help: 'No custom MySEO title saved' }),
                el(MetricCard, { label: 'Missing descriptions', value: number(summary.missing_meta_description), icon: 'dashicons-text', help: 'No custom MySEO description saved' }),
                el(MetricCard, { label: 'Missing keyphrases', value: number(summary.missing_focus_keyphrase), icon: 'dashicons-tag', help: 'No focus keyphrase saved' })
            ),
            el('div', { className: 'myseo-audit-secondary-summary' },
                el('span', null, 'Duplicate SEO title groups: ', el('strong', null, number(summary.duplicate_seo_title_groups))),
                el('span', null, 'Duplicate description groups: ', el('strong', null, number(summary.duplicate_meta_description_groups))),
                el('span', null, 'Content missing one or more custom fields: ', el('strong', null, number(summary.content_with_issues)))
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null, el('h2', null, 'Published content'), el('p', null, 'Search by post or page title. Select Edit to update its SEO fields.')),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) { event.preventDefault(); setAppliedSearch(search); load(1, search); } },
                        el('input', { type: 'search', value: search, placeholder: 'Search content…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Scanning published content…')) :
                    result && result.items && result.items.length
                        ? el('div', { className: 'myseo-audit-table-wrap' },
                            el('table', { className: 'myseo-audit-table' },
                                el('thead', null, el('tr', null,
                                    el('th', null, 'Content'),
                                    el('th', null, 'Type'),
                                    el('th', null, 'Issues'),
                                    el('th', null, 'Action')
                                )),
                                el('tbody', null, result.items.map(function (item) {
                                    return el('tr', { key: item.id },
                                        el('td', null,
                                            el('strong', null, item.title || '(Untitled)'),
                                            el('small', null, 'ID: ' + item.id)
                                        ),
                                        el('td', null, item.post_type),
                                        el('td', null, issueBadges(item.issues)),
                                        el('td', null, item.edit_url ? el('a', { className: 'button button-small', href: item.edit_url }, 'Edit') : '—')
                                    );
                                }))
                            )
                        )
                        : el('p', { className: 'myseo-empty-state' }, 'No published content matched this search.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Page ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1) + ' · ' + number(pagination.total_items) + ' matching items'),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, appliedSearch); } }, 'Previous'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, appliedSearch); } }, 'Next')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'This audit checks whether custom MySEO fields are saved. WordPress may still output a fallback document title and excerpt-based description when these fields are blank. Duplicate counts refer to groups of identical non-empty custom values. The audit does not measure Google rankings.')
        );
    }


    function ImageAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedState = useState('');
        var applied = appliedState[0], setApplied = appliedState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            apiFetch({ path: '/myseo/v1/image-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '') })
                .then(function (data) { setResult(data); setPage(nextPage); })
                .catch(function (err) { setError(err && err.message ? err.message : 'Unable to load image audit.'); })
                .finally(function () { setLoading(false); });
        }
        useEffect(function () { load(1, ''); }, []);

        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var items = result && result.items ? result.items : [];

        function statusLabel(status) {
            if (status === 'missing') return el('span', { className: 'myseo-audit-issue' }, 'Missing alt');
            if (status === 'empty') return el('span', { className: 'myseo-image-review' }, 'Empty alt · review');
            return el('span', { className: 'myseo-audit-clean' }, 'Alt text set');
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Site-wide image audit'),
                    el('p', null, 'Review image alt attributes in published content. Each page of results scans a batch of published posts.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, applied); }, disabled: loading }, 'Refresh audit')
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Image occurrences', value: number(summary.image_occurrences), icon: 'dashicons-format-image', help: 'Images found in this post batch' }),
                el(MetricCard, { label: 'Missing alt', value: number(summary.missing_alt), icon: 'dashicons-warning', help: 'Alt attribute is not present' }),
                el(MetricCard, { label: 'Empty alt', value: number(summary.empty_alt), icon: 'dashicons-visibility', help: 'May be decorative; review in context' }),
                el(MetricCard, { label: 'Alt text set', value: number(summary.with_alt), icon: 'dashicons-yes-alt', help: 'Non-empty alt attribute found' })
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Image usage in published content'),
                        el('p', null, number(summary.posts_in_batch) + ' posts scanned in this batch · ' +
                            number(summary.posts_with_images) + ' posts contain images · ' +
                            number(pagination.total_posts) + ' published posts match')
                    ),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) {
                        event.preventDefault(); setApplied(search); load(1, search);
                    } },
                        el('input', { type: 'search', value: search, placeholder: 'Search posts…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Scanning this batch…')) :
                    items.length ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table myseo-image-audit-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Image'),
                                el('th', null, 'Alt status'),
                                el('th', null, 'Alt text'),
                                el('th', null, 'Content'),
                                el('th', null, 'Actions')
                            )),
                            el('tbody', null, items.map(function (item) {
                                return el('tr', { key: item.key },
                                    el('td', null,
                                        el('strong', null, item.filename || '(Unknown file)'),
                                        item.src ? el('small', null, item.src) : null
                                    ),
                                    el('td', null, statusLabel(item.status)),
                                    el('td', null, item.alt || (item.status === 'empty' ? '(empty)' : '—')),
                                    el('td', null,
                                        el('strong', null, item.post_title),
                                        el('small', null, item.post_type + ' · ID: ' + item.post_id)
                                    ),
                                    el('td', null,
                                        item.post_edit_url ? el('a', { className: 'button button-small', href: item.post_edit_url }, 'Edit content') : null,
                                        item.attachment_edit_url ? el('a', { className: 'button button-small myseo-button-gap', href: item.attachment_edit_url }, 'Media file') : null
                                    )
                                );
                            }))
                        )
                    ) : el('p', { className: 'myseo-empty-state' }, 'No images found in this batch of published content.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Post batch ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1)),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, applied); } }, 'Previous batch'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, applied); } }, 'Next batch')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Scope: images found in saved post content (including Gutenberg block markup) for published public post types. Theme-generated images, shortcode output, CSS background images, and dynamically rendered content are not scanned. Missing alt means the attribute is absent; alt="" is shown for review because it can be correct for decorative images. Summary metrics apply only to the currently displayed batch. Search filters posts by WordPress title/content search.')
        );
    }


    function TechnicalAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedState = useState('');
        var applied = appliedState[0], setApplied = appliedState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            apiFetch({ path: '/myseo/v1/technical-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '') })
                .then(function (data) { setResult(data); setPage(nextPage); })
                .catch(function (err) { setError(err && err.message ? err.message : 'Unable to load technical audit.'); })
                .finally(function () { setLoading(false); });
        }
        useEffect(function () { load(1, ''); }, []);

        var checks = result && result.site_checks ? result.site_checks : [];
        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var items = result && result.items ? result.items : [];

        function checkCard(check) {
            var statusText = check.status === 'good' ? 'Looks good' : (check.status === 'issue' ? 'Action needed' : 'Review');
            return el('div', { className: 'myseo-technical-check', key: check.id },
                el('div', { className: 'myseo-technical-check-top' },
                    el('strong', null, check.label),
                    el('span', { className: 'myseo-technical-status ' + check.status }, statusText)
                ),
                el('p', null, check.detail),
                check.url ? el('a', { href: check.url, target: '_blank', rel: 'noopener noreferrer' }, check.id === 'sitemap' ? 'Open sitemap' : (check.id === 'visibility' ? 'Reading settings' : 'Open site')) : null
            );
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Technical SEO audit'),
                    el('p', null, 'Review WordPress SEO configuration, sitemap availability, rendered canonical output and internal links in published content.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, applied); }, disabled: loading }, 'Refresh audit')
            ),
            el('section', { className: 'myseo-panel myseo-technical-site-panel' },
                el('h2', null, 'Site configuration checks'),
                el('div', { className: 'myseo-technical-check-grid' }, checks.map(checkCard))
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Internal links', value: number(summary.internal_link_occurrences), icon: 'dashicons-admin-links', help: 'Internal link occurrences in this post batch' }),
                el(MetricCard, { label: 'Mixed-content links', value: number(summary.mixed_content_links), icon: 'dashicons-warning', help: 'HTTP links found on an HTTPS site' }),
                el(MetricCard, { label: 'Unresolved links', value: number(summary.unresolved_internal_links), icon: 'dashicons-search', help: 'Could not map to a WordPress post; review required' }),
                el(MetricCard, { label: 'Posts scanned', value: number(summary.posts_in_batch), icon: 'dashicons-media-document', help: number(pagination.total_posts) + ' published posts match' })
            ),
            el('section', { className: 'myseo-panel myseo-link-topology-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Site-wide internal link structure'),
                        el('p', null, number(((result && result.link_topology) || {}).posts_analyzed) + ' published content items analyzed.')
                    )
                ),
                el('div', { className: 'myseo-audit-summary-grid myseo-link-topology-metrics' },
                    el(MetricCard, { label: 'Posts with no incoming links', value: number(((result && result.link_topology) || {}).orphaned_posts_count), icon: 'dashicons-admin-links', help: 'No links from other scanned published posts were found' }),
                    el(MetricCard, { label: 'Posts with no outgoing links', value: number(((result && result.link_topology) || {}).posts_without_outgoing_links_count), icon: 'dashicons-share', help: 'No links to other scanned published posts were found' }),
                    el(MetricCard, { label: 'Analyzed internal links', value: number(((result && result.link_topology) || {}).internal_link_occurrences), icon: 'dashicons-networking', help: 'Resolved post-to-post link occurrences' })
                ),
                ((result && result.link_topology) || {}).analysis_limited ? el(Notice, { type: 'warning', title: 'Partial site scan', children: 'The site-wide link map is limited to the first 1,000 published content items. Some posts may not be included.' }) : null,
                el('h3', null, 'Posts with no incoming internal links'),
                ((result && result.link_topology) || {}).orphaned_posts && (result && result.link_topology).orphaned_posts.length
                    ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Content'),
                                el('th', null, 'Outgoing links'),
                                el('th', null, 'Action')
                            )),
                            el('tbody', null, (result && result.link_topology).orphaned_posts.map(function (item) {
                                return el('tr', { key: 'orphan-' + item.id },
                                    el('td', null, el('strong', null, item.title), el('small', null, item.type + ' · ID: ' + item.id)),
                                    el('td', null, number(item.outgoing_links)),
                                    el('td', null, item.edit_url ? el('a', { className: 'button button-small', href: item.edit_url }, 'Edit content') : '—')
                                );
                            }))
                        )
                    )
                    : el('p', { className: 'myseo-empty-state' }, 'Every analyzed content item has at least one incoming internal link from another scanned post.'),
                el('h3', null, 'Posts with no outgoing internal links'),
                ((result && result.link_topology) || {}).posts_without_outgoing_links && (result && result.link_topology).posts_without_outgoing_links.length
                    ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Content'),
                                el('th', null, 'Incoming links'),
                                el('th', null, 'Action')
                            )),
                            el('tbody', null, (result && result.link_topology).posts_without_outgoing_links.map(function (item) {
                                return el('tr', { key: 'no-out-' + item.id },
                                    el('td', null, el('strong', null, item.title), el('small', null, item.type + ' · ID: ' + item.id)),
                                    el('td', null, number(item.incoming_links)),
                                    el('td', null, item.edit_url ? el('a', { className: 'button button-small', href: item.edit_url }, 'Edit content') : '—')
                                );
                            }))
                        )
                    )
                    : el('p', { className: 'myseo-empty-state' }, 'Every analyzed content item links to at least one other scanned published post.')
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Internal link review'),
                        el('p', null, number(summary.posts_with_internal_links) + ' posts in this batch contain internal links.')
                    ),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) {
                        event.preventDefault(); setApplied(search); load(1, search);
                    } },
                        el('input', { type: 'search', value: search, placeholder: 'Search posts…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Checking published content…')) :
                    items.length ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table myseo-technical-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Internal URL'),
                                el('th', null, 'Finding'),
                                el('th', null, 'Source content'),
                                el('th', null, 'Action')
                            )),
                            el('tbody', null, items.map(function (item) {
                                var finding = item.mixed_content ? 'HTTP link on HTTPS site' :
                                    (item.unresolved ? 'Target not mapped · review' : 'Internal link');
                                return el('tr', { key: item.key },
                                    el('td', null, el('a', { href: item.href, target: '_blank', rel: 'noopener noreferrer' }, item.href)),
                                    el('td', null, item.mixed_content ? el('span', { className: 'myseo-audit-issue' }, finding) :
                                        (item.unresolved ? el('span', { className: 'myseo-image-review' }, finding) : el('span', { className: 'myseo-audit-clean' }, finding))),
                                    el('td', null, el('strong', null, item.post_title), el('small', null, item.post_type + ' · ID: ' + item.post_id)),
                                    el('td', null, item.post_edit_url ? el('a', { className: 'button button-small', href: item.post_edit_url }, 'Edit content') : '—')
                                );
                            }))
                        )
                    ) : el('p', { className: 'myseo-empty-state' }, 'No internal links were found in this post batch.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Post batch ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1)),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, applied); } }, 'Previous batch'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, applied); } }, 'Next batch')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Important: unresolved internal URLs are review candidates, not confirmed broken links. WordPress cannot map archive pages, custom routes, some multilingual URLs, or external rewrite rules to a post ID. This scan examines saved post content only and does not crawl rendered pages or send HTTP requests to every link. The link-structure map scans up to 1,000 published content items and counts only links that resolve to another scanned WordPress post. It does not include navigation menus, widgets, theme-generated links, archive routes, or links injected dynamically. A post with no incoming links is a review candidate, not automatically an SEO problem.')
        );
    }

    function ContentHealth() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];

        function load() {
            setLoading(true);
            apiFetch({ path: '/myseo/v1/content-health' })
                .then(function (data) { setResult(data); setError(''); })
                .catch(function (err) { setError(err && err.message ? err.message : 'Could not load content health.'); })
                .finally(function () { setLoading(false); });
        }

        useEffect(function () { load(); }, []);

        if (loading) {
            return el('div', { className: 'myseo-page-content' },
                el('h1', null, 'Content health'),
                el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('p', null, 'Analyzing published content…'))
            );
        }
        if (error) {
            return el('div', { className: 'myseo-page-content' },
                el('h1', null, 'Content health'),
                el(Notice, { type: 'error', title: 'Content health could not load', children: error }),
                el('button', { className: 'button', onClick: load }, 'Try again')
            );
        }

        var summary = (result && result.summary) || {};
        var items = (result && result.items) || [];
        function flagLabel(flag) {
            return {
                stale: 'Not updated in 12+ months',
                thin: 'Under 300 words',
                no_featured_image: 'No featured image'
            }[flag] || flag;
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-audit-heading' },
                el('div', null,
                    el('h1', null, 'Content health'),
                    el('p', { className: 'myseo-page-intro' }, 'Find published content that may need a review, refresh or richer presentation.')
                ),
                el('button', { className: 'button button-primary', onClick: load }, 'Refresh audit')
            ),
            el('div', { className: 'myseo-metric-grid' },
                el(MetricCard, { label: 'Published content analyzed', value: number(summary.posts_analyzed), icon: 'dashicons-media-document', help: 'Published public content in this scan' }),
                el(MetricCard, { label: 'Needs freshness review', value: number(summary.stale_content), icon: 'dashicons-clock', help: 'Not modified in at least 365 days' }),
                el(MetricCard, { label: 'Short content', value: number(summary.thin_content), icon: 'dashicons-editor-paragraph', help: 'Fewer than 300 words' }),
                el(MetricCard, { label: 'No featured image', value: number(summary.missing_featured_image), icon: 'dashicons-format-image', help: 'No featured image assigned' })
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Content review candidates'),
                        el('p', null, number(summary.posts_with_issues) + ' published items have one or more review signals.')
                    )
                ),
                result && result.analysis_limited ? el(Notice, { type: 'warning', title: 'Partial scan', children: 'The audit is limited to the first 500 published content items.' }) : null,
                items.length ? el('div', { className: 'myseo-audit-table-wrap' },
                    el('table', { className: 'myseo-audit-table' },
                        el('thead', null, el('tr', null,
                            el('th', null, 'Content'),
                            el('th', null, 'Word count'),
                            el('th', null, 'Last modified'),
                            el('th', null, 'Review signals'),
                            el('th', null, 'Action')
                        )),
                        el('tbody', null, items.map(function (item) {
                            return el('tr', { key: item.id },
                                el('td', null, el('strong', null, item.title), el('small', null, item.type + ' · ID: ' + item.id)),
                                el('td', null, number(item.word_count)),
                                el('td', null, item.modified + (item.age_days >= 365 ? ' · ' + number(item.age_days) + ' days ago' : '')),
                                el('td', null, item.flags.map(function (flag) {
                                    return el('span', { key: flag, className: 'myseo-health-flag' }, flagLabel(flag));
                                })),
                                el('td', null, item.edit_url ? el('a', { className: 'button button-small', href: item.edit_url }, 'Review content') : '—')
                            );
                        }))
                    )
                ) : el('p', { className: 'myseo-empty-state' }, 'No content health review signals were found in the scanned published content.')
            ),
            el('p', { className: 'myseo-footnote' }, 'These are editorial review signals, not Google ranking factors. The 300-word threshold is a simple triage heuristic, not an ideal word-count rule. Older content is not necessarily outdated, and featured images are optional for some content types. The scan examines saved post content and featured-image assignments; it does not judge factual accuracy, search performance or rendered page quality.')
        );
    }

    function ProCrawler() {
        var _s = useState(null), data = _s[0], setData = _s[1];
        var _l = useState(false), loading = _l[0], setLoading = _l[1];
        var _e = useState(''), error = _e[0], setError = _e[1];
        var _f = useState('all'), linkFilter = _f[0], setLinkFilter = _f[1];
        function load() { apiFetch({path:'/myseo/v1/pro-crawler'}).then(setData).catch(function(err){setError(err.message||'Unable to load crawl results.');}); }
        useEffect(function(){load();}, []);
        function start() { setLoading(true); setError(''); apiFetch({path:'/myseo/v1/pro-crawler',method:'POST'}).then(setData).catch(function(err){setError(err.message||'Crawl failed.');}).finally(function(){setLoading(false);}); }
        var results = data && data.results ? data.results : [];
        var summary = data && data.summary ? data.summary : null;
        var linkSection = null;
        if (data && data.link_checks && data.link_checks.length) {
            var filteredLinks = data.link_checks.filter(function(l){var r=l.status===0||l.status>=400?'broken':l.redirect?'redirect':'ok';return linkFilter==='all'||linkFilter===r;});
            linkSection = el('div',{className:'myseo-audit-table-wrap'},
                el('h2',null,'Link Analysis'),
                el('label',{className:'myseo-link-filter-label'},'Filter links: ',el('select',{value:linkFilter,onChange:function(ev){setLinkFilter(ev.target.value);}},el('option',{value:'all'},'All'),el('option',{value:'broken'},'Broken'),el('option',{value:'redirect'},'Redirecting'),el('option',{value:'ok'},'OK'))),
                el('table',{className:'myseo-audit-table'},el('thead',null,el('tr',null,el('th',null,'Link URL'),el('th',null,'Status'),el('th',null,'Result'),el('th',null,'Sources'))),
                    el('tbody',null,filteredLinks.map(function(l,i){
                        var result=l.status===0||l.status>=400?'Broken':l.redirect?'Redirect':'OK'; var src=l.sources||[];
                        var sourceDetails=src.length?el('details',null,el('summary',null,'View source pages'),el('ul',null,src.map(function(s,j){var anchors=s.anchors||[];return el('li',{key:j},el('a',{href:s.source,target:'_blank',rel:'noopener noreferrer'},s.source),anchors.length?el('span',{className:'myseo-footnote'},' — anchor text: '+anchors.join(', ')):null);} ))):null;
                        return el('tr',{key:i},el('td',null,el('a',{href:l.url,target:'_blank',rel:'noopener noreferrer'},l.url),l.redirect_to?el('div',null,'Redirect destination: ',el('a',{href:l.redirect_to,target:'_blank',rel:'noopener noreferrer'},l.redirect_to)):null),el('td',null,l.status||'Fetch error'),el('td',null,result,l.error?el('div',{className:'myseo-footnote'},l.error):null),el('td',null,(l.source_count!==undefined?l.source_count:src.length)+' source page'+((l.source_count!==undefined?l.source_count:src.length)===1?'':'s'),sourceDetails));
                    }))));
        }
        return el('div',{className:'myseo-page-content'},
            el('div',{className:'myseo-welcome-row'},el('div',null,el('h1',null,'MySEO Pro Crawler'),el('p',null,'Scan up to 20 pages and check up to 40 discovered link targets for link issues.')),el('button',{className:'button button-primary',type:'button',disabled:loading,onClick:start},loading?'Crawling…':'Start Crawl')),
            el(Notice,{title:'Crawler foundation preview',children:'This crawl checks page SEO and a bounded sample of up to 40 unique discovered links. Link status checks are synchronous and may not reflect every destination. Length thresholds are advisory, not ranking rules.'}),
            error?el('div',{className:'myseo-notice error'},error):null,
            summary?el('div',{className:'myseo-metrics-grid'},el(MetricCard,{label:'Pages crawled',value:summary.pages_crawled,help:'Pages fetched in this run',icon:'dashicons-admin-site'}),el(MetricCard,{label:'Issues found',value:summary.issues,help:'Page-level findings',icon:'dashicons-warning'}),el(MetricCard,{label:'Missing titles',value:summary.missing_titles,help:'Pages without title tags',icon:'dashicons-editor-textcolor'}),el(MetricCard,{label:'Missing descriptions',value:summary.missing_descriptions,help:'Pages without descriptions',icon:'dashicons-editor-paragraph'}),el(MetricCard,{label:'HTTP errors',value:summary.http_errors,help:'Failed/error responses',icon:'dashicons-dismiss'}),el(MetricCard,{label:'Noindex',value:summary.noindex,help:'Pages with noindex detected',icon:'dashicons-hidden'}),el(MetricCard,{label:'Duplicate titles',value:summary.duplicate_titles||0,help:'Pages sharing a title within this crawl',icon:'dashicons-admin-page'}),el(MetricCard,{label:'Duplicate descriptions',value:summary.duplicate_descriptions||0,help:'Pages sharing a meta description within this crawl',icon:'dashicons-admin-page'}),el(MetricCard,{label:'Links checked',value:summary.links_checked||0,help:'Unique link targets checked (limit 40)',icon:'dashicons-admin-links'}),el(MetricCard,{label:'Broken links',value:summary.broken_links||0,help:'Links returning an error or fetch failure',icon:'dashicons-warning'}),el(MetricCard,{label:'Redirecting links',value:summary.redirect_links||0,help:'Targets returning a redirect response',icon:'dashicons-randomize'})):null,
            results.length?el('div',{className:'myseo-audit-table-wrap'},el('table',{className:'myseo-audit-table'},el('thead',null,el('tr',null,el('th',null,'URL'),el('th',null,'Status'),el('th',null,'Title'),el('th',null,'Canonical'),el('th',null,'Issues'))),el('tbody',null,results.map(function(r,i){return el('tr',{key:i},el('td',null,el('a',{href:r.url,target:'_blank',rel:'noopener noreferrer'},r.url)),el('td',null,r.status||'Fetch error'),el('td',null,r.title||'—'),el('td',null,r.canonical||'—'),el('td',null,r.issues&&r.issues.length?r.issues.join(', '):'None'));})))):el('p',null,'No crawl results yet. Click Start Crawl to scan the site.'),
            linkSection,
            data&& (data.time||data.crawl_time)?el('p',{className:'myseo-footnote'},'Last crawl: '+(data.time||data.crawl_time)):null);
    }

    function Placeholder(props) {
        var copy = {
            content: ['Content audit', 'The paginated Content Audit is available for reviewing missing SEO titles, meta descriptions and focus keyphrases, plus duplicate custom titles and descriptions.'],
            images: ['Image audit', 'Site-wide image usage audit is available.'],
            technical: ['Technical SEO', 'Technical SEO audit is available.'], crawler: ['Pro Crawler', 'A crawler is available.'],
            health: ['Content health', 'Content freshness and content-decay monitoring are planned for a future release.'],
            performance: ['SEO performance', 'Google Search Console integration is not connected yet. Search clicks, impressions and query data will appear here after that integration is built.']
        }[props.section];
        return el('div', { className: 'myseo-page-content' },
            el('h1', null, copy[0]),
            el(Notice, { title: 'Coming in a future release', children: copy[1] }),
            el('p', { className: 'myseo-footnote' }, props.section === 'health' || props.section === 'performance' ? 'This section is a roadmap placeholder and does not currently run an audit or display connected search-performance data.' : 'This section provides information about the selected MySEO module.')
        );
    }

    function Settings(props) {
        var settings = props.settings;
        var setSettings = props.setSettings;
        var saving = props.saving;
        var saveMessage = props.saveMessage;
        function update(key, value) {
            var next = Object.assign({}, settings);
            next[key] = value;
            setSettings(next);
        }
        function toggle(key) {
            update(key, !settings[key]);
        }
        function field(label, key, description, multiline) {
            return el('div', { className: 'myseo-global-setting-field' },
                el('label', { htmlFor: 'myseo-setting-' + key }, label),
                multiline
                    ? el('textarea', { id: 'myseo-setting-' + key, rows: 3, value: settings[key] || '', onChange: function (event) { update(key, event.target.value); } })
                    : el('input', { id: 'myseo-setting-' + key, type: key === 'social_default_image' ? 'url' : 'text', value: settings[key] || '', onChange: function (event) { update(key, event.target.value); } }),
                description ? el('p', { className: 'description' }, description) : null
            );
        }
        return el('div', { className: 'myseo-page-content' },
            el('h1', null, 'Settings'),
            el('p', { className: 'myseo-page-intro' }, 'Manage global SEO defaults, homepage metadata and social sharing fallbacks. Per-content values take priority where applicable.'),
            el('section', { className: 'myseo-panel myseo-settings-panel' },
                el('div', { className: 'myseo-toggle-row' },
                    el('div', null, el('h3', null, 'Meta description output'), el('p', null, 'Print the MySEO meta description on the homepage and singular pages when enabled.')),
                    el('label', { className: 'myseo-switch' },
                        el('input', { type: 'checkbox', checked: !!settings.enable_meta_output, onChange: function () { toggle('enable_meta_output'); } }),
                        el('span', { className: 'myseo-switch-slider' })
                    )
                ),
                el('div', { className: 'myseo-toggle-row' },
                    el('div', null, el('h3', null, 'Structured data (JSON-LD)'), el('p', null, 'Generate basic BlogPosting schema for posts and WebPage schema for other singular content.')),
                    el('label', { className: 'myseo-switch' },
                        el('input', { type: 'checkbox', checked: !!settings.enable_schema_output, onChange: function () { toggle('enable_schema_output'); } }),
                        el('span', { className: 'myseo-switch-slider' })
                    )
                )
            ),
            el('section', { className: 'myseo-panel myseo-settings-panel' },
                el('h2', null, 'Global SEO templates'),
                field('SEO title template', 'title_template', 'Available tokens: {title}, {site_name}, {tagline}. Default: {title} | {site_name}. Used when a post has no custom SEO title.'),
                field('Meta description fallback template', 'description_template', 'Available tokens: {excerpt}, {title}, {site_name}. Used when a post has no custom meta description.', true)
            ),
            el('section', { className: 'myseo-panel myseo-settings-panel' },
                el('h2', null, 'Homepage SEO'),
                field('Homepage SEO title', 'homepage_title', 'Leave blank to use the global SEO title template.'),
                field('Homepage meta description', 'homepage_description', 'Leave blank to use the WordPress site tagline.')
            ),
            el('section', { className: 'myseo-panel myseo-settings-panel' },
                el('h2', null, 'Default social metadata'),
                field('Default social title', 'social_default_title', 'Used as a site-wide social title fallback when a content-specific social title is blank.'),
                field('Default social description', 'social_default_description', 'Used as a site-wide social description fallback when a content-specific social description is blank.', true),
                field('Default social image URL', 'social_default_image', 'Used when content has no custom social image or featured image.')
            ),
            el('div', { className: 'myseo-settings-actions' },
                el('button', { className: 'button button-primary', disabled: saving, onClick: props.save }, saving ? 'Saving…' : 'Save settings'),
                saveMessage ? el('span', { className: 'myseo-save-message', role: 'status' }, saveMessage) : null
            ),
            el(Notice, { title: 'Metadata priority', children: 'For social metadata, per-content social fields take priority, followed by the global social defaults and then SEO/content fallbacks. For SEO titles and descriptions, custom per-content fields take priority over global templates. For a static homepage, metadata saved on the selected front-page page takes priority over the homepage settings.' }),
            el(Notice, { type: 'warning', title: 'Compatibility note', children: 'If another SEO plugin is active, review its metadata and schema settings to avoid duplicate output. MySEO suppresses selected outputs when supported SEO plugins are detected.' })
        );
    }

    function number(value) {
        return Number(value || 0).toLocaleString();
    }

    function App() {
        var activeState = useState('overview');
        var active = activeState[0], setActive = activeState[1];
        var dataState = useState(null);
        var data = dataState[0], setData = dataState[1];
        var settingsState = useState({
            enable_meta_output: true,
            enable_schema_output: true,
            title_template: '{title} | {site_name}',
            description_template: '{excerpt}',
            homepage_title: '',
            homepage_description: '',
            social_default_title: '',
            social_default_description: '',
            social_default_image: ''
        });
        var settings = settingsState[0], setSettings = settingsState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var savingState = useState(false);
        var saving = savingState[0], setSaving = savingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var messageState = useState('');
        var message = messageState[0], setMessage = messageState[1];

        function refresh() {
            setLoading(true);
            Promise.all([
                apiFetch({ path: '/myseo/v1/dashboard' }),
                apiFetch({ path: '/myseo/v1/settings' })
            ]).then(function (results) {
                setData(results[0]);
                setSettings(results[1]);
                setError('');
            }).catch(function (err) {
                setError(err && err.message ? err.message : 'Could not load dashboard data.');
            }).finally(function () { setLoading(false); });
        }

        useEffect(function () { refresh(); }, []);

        function saveSettings() {
            setSaving(true);
            setMessage('');
            apiFetch({
                path: '/myseo/v1/settings',
                method: 'POST',
                data: settings
            }).then(function (result) {
                setSettings({
                    enable_meta_output: result.enable_meta_output,
                    enable_schema_output: result.enable_schema_output,
                    title_template: result.title_template,
                    description_template: result.description_template,
                    homepage_title: result.homepage_title,
                    homepage_description: result.homepage_description,
                    social_default_title: result.social_default_title,
                    social_default_description: result.social_default_description,
                    social_default_image: result.social_default_image
                });
                setMessage('Settings saved successfully.');
                refresh();
            }).catch(function (err) {
                setMessage(err && err.message ? err.message : 'Unable to save settings.');
            }).finally(function () { setSaving(false); });
        }

        var page = active === 'overview'
            ? el(Overview, { data: data || {}, openSettings: function () { setActive('settings'); } })
            : active === 'settings'
                ? el(Settings, { settings: settings, setSettings: setSettings, saving: saving, saveMessage: message, save: saveSettings })
                : active === 'content'
                    ? el(ContentAudit)
                    : active === 'images'
                        ? el(ImageAudit)
                        : active === 'technical'
                            ? el(TechnicalAudit)
                            : active === 'health'
                                ? el(ContentHealth)
                                : active === 'crawler'
                                    ? el(ProCrawler)
                                    : el(Placeholder, { section: active });

        return el('div', { className: 'myseo-app' },
            el('aside', { className: 'myseo-sidebar' },
                el('div', { className: 'myseo-brand' },
                    el('span', { className: 'myseo-brand-mark' }, 'M'),
                    el('div', null, el('strong', null, 'MySEO'), el('small', null, 'Website optimization'))
                ),
                el('nav', { className: 'myseo-navigation', 'aria-label': 'MySEO navigation' },
                    navItems.map(function (item) {
                        return el('button', {
                            key: item.id,
                            type: 'button',
                            className: 'myseo-nav-item' + (active === item.id ? ' active' : ''),
                            onClick: function () { setActive(item.id); setMessage(''); }
                        }, el(Icon, { name: item.icon }), el('span', null, item.label));
                    })
                ),
                el('div', { className: 'myseo-sidebar-footer' }, 'MySEO ' + (config.version || '0.9.0'))
            ),
            el('main', { className: 'myseo-main' },
                el('div', { className: 'myseo-topbar' },
                    el('span', null, 'WordPress SEO workspace'),
                    el('button', { type: 'button', className: 'button', onClick: refresh }, 'Refresh data')
                ),
                error ? el(Notice, { type: 'error', title: 'Dashboard error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('p', null, 'Loading dashboard…')) : page
            )
        );
    }

    var root = document.getElementById('myseo-dashboard-root');
    if (root) {
        if (wp.element.createRoot) {
            wp.element.createRoot(root).render(el(App));
        } else {
            wp.element.render(el(App), root);
        }
    }
})(window.wp);
