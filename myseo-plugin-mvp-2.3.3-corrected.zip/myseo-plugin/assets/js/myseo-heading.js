(function () {
    'use strict';

    function getContent() {
        if (window.wp && wp.data && wp.data.select) {
            var editor = wp.data.select('core/editor');
            if (editor && typeof editor.getEditedPostContent === 'function') {
                return editor.getEditedPostContent();
            }
        }
        var classic = document.getElementById('content');
        return classic ? classic.value : '';
    }

    function addIssue(list, severity, message) {
        var li = document.createElement('li');
        li.className = severity === 'warning' ? 'needs-work' : 'needs-review';
        var mark = document.createElement('span');
        mark.className = 'myseo-check-mark';
        mark.textContent = severity === 'warning' ? '!' : 'i';
        var text = document.createElement('span');
        text.textContent = message;
        li.append(mark, text);
        list.appendChild(li);
    }

    function render() {
        var output = document.getElementById('myseo-heading-results');
        if (!output) return;

        var html = getContent();
        var wrapper = document.createElement('div');
        wrapper.innerHTML = html || '';

        // Restrict analysis to article content. Theme-generated page titles
        // are not part of the editor content and may supply the page H1.
        var nodes = Array.prototype.slice.call(wrapper.querySelectorAll('h1,h2,h3,h4,h5,h6'));
        output.textContent = '';

        var counts = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0};
        var headings = nodes.map(function (node) {
            var level = parseInt(node.tagName.substring(1), 10);
            var text = (node.textContent || '').replace(/\s+/g, ' ').trim();
            counts[level]++;
            return { level: level, text: text };
        });

        var summary = document.createElement('p');
        summary.className = 'myseo-readability-summary';
        summary.textContent = headings.length
            ? headings.length + ' heading(s): ' + [1,2,3,4,5,6].map(function (n) { return 'H' + n + ' ' + counts[n]; }).join(' · ')
            : 'No headings found in the article content.';
        output.appendChild(summary);

        var issues = [];
        if (counts[1] === 0) {
            issues.push({
                severity: 'warning',
                message: 'No H1 was found inside the article. Check whether your theme displays the post title as the page H1.'
            });
        } else if (counts[1] > 1) {
            issues.push({
                severity: 'notice',
                message: 'Found ' + counts[1] + ' H1 headings in the article. Review whether one clear main heading is appropriate.'
            });
        }

        headings.forEach(function (heading, index) {
            if (!heading.text) {
                issues.push({ severity: 'warning', message: 'Heading ' + (index + 1) + ' (H' + heading.level + ') is empty.' });
            }
            if (index > 0 && heading.level > headings[index - 1].level + 1) {
                issues.push({
                    severity: 'notice',
                    message: 'Heading hierarchy skips from H' + headings[index - 1].level + ' to H' + heading.level +
                        (heading.text ? ' before "' + heading.text + '".' : '.')
                });
            }
        });

        var list = document.createElement('ul');
        list.className = 'myseo-check-list';
        if (!issues.length) {
            addIssue(list, 'good', headings.length
                ? 'No obvious heading hierarchy issues detected.'
                : 'Add headings to organize longer content into meaningful sections.');
        } else {
            issues.forEach(function (issue) {
                addIssue(list, issue.severity, issue.message);
            });
        }
        output.appendChild(list);

        var outlineTitle = document.createElement('h5');
        outlineTitle.className = 'myseo-heading-outline-title';
        outlineTitle.textContent = 'Heading outline';
        output.appendChild(outlineTitle);

        if (!headings.length) {
            var empty = document.createElement('p');
            empty.className = 'myseo-empty';
            empty.textContent = 'Your article heading outline will appear here.';
            output.appendChild(empty);
        } else {
            var outline = document.createElement('ol');
            outline.className = 'myseo-heading-outline';
            headings.forEach(function (heading) {
                var item = document.createElement('li');
                item.style.marginLeft = ((heading.level - 1) * 14) + 'px';
                item.textContent = 'H' + heading.level + ' — ' + (heading.text || '[Empty heading]');
                outline.appendChild(item);
            });
            output.appendChild(outline);
        }

        var note = document.createElement('p');
        note.className = 'myseo-analysis-note';
        note.textContent = 'This checks headings inside the article editor only. Your theme may output the post title as the page H1, so verify the rendered page before changing headings.';
        output.appendChild(note);
    }

    function init() {
        var classic = document.getElementById('content');
        if (classic) classic.addEventListener('input', render);

        if (window.wp && wp.data && wp.data.subscribe) {
            var pending = false;
            wp.data.subscribe(function () {
                if (pending) return;
                pending = true;
                window.setTimeout(function () {
                    pending = false;
                    render();
                }, 300);
            });
        }
        render();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
