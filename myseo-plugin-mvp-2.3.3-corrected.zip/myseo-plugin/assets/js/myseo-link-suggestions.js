(function () {
'use strict';

function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (typeof text === 'string') node.textContent = text;
    return node;
}
function getEditorPostId() {
    if (window.wp && wp.data && wp.data.select) {
        var select = wp.data.select('core/editor');
        if (select && select.getCurrentPostId) return select.getCurrentPostId();
    }
    var input = document.getElementById('post_ID');
    return input ? parseInt(input.value, 10) : 0;
}
function getKeyphrase() {
    var field = document.getElementById('myseo_keyphrase');
    return field ? field.value.trim() : '';
}
function insertLink(item) {
    var anchorText = item.anchor_text || item.title;
    var html = '<a href="' + String(item.url).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '">' +
        String(anchorText).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</a>';

    if (window.wp && wp.blocks && wp.data && wp.data.dispatch) {
        var dispatch = wp.data.dispatch('core/block-editor');
        if (dispatch && dispatch.insertBlocks) {
            var block = wp.blocks.createBlock('core/paragraph', { content: html });
            dispatch.insertBlocks(block);
            return true;
        }
    }

    if (window.tinymce && tinymce.activeEditor && !tinymce.activeEditor.isHidden()) {
        tinymce.activeEditor.execCommand('mceInsertContent', false, html);
        return true;
    }

    var textarea = document.getElementById('content');
    if (textarea) {
        var start = typeof textarea.selectionStart === 'number' ? textarea.selectionStart : textarea.value.length;
        var end = typeof textarea.selectionEnd === 'number' ? textarea.selectionEnd : start;
        textarea.value = textarea.value.slice(0, start) + html + textarea.value.slice(end);
        textarea.focus();
        textarea.selectionStart = textarea.selectionEnd = start + html.length;
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
    }
    return false;
}
function render(container, payload) {
    container.innerHTML = '';
    if (!payload.items || !payload.items.length) {
        container.appendChild(element('p', 'myseo-empty', payload.message || 'No related published content was found.'));
        return;
    }

    var list = element('div', 'myseo-link-suggestion-list');
    payload.items.forEach(function (item) {
        var card = element('div', 'myseo-link-suggestion');
        var title = element('strong', 'myseo-link-suggestion-title', item.title);
        var type = element('span', 'myseo-link-suggestion-type', item.type || 'Content');
        var excerpt = element('p', 'myseo-link-suggestion-excerpt', item.excerpt || '');
        var reason = element('p', 'myseo-link-suggestion-reason', item.reason || ('Matched terms: ' + (item.matched_terms || []).join(', ')));
        var anchor = element('p', 'myseo-link-suggestion-anchor', 'Suggested anchor text: ' + (item.anchor_text || item.title));
        var url = element('a', 'myseo-link-suggestion-url', item.url);
        url.href = item.url;
        url.target = '_blank';
        url.rel = 'noopener noreferrer';
        var actions = element('div', 'myseo-link-suggestion-actions');
        var insert = element('button', 'button button-primary', item.already_linked ? 'Already linked' : 'Insert suggested anchor');
        insert.type = 'button';
        insert.disabled = !!item.already_linked;
        if (!item.already_linked) {
            insert.addEventListener('click', function () {
                if (insertLink(item)) {
                    insert.textContent = 'Inserted';
                    insert.disabled = true;
                } else {
                    window.alert('Could not find an active WordPress editor to insert the link.');
                }
            });
        }
        var copy = element('button', 'button', 'Copy URL');
        copy.type = 'button';
        copy.addEventListener('click', function () {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(item.url).then(function () {
                    copy.textContent = 'Copied';
                }).catch(function () {
                    copy.textContent = 'Copy unavailable';
                });
            } else {
                copy.textContent = 'Clipboard unavailable';
            }
        });
        actions.append(insert, copy);
        card.append(title, type, excerpt, reason, anchor, url, actions);
        list.appendChild(card);
    });
    container.appendChild(list);
}
function fetchSuggestions() {
    var container = document.getElementById('myseo-link-suggestions');
    if (!container) return;
    var postId = getEditorPostId() || parseInt(container.getAttribute('data-post-id'), 10);
    var keyphrase = getKeyphrase();
    if (!keyphrase) {
        container.innerHTML = '';
        container.appendChild(element('p', 'myseo-empty', 'Enter a focus keyphrase to find related published content.'));
        return;
    }
    if (!window.wp || !wp.apiFetch) {
        container.textContent = 'The WordPress REST API client is unavailable.';
        return;
    }
    container.textContent = 'Finding related published content…';
    var path = (myseoLinkSuggestions.restPath || '/myseo/v1/link-suggestions') +
        '?post_id=' + encodeURIComponent(postId) + '&keyphrase=' + encodeURIComponent(keyphrase);
    wp.apiFetch({ path: path }).then(function (payload) {
        render(container, payload);
    }).catch(function (error) {
        container.textContent = error && error.message ? error.message : 'Could not load link suggestions.';
    });
}
function init() {
    var field = document.getElementById('myseo_keyphrase');
    if (!document.getElementById('myseo-link-suggestions')) return;
    if (field) field.addEventListener('input', function () {
        window.clearTimeout(init.timer);
        init.timer = window.setTimeout(fetchSuggestions, 350);
    });
    fetchSuggestions();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
})();
