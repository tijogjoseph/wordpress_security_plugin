(function () {
'use strict';
function norm(s){return(s||'').toLocaleLowerCase().replace(/[^\p{L}\p{N}\s-]/gu,' ').replace(/\s+/g,' ').trim();}
function has(t,p){t=norm(t);p=norm(p);if(!t||!p)return false;var e=p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');return new RegExp('(^|[^\\p{L}\\p{N}])'+e+'($|[^\\p{L}\\p{N}])','u').test(t);}
function ed(){return window.wp&&wp.data&&wp.data.select?wp.data.select('core/editor'):null;}
function content(){var e=ed();if(e&&e.getEditedPostContent)return e.getEditedPostContent();var x=document.getElementById('content');return x?x.value:'';}
function title(){var e=ed();if(e&&e.getEditedPostAttribute)return e.getEditedPostAttribute('title')||'';var x=document.getElementById('title');return x?x.value:'';}
function slug(){var e=ed();if(e&&e.getEditedPostAttribute)return e.getEditedPostAttribute('slug')||'';var x=document.getElementById('post_name');return x?x.value:'';}
function plain(h){var x=document.createElement('div');x.innerHTML=h||'';return(x.textContent||'').replace(/\s+/g,' ').trim();}
function render(){
 var k=document.getElementById('myseo_keyphrase'),t=document.getElementById('myseo_title'),d=document.getElementById('myseo_description'),o=document.getElementById('myseo-keyphrase-results');
 if(!k||!o)return;o.textContent='';var p=k.value.trim();
 if(!p){var em=document.createElement('p');em.className='myseo-empty';em.textContent='Enter a focus keyphrase to see recommendations.';o.appendChild(em);return;}
 var html=content(),body=plain(html),intro=body.split(/\s+/).slice(0,60).join(' '),box=document.createElement('div');box.innerHTML=html;
 var hs=Array.prototype.map.call(box.querySelectorAll('h1,h2,h3,h4,h5,h6'),function(x){return x.textContent||'';}).join(' ');
 var checks=[
 ['SEO title',has(t&&t.value?t.value:title(),p),'Add the keyphrase to the SEO title where natural.'],
 ['Meta description',has(d?d.value:'',p),'Consider including the keyphrase in the meta description.'],
 ['URL slug',has(slug().replace(/-/g,' '),p),'Consider including the keyphrase in the URL slug.'],
 ['Introduction',has(intro,p),'Mention the keyphrase naturally near the beginning.'],
 ['Headings',has(hs,p),'Consider using the keyphrase or a variation in a relevant heading.'],
 ['Article content',has(body,p),'Use the keyphrase naturally in the article body.']];
 related.forEach(function(item){checks.push(['Related phrase: '+item,has(body,item),'Consider including this related phrase naturally where it adds useful context.']);});
 var ul=document.createElement('ul');ul.className='myseo-check-list';
 checks.forEach(function(c){var li=document.createElement('li');li.className=c[1]?'is-good':'needs-work';var m=document.createElement('span');m.className='myseo-check-mark';m.textContent=c[1]?'✓':'!';var b=document.createElement('strong');b.textContent=c[0]+': ';var s=document.createElement('span');s.textContent=c[1]?'Found':c[2];li.append(m,b,s);ul.appendChild(li);});
 o.appendChild(ul);var n=document.createElement('p');n.className='myseo-analysis-note';n.textContent='Editorial suggestions only—not guaranteed ranking factors. Avoid unnatural keyword repetition.';o.appendChild(n);
}
function init(){
 ['myseo_keyphrase','myseo_related_keyphrases','myseo_title','myseo_description','content','title'].forEach(function(id){var x=document.getElementById(id);if(x)x.addEventListener('input',render);});
 if(window.wp&&wp.data&&wp.data.subscribe){var wait=false;wp.data.subscribe(function(){if(wait)return;wait=true;window.setTimeout(function(){wait=false;render();},250);});}
 render();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();