(function () {
'use strict';

function normalize(value) {
    return (value || '').toLocaleLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, ' ').replace(/\s+/g, ' ').trim();
}
function containsPhrase(text, phrase) {
    var t = normalize(text), p = normalize(phrase);
    if (!t || !p) return false;
    var escaped = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp('(^|[^\\p{L}\\p{N}])' + escaped + '($|[^\\p{L}\\p{N}])', 'u').test(t);
}
function editor() {
    return window.wp && wp.data && wp.data.select ? wp.data.select('core/editor') : null;
}
function getContent() {
    var e = editor();
    if (e && e.getEditedPostContent) return e.getEditedPostContent() || '';
    var field = document.getElementById('content');
    return field ? field.value : '';
}
function getTitle() {
    var e = editor();
    if (e && e.getEditedPostAttribute) return e.getEditedPostAttribute('title') || '';
    var field = document.getElementById('title');
    return field ? field.value : '';
}
function getSlug() {
    var e = editor();
    if (e && e.getEditedPostAttribute) return e.getEditedPostAttribute('slug') || '';
    var field = document.getElementById('post_name');
    return field ? field.value : '';
}
function plainText(html) {
    var node = document.createElement('div');
    node.innerHTML = html || '';
    return (node.textContent || '').replace(/\s+/g, ' ').trim();
}
function render() {
    var root = document.getElementById('myseo-seo-score');
    var keyphraseField = document.getElementById('myseo_keyphrase');
    var titleField = document.getElementById('myseo_title');
    var descriptionField = document.getElementById('myseo_description');
    if (!root || !keyphraseField) return;

    var phrase = keyphraseField.value.trim();
    var relatedField = document.getElementById('myseo_related_keyphrases');
    var relatedPhrases = relatedField ? relatedField.value.split(/[,;\\n]+/).map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 5) : [];
    if (!phrase) {
        root.innerHTML = '';
        var empty = document.createElement('p');
        empty.className = 'myseo-empty';
        empty.textContent = 'Add a focus keyphrase to calculate the content checklist score.';
        root.appendChild(empty);
        return;
    }

    var html = getContent();
    var text = plainText(html);
    var title = (titleField && titleField.value.trim()) || getTitle();
    var description = descriptionField ? descriptionField.value.trim() : '';
    var slug = getSlug().replace(/-/g, ' ');
    var firstWords = text.split(/\s+/).slice(0, 60).join(' ');
    var contentBox = document.createElement('div');
    contentBox.innerHTML = html;
    var headings = Array.prototype.map.call(contentBox.querySelectorAll('h1,h2,h3,h4,h5,h6'), function (node) {
        return node.textContent || '';
    }).join(' ');
    var wordCount = (text.match(/[\p{L}\p{N}]+/gu) || []).length;
    var images = Array.prototype.slice.call(contentBox.querySelectorAll('img'));
    var imagesWithAlt = images.filter(function (img) {
        return img.hasAttribute('alt') && img.getAttribute('alt').trim() !== '';
    }).length;

    var phraseOccurrences = 0;
    var normalizedText = normalize(text);
    var normalizedPhrase = normalize(phrase);
    if (normalizedPhrase) {
        var escapedPhrase = normalizedPhrase.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
        var phrasePattern = new RegExp('(^|[^\\\\p{L}\\\\p{N}])' + escapedPhrase + '($|[^\\\\p{L}\\\\p{N}])', 'gu');
        phraseOccurrences = (normalizedText.match(phrasePattern) || []).length;
    }
    var density = wordCount > 0 ? (phraseOccurrences / wordCount) * 100 : 0;
    var relatedFound = relatedPhrases.filter(function (item) { return containsPhrase(text, item); }).length;

    var checks = [
        {label: 'Focus keyphrase appears in SEO title', ok: containsPhrase(title, phrase), advice: 'Add the keyphrase naturally to the SEO title.'},
        {label: 'Focus keyphrase appears in meta description', ok: containsPhrase(description, phrase), advice: 'Consider including the keyphrase in the meta description.'},
        {label: 'Focus keyphrase appears in URL slug', ok: containsPhrase(slug, phrase), advice: 'Consider including the keyphrase in the URL slug where appropriate.'},
        {label: 'Focus keyphrase appears near the beginning', ok: containsPhrase(firstWords, phrase), advice: 'Mention the keyphrase naturally near the beginning.'},
        {label: 'Focus keyphrase appears in a heading', ok: containsPhrase(headings, phrase), advice: 'Use the keyphrase or a natural variation in a relevant heading.'},
        {label: 'Focus keyphrase appears in the body', ok: containsPhrase(text, phrase), advice: 'Use the keyphrase naturally in the article body.'},
        {label: 'Focus keyphrase frequency review', ok: wordCount === 0 || density <= 2.5, advice: 'The phrase appears frequently by this simple estimate. Review for repetition; there is no universal ideal density.'},
        {label: 'Related keyphrase coverage', ok: relatedPhrases.length === 0 || relatedFound > 0, advice: relatedPhrases.length === 0 ? 'Optional: add related phrases to check topic coverage.' : 'Consider including a relevant related phrase naturally.'},
        {label: 'SEO title length is 30–60 characters', ok: title.length >= 30 && title.length <= 60, advice: 'Aim for a concise title; 30–60 characters is a working editorial guideline, not a Google rule.'},
        {label: 'Meta description length is 120–160 characters', ok: description.length >= 120 && description.length <= 160, advice: 'Aim for a useful summary; 120–160 characters is a working guideline, not a display guarantee.'},
        {label: 'Content contains at least 300 words', ok: wordCount >= 300, advice: 'Consider whether the topic needs more useful detail. There is no universal ideal word count.'},
        {label: 'Images have descriptive alt text', ok: images.length === 0 || imagesWithAlt === images.length, advice: 'Add meaningful alt text to informative images; use empty alt for decorative images and review them separately.'}
    ];

    var earned = checks.filter(function (item) { return item.ok; }).length;
    var score = Math.round((earned / checks.length) * 100);
    var heading = document.createElement('div');
    heading.className = 'myseo-score-heading';
    var number = document.createElement('strong');
    number.className = 'myseo-score-number';
    number.textContent = score + '/100';
    var label = document.createElement('span');
    label.className = 'myseo-score-label';
    label.textContent = score >= 80 ? 'Good checklist coverage' : (score >= 50 ? 'Some improvements available' : 'More optimization work suggested');
    heading.append(number, label);

    var progress = document.createElement('div');
    progress.className = 'myseo-score-track';
    progress.setAttribute('role', 'progressbar');
    progress.setAttribute('aria-valuemin', '0');
    progress.setAttribute('aria-valuemax', '100');
    progress.setAttribute('aria-valuenow', String(score));
    var fill = document.createElement('span');
    fill.style.width = score + '%';
    progress.appendChild(fill);

    var list = document.createElement('ul');
    list.className = 'myseo-check-list myseo-score-checks';
    checks.forEach(function (item) {
        var li = document.createElement('li');
        li.className = item.ok ? 'is-good' : 'needs-work';
        var mark = document.createElement('span');
        mark.className = 'myseo-check-mark';
        mark.textContent = item.ok ? '✓' : '!';
        var strong = document.createElement('strong');
        strong.textContent = item.label + ': ';
        var detail = document.createElement('span');
        detail.textContent = item.ok ? 'Pass' : item.advice;
        li.append(mark, strong, detail);
        list.appendChild(li);
    });

    var note = document.createElement('p');
    note.className = 'myseo-analysis-note';
    note.textContent = 'This is a transparent editorial checklist based on visible checks. Related phrase coverage is optional, and phrase frequency is only a review signal—not a target density. This is not a Google score or ranking prediction.';
    root.innerHTML = '';
    root.append(heading, progress, list, note);
}

function init() {
    ['myseo_keyphrase', 'myseo_related_keyphrases', 'myseo_title', 'myseo_description', 'content', 'title', 'post_name'].forEach(function (id) {
        var field = document.getElementById(id);
        if (field) field.addEventListener('input', render);
    });
    if (window.wp && wp.data && wp.data.subscribe) {
        var scheduled = false;
        wp.data.subscribe(function () {
            if (scheduled) return;
            scheduled = true;
            window.setTimeout(function () { scheduled = false; render(); }, 250);
        });
    }
    render();
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
})();
