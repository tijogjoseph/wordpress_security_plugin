(function () {
    'use strict';

    function plainText(html) {
        var node = document.createElement('div');
        node.innerHTML = html || '';
        return (node.textContent || node.innerText || '').replace(/\s+/g, ' ').trim();
    }

    function getContent() {
        if (window.wp && wp.data && wp.data.select) {
            var editor = wp.data.select('core/editor');
            if (editor && typeof editor.getEditedPostContent === 'function') {
                return editor.getEditedPostContent();
            }
        }
        var classic = document.getElementById('content');
        return classic ? classic.value : '';
    }

    function words(text) {
        return (text.match(/[\p{L}\p{N}]+(?:['’_-][\p{L}\p{N}]+)*/gu) || []).length;
    }

    function sentences(text) {
        return (text.match(/[^.!?]+[.!?]+|[^.!?]+$/gu) || [])
            .map(function (s) { return s.trim(); })
            .filter(Boolean);
    }

    function render() {
        var output = document.getElementById('myseo-readability-results');
        if (!output) return;

        var text = plainText(getContent());
        output.textContent = '';

        if (!text) {
            var empty = document.createElement('p');
            empty.className = 'myseo-empty';
            empty.textContent = 'Add article content to see readability suggestions.';
            output.appendChild(empty);
            return;
        }

        var sentenceList = sentences(text);
        var sentenceCounts = sentenceList.map(words);
        var longSentences = sentenceCounts.filter(function (n) { return n > 25; }).length;

        var paragraphTexts = text.split(/\n+/).map(function (p) { return p.trim(); }).filter(Boolean);
        // Gutenberg content may flatten block boundaries in textContent. Use
        // source paragraph tags as a better paragraph approximation.
        var html = getContent();
        var temp = document.createElement('div');
        temp.innerHTML = html;
        var sourceParagraphs = Array.prototype.map.call(temp.querySelectorAll('p'), function (p) {
            return (p.textContent || '').trim();
        }).filter(Boolean);
        if (sourceParagraphs.length) paragraphTexts = sourceParagraphs;

        var longParagraphs = paragraphTexts.filter(function (p) { return words(p) > 120; }).length;
        var passivePatterns = /\b(?:am|is|are|was|were|be|been|being|get|gets|got)\s+(?:\w+\s+){0,2}(?:made|done|written|known|seen|given|taken|built|found|used|created|designed|developed|implemented|supported|managed|provided|required|published|updated|configured|generated|installed|selected|sent|shown|stored|checked|approved|completed|added|removed|considered|\w+ed)\b/gi;
        var passiveCount = sentenceList.filter(function (s) { return passivePatterns.test(s); }).length;
        passivePatterns.lastIndex = 0;

        var transitionWords = /\b(?:however|therefore|additionally|also|furthermore|moreover|for example|for instance|in addition|as a result|consequently|meanwhile|instead|first|second|finally|although|because|in contrast|on the other hand|next)\b/i;
        var transitionCount = sentenceList.filter(function (s) { return transitionWords.test(s); }).length;

        var repeated = 0;
        for (var i = 1; i < sentenceList.length; i++) {
            var a = (sentenceList[i - 1].match(/^[\s"'“(]*([\p{L}\p{N}]+)/u) || [])[1];
            var b = (sentenceList[i].match(/^[\s"'“(]*([\p{L}\p{N}]+)/u) || [])[1];
            if (a && b && a.toLowerCase() === b.toLowerCase()) repeated++;
        }

        var average = sentenceCounts.length
            ? sentenceCounts.reduce(function (sum, n) { return sum + n; }, 0) / sentenceCounts.length
            : 0;

        var checks = [
            ['Sentence length', longSentences === 0, longSentences
                ? longSentences + ' sentence(s) exceed 25 words. Consider splitting them.'
                : 'No sentences exceed the suggested 25-word review threshold.'],
            ['Paragraph length', longParagraphs === 0, longParagraphs
                ? longParagraphs + ' paragraph(s) exceed 120 words. Consider breaking them up.'
                : 'No paragraphs exceed the suggested 120-word review threshold.'],
            ['Passive voice', passiveCount === 0, passiveCount
                ? passiveCount + ' sentence(s) may use passive voice. Review whether active voice is clearer.'
                : 'No likely passive-voice patterns were detected.'],
            ['Transition words', sentenceList.length < 3 || transitionCount > 0, sentenceList.length < 3
                ? 'Use connecting words where they improve flow.'
                : (transitionCount ? 'Transition words found in ' + transitionCount + ' sentence(s).' : 'Consider adding transitions such as “however” or “therefore” where useful.')],
            ['Consecutive sentence openings', repeated === 0, repeated
                ? repeated + ' consecutive sentence pair(s) start with the same word. Vary openings where possible.'
                : 'No repeated consecutive sentence openings detected.']
        ];

        var summary = document.createElement('p');
        summary.className = 'myseo-readability-summary';
        summary.textContent = words(text) + ' words · ' + sentenceList.length + ' sentences · average ' + average.toFixed(1) + ' words per sentence';
        output.appendChild(summary);

        var list = document.createElement('ul');
        list.className = 'myseo-check-list';
        checks.forEach(function (check) {
            var li = document.createElement('li');
            li.className = check[1] ? 'is-good' : 'needs-work';
            var mark = document.createElement('span');
            mark.className = 'myseo-check-mark';
            mark.textContent = check[1] ? '✓' : '!';
            var label = document.createElement('strong');
            label.textContent = check[0] + ': ';
            var message = document.createElement('span');
            message.textContent = check[2];
            li.append(mark, label, message);
            list.appendChild(li);
        });
        output.appendChild(list);

        var note = document.createElement('p');
        note.className = 'myseo-analysis-note';
        note.textContent = 'Readability checks use simple language heuristics. They can miss context and may flag valid writing; review suggestions manually.';
        output.appendChild(note);
    }

    function init() {
        var classic = document.getElementById('content');
        if (classic) classic.addEventListener('input', render);
        if (window.wp && wp.data && wp.data.subscribe) {
            var pending = false;
            wp.data.subscribe(function () {
                if (pending) return;
                pending = true;
                window.setTimeout(function () { pending = false; render(); }, 300);
            });
        }
        render();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
