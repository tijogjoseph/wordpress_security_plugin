(function ($) {
    'use strict';

    $(function () {
        var $root = $('#myseo-serp-preview');
        if (!$root.length) return;

        var $title = $('#myseo_title');
        var $description = $('#myseo_description');
        var $socialTitle = $('#myseo_social_title');
        var $socialDescription = $('#myseo_social_description');
        var $previewTitle = $('#myseo-preview-title');
        var $previewDescription = $('#myseo-preview-description');
        var $titleMeasure = $('#myseo-title-measure');
        var $descriptionMeasure = $('#myseo-description-measure');
        var defaultTitle = $root.data('default-title') || document.title;
        var pageUrl = $root.data('page-url') || window.location.href;
        var canvas = document.createElement('canvas');
        var context = canvas.getContext ? canvas.getContext('2d') : null;

        function clean(value) {
            return String(value || '').replace(/\s+/g, ' ').trim();
        }

        function estimatedWidth(text, font) {
            if (!context) return 0;
            context.font = font;
            return Math.round(context.measureText(text).width);
        }

        function update() {
            var title = clean($title.val()) || defaultTitle;
            var description = clean($description.val());
            if (!description) {
                description = clean($previewDescription.data('fallback')) || 'Add a meta description to preview how a search snippet may appear.';
            }

            $previewTitle.text(title);
            $previewDescription.text(description);

            var titleWidth = estimatedWidth(title, '20px Arial');
            var descriptionWidth = estimatedWidth(description, '14px Arial');
            var titleLabel = 'Title: ' + title.length + ' characters · approx. ' + titleWidth + ' px';
            var descriptionLabel = 'Description: ' + description.length + ' characters · approx. ' + descriptionWidth + ' px';
            $titleMeasure.text(titleLabel);
            $descriptionMeasure.text(descriptionLabel);

            $titleMeasure.toggleClass('is-long', titleWidth > 600);
            $descriptionMeasure.toggleClass('is-long', descriptionWidth > 920);
        }

        function setDevice(device) {
            var mobile = device === 'mobile';
            $('#myseo-google-preview')
                .toggleClass('is-mobile', mobile)
                .toggleClass('is-desktop', !mobile);
            $root.find('[data-preview-device]').each(function () {
                var active = $(this).data('preview-device') === device;
                $(this).toggleClass('is-active', active).attr('aria-pressed', active ? 'true' : 'false');
            });
        }

        $previewDescription.data('fallback', $previewDescription.text());
        $root.on('click', '[data-preview-device]', function () {
            setDevice($(this).data('preview-device'));
        });
        $title.add($description).on('input change', update);
        update();

        // Social preview updates when social fields are edited, while keeping the
        // Google preview tied to SEO title and meta description.
        var $socialPanel = $('.myseo-social-fields');
        if ($socialPanel.length) {
            var socialPreview = $('<div class="myseo-social-card-preview" aria-live="polite"><div class="myseo-social-preview-heading"><h4>Social sharing preview</h4><div class="myseo-social-preview-tabs" role="group" aria-label="Social preview layout"><button type="button" class="button is-active" data-social-layout="compact" aria-pressed="true">Facebook / LinkedIn</button><button type="button" class="button" data-social-layout="large" aria-pressed="false">Large image card</button></div></div><div class="myseo-social-image-controls"><span class="description">Image fit:</span><div class="myseo-social-fit-tabs" role="group" aria-label="Social image fit"><button type="button" class="button is-active" data-social-fit="cover" aria-pressed="true">Cover</button><button type="button" class="button" data-social-fit="contain" aria-pressed="false">Contain</button></div><label class="myseo-social-position-control">Image position <select data-social-position><option value="center">Center</option><option value="top">Top</option><option value="bottom">Bottom</option><option value="left">Left</option><option value="right">Right</option></select></label></div><div class="myseo-social-card is-compact"><div class="myseo-social-card-image"></div><div class="myseo-social-card-copy"><strong></strong><p></p><small></small></div></div><p class="description">Approximate social card previews. These controls affect only this preview; social platforms control their final crop and layout.</p></div>');
            $socialPanel.append(socialPreview);

            function updateSocial() {
                var title = clean($socialTitle.val()) || clean($title.val()) || defaultTitle;
                var description = clean($socialDescription.val()) || clean($description.val()) || 'Add a description to preview your social card.';
                var image = clean($('#myseo_social_image').val());
                if (!image) {
                    var $featured = $('.editor-post-featured-image img, .components-responsive-wrapper img').first();
                    image = $featured.attr('src') || '';
                }
                socialPreview.find('.myseo-social-card-copy strong').text(title);
                socialPreview.find('.myseo-social-card-copy p').text(description);
                socialPreview.find('.myseo-social-card-copy small').text((new URL(pageUrl, window.location.href)).hostname);
                var $image = socialPreview.find('.myseo-social-card-image');
                if (image) {
                    $image.css('background-image', 'url("' + image.replace(/["\\]/g, '') + '")').show();
                } else {
                    $image.css('background-image', 'none').hide();
                }
            }

            function setSocialLayout(layout) {
                var large = layout === 'large';
                socialPreview.find('.myseo-social-card')
                    .toggleClass('is-large', large)
                    .toggleClass('is-compact', !large);
                socialPreview.find('[data-social-layout]').each(function () {
                    var active = $(this).data('social-layout') === layout;
                    $(this).toggleClass('is-active', active)
                        .attr('aria-pressed', active ? 'true' : 'false');
                });
            }

            function setSocialFit(fit) {
                var $cardImage = socialPreview.find('.myseo-social-card-image');
                $cardImage.css('background-size', fit === 'contain' ? 'contain' : 'cover');
                socialPreview.find('[data-social-fit]').each(function () {
                    var active = $(this).data('social-fit') === fit;
                    $(this).toggleClass('is-active', active)
                        .attr('aria-pressed', active ? 'true' : 'false');
                });
            }

            function setSocialPosition(position) {
                var positions = {
                    center: 'center center',
                    top: 'center top',
                    bottom: 'center bottom',
                    left: 'left center',
                    right: 'right center'
                };
                socialPreview.find('.myseo-social-card-image')
                    .css('background-position', positions[position] || positions.center);
            }

            socialPreview.on('click', '[data-social-layout]', function () {
                setSocialLayout($(this).data('social-layout'));
            });
            socialPreview.on('click', '[data-social-fit]', function () {
                setSocialFit($(this).data('social-fit'));
            });
            socialPreview.on('change', '[data-social-position]', function () {
                setSocialPosition($(this).val());
            });
            $socialTitle.add($socialDescription).add($('#myseo_social_image')).on('input change', updateSocial);
            updateSocial();
            setSocialLayout('compact');
            setSocialFit('cover');
            setSocialPosition('center');
        }
    });
})(jQuery);
