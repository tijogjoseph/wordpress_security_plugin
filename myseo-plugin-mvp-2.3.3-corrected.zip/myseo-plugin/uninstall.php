<?php
/**
 * MySEO uninstall handler.
 *
 * We intentionally retain SEO metadata and settings on uninstall.
 * A future settings screen may offer an explicit data-removal option.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}
