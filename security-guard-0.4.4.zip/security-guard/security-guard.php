<?php
/**
 * Plugin Name: Security Guard
 * Description: Adds configurable WordPress security protections.
 * Version: 0.4.4
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * License: GPL-2.0-or-later
 * Text Domain: security-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard {
	const OPTION_NAME = 'secure_login_guard_settings';
	const SETTINGS_PAGE = 'security-guard';
	private static $settings_page_hook = '';

	/**
	 * Register WordPress hooks.
	 */
	public static function init() {
		require_once __DIR__ . '/includes/class-slg-firewall.php';
		require_once __DIR__ . '/includes/class-slg-backups.php';
		require_once __DIR__ . '/includes/class-slg-scanner.php';
		Secure_Login_Guard_Firewall::init();
		Secure_Login_Guard_Backups::init();
		Secure_Login_Guard_Scanner::init();
		add_filter( 'authenticate', array( __CLASS__, 'check_lockout' ), 30, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'check_login_captcha' ), 98, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'check_two_factor' ), 99, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'record_failure' ) );
		add_action( 'wp_login', array( __CLASS__, 'clear_login_failures' ), 10, 2 );
		add_action( 'wp_login', array( __CLASS__, 'send_login_notification' ), 20, 2 );
		add_action( 'login_form_middle', array( __CLASS__, 'render_login_2fa_field' ) );
		add_action( 'login_form', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'register_form', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'enqueue_captcha_script' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_profile_actions_script' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'update_option_' . self::OPTION_NAME, array( 'Secure_Login_Guard_Scanner', 'settings_updated' ), 10, 2 );
		add_action( 'show_user_profile', array( __CLASS__, 'render_2fa_profile' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'render_2fa_profile' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_2fa_profile' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_2fa_profile' ) );
		add_filter( 'registration_errors', array( __CLASS__, 'validate_registration_password' ), 10, 3 );
		add_filter( 'registration_errors', array( __CLASS__, 'validate_registration_captcha' ), 20, 3 );
		add_action( 'user_profile_update_errors', array( __CLASS__, 'validate_profile_password' ), 10, 3 );
		add_action( 'validate_password_reset', array( __CLASS__, 'validate_reset_password' ), 10, 2 );
		add_action( 'comment_form_after_fields', array( __CLASS__, 'render_comment_honeypot' ) );
		add_action( 'comment_form_logged_in_after', array( __CLASS__, 'render_comment_honeypot' ) );
		add_action( 'comment_form_after_fields', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'comment_form_logged_in_after', array( __CLASS__, 'render_captcha_field' ) );
		add_filter( 'pre_comment_approved', array( __CLASS__, 'mark_honeypot_comment_as_spam' ), 10, 2 );
		add_filter( 'preprocess_comment', array( __CLASS__, 'check_comment_captcha' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_captcha_script' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_inactivity_script' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_inactivity_script' ) );
		add_action( 'wp_ajax_slg_activity', array( __CLASS__, 'record_activity' ) );
		add_action( 'admin_post_slg_download_backup', array( __CLASS__, 'download_database_backup' ) );
		add_action( 'admin_post_slg_scan_database', array( __CLASS__, 'run_database_scan' ) );
		add_action( 'admin_post_slg_revoke_sessions', array( __CLASS__, 'revoke_user_sessions' ) );
		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ), -10 );
		add_action( 'register_form', array( __CLASS__, 'render_registration_honeypot' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'add_settings_link' ) );
	}

	/**
	 * Install default settings without overwriting existing values.
	 */
	public static function activate() {
		if ( false === get_option( self::OPTION_NAME ) ) {
			add_option( self::OPTION_NAME, self::default_settings() );
		}
		Secure_Login_Guard_Firewall::install();
		Secure_Login_Guard_Backups::activate();
		Secure_Login_Guard_Scanner::activate();
		update_option( 'slg_version', '0.3.2', false );
	}

	public static function deactivate() {
		Secure_Login_Guard_Backups::deactivate();
		Secure_Login_Guard_Scanner::deactivate();
	}

	public static function maybe_upgrade() {
		if ( version_compare( get_option( 'slg_version', '0.0.0' ), '0.3.2', '<' ) ) {
			Secure_Login_Guard_Firewall::install();
			Secure_Login_Guard_Backups::activate();
			update_option( 'slg_version', '0.3.2', false );
		}
	}

	private static function default_settings() {
		return array(
			'failures_per_login' => 5,
			'failures_per_ip'    => 20,
			'window_minutes'     => 15,
			'lockout_minutes'    => 15,
			'inactivity_minutes' => 30,
			'minimum_password_length' => 12,
			'firewall_enabled' => 1,
			'captcha_site_key' => '',
			'captcha_secret_key' => '',
			'backup_directory' => '',
			'backup_retention' => 5,
			'file_monitoring_enabled' => 0,
			'login_notifications_enabled' => 1,
		);
	}

	private static function settings() {
		return wp_parse_args( get_option( self::OPTION_NAME, array() ), self::default_settings() );
	}

	/**
	 * Stop authentication when the corresponding rolling window is locked.
	 *
	 * @param WP_User|WP_Error|null $user     Authentication result so far.
	 * @param string                $username Submitted username.
	 * @param string                $password Submitted password.
	 * @return WP_User|WP_Error|null
	 */
	public static function check_lockout( $user, $username, $password ) {
		unset( $password );

		if ( $user instanceof WP_User ) {
			return $user;
		}

		$ip = self::client_ip();
		$login_state = self::get_state( self::login_key( $username, $ip ) );
		$ip_state = self::get_state( self::ip_key( $ip ) );
		$now = time();

		if ( $login_state['blocked_until'] > $now || $ip_state['blocked_until'] > $now ) {
			return new WP_Error(
				'slg_rate_limited',
				__( 'Too many failed sign-in attempts. Please wait before trying again.', 'security-guard' )
			);
		}

		return $user;
	}

	/**
	 * Record a failed login against the username/IP and, when available, the IP.
	 *
	 * @param string $username Submitted username.
	 */
	public static function record_failure( $username ) {
		$ip = self::client_ip();
		$settings = self::settings();
		$now = time();
		$window = absint( $settings['window_minutes'] ) * MINUTE_IN_SECONDS;
		$lockout = absint( $settings['lockout_minutes'] ) * MINUTE_IN_SECONDS;

		self::add_failure(
			self::login_key( $username, $ip ),
			absint( $settings['failures_per_login'] ),
			$window,
			$lockout,
			$now
		);

		if ( 'unknown' !== $ip ) {
			self::add_failure(
				self::ip_key( $ip ),
				absint( $settings['failures_per_ip'] ),
				$window,
				$lockout,
				$now
			);
		}
	}

	/**
	 * Clear the username-specific counter after a successful login.
	 *
	 * The IP-wide counter is deliberately retained to avoid making password
	 * spraying easier when another user on the same address signs in.
	 *
	 * @param string  $user_login User login.
	 * @param WP_User $user       Authenticated user.
	 */
	public static function clear_login_failures( $user_login, $user ) {
		unset( $user );
		delete_transient( self::login_key( $user_login, self::client_ip() ) );
	}

	public static function send_login_notification( $user_login, $user ) {
		unset( $user_login );
		if (
			! $user instanceof WP_User
			|| empty( self::settings()['login_notifications_enabled'] )
			|| ! is_email( $user->user_email )
		) {
			return;
		}

		$ip = self::client_ip();
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) && is_string( $_SERVER['HTTP_USER_AGENT'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
			: __( 'Unknown browser', 'security-guard' );
		$browser = self::browser_label( $user_agent );
		$subject = sprintf(
			/* translators: %s is the site name. */
			__( '[%s] Successful account sign-in', 'security-guard' ),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES )
		);
		$message = implode(
			"\n",
			array(
				__( 'A successful sign-in was detected for your account.', 'security-guard' ),
				sprintf( __( 'Account: %s', 'security-guard' ), $user->user_login ),
				sprintf( __( 'Time: %s UTC', 'security-guard' ), gmdate( 'Y-m-d H:i:s' ) ),
				sprintf( __( 'Server IP: %s', 'security-guard' ), $ip ),
				sprintf( __( 'Browser: %s', 'security-guard' ), $browser ),
				'',
				__( 'If this was not you, change the account password and revoke all other sessions immediately.', 'security-guard' ),
				admin_url( 'profile.php' ),
			)
		);
		wp_mail( $user->user_email, $subject, $message );
	}

	private static function browser_label( $user_agent ) {
		if ( '' === $user_agent ) {
			return __( 'Unknown browser', 'security-guard' );
		}
		if ( false !== stripos( $user_agent, 'Edg/' ) ) {
			return 'Microsoft Edge';
		}
		if ( false !== stripos( $user_agent, 'Chrome/' ) || false !== stripos( $user_agent, 'Chromium/' ) ) {
			return 'Chromium-based browser';
		}
		if ( false !== stripos( $user_agent, 'Firefox/' ) ) {
			return 'Firefox';
		}
		if ( false !== stripos( $user_agent, 'Safari/' ) ) {
			return 'Safari';
		}
		return __( 'Unrecognized browser', 'security-guard' );
	}

	public static function revoke_user_sessions() {
		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		if (
			$user_id < 1
			|| ! current_user_can( 'edit_user', $user_id )
		) {
			wp_die( esc_html__( 'You are not allowed to manage sessions for this account.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_revoke_sessions_' . $user_id );

		$scope = isset( $_POST['slg_revoke_scope'] ) && is_string( $_POST['slg_revoke_scope'] )
			? sanitize_key( wp_unslash( $_POST['slg_revoke_scope'] ) )
			: '';
		$manager = WP_Session_Tokens::get_instance( $user_id );
		if ( 'others' === $scope && $user_id === get_current_user_id() ) {
			$current_token = wp_get_session_token();
			if ( '' !== $current_token ) {
				$manager->destroy_others( $current_token );
			} else {
				$manager->destroy_all();
			}
		} elseif ( 'all' === $scope || 'others' === $scope ) {
			$manager->destroy_all();
		} else {
			wp_die( esc_html__( 'Invalid session revocation scope.', 'security-guard' ), '', array( 'response' => 400 ) );
		}

		$redirect = $user_id === get_current_user_id()
			? admin_url( 'profile.php' )
			: admin_url( 'user-edit.php?user_id=' . $user_id );
		wp_safe_redirect( $redirect );
		exit;
	}

	private static function add_failure( $key, $limit, $window, $lockout, $now ) {
		$state = self::get_state( $key );

		if ( $state['blocked_until'] > $now ) {
			return;
		}

		$state['failures'][] = $now;
		$state['failures'] = array_values(
			array_filter(
				$state['failures'],
				static function ( $timestamp ) use ( $now, $window ) {
					return $timestamp > $now - $window;
				}
			)
		);

		if ( count( $state['failures'] ) >= $limit ) {
			$state['blocked_until'] = $now + $lockout;
		}

		set_transient( $key, $state, max( $window, $lockout ) + MINUTE_IN_SECONDS );
	}

	private static function get_state( $key ) {
		$state = get_transient( $key );

		if ( ! is_array( $state ) ) {
			return array(
				'failures'      => array(),
				'blocked_until' => 0,
			);
		}

		return array(
			'failures'      => isset( $state['failures'] ) && is_array( $state['failures'] ) ? $state['failures'] : array(),
			'blocked_until' => isset( $state['blocked_until'] ) ? absint( $state['blocked_until'] ) : 0,
		);
	}

	private static function client_ip() {
		if ( empty( $_SERVER['REMOTE_ADDR'] ) || ! is_string( $_SERVER['REMOTE_ADDR'] ) ) {
			return 'unknown';
		}

		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : 'unknown';
	}

	private static function login_key( $username, $ip ) {
		$normalized_username = is_scalar( $username ) ? strtolower( trim( (string) $username ) ) : '';
		return self::transient_key( 'login', $normalized_username . '|' . $ip );
	}

	private static function ip_key( $ip ) {
		return self::transient_key( 'ip', $ip );
	}

	private static function transient_key( $scope, $value ) {
		return 'slg_' . hash_hmac( 'sha256', $scope . '|' . $value, wp_salt( 'auth' ) );
	}

	public static function register_settings() {
		register_setting(
			'secure_login_guard',
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => self::default_settings(),
			)
		);
	}

	public static function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();

		return array(
			'failures_per_login' => self::bounded_int( $input, 'failures_per_login', 5, 3, 20 ),
			'failures_per_ip'    => self::bounded_int( $input, 'failures_per_ip', 20, 10, 100 ),
			'window_minutes'     => self::bounded_int( $input, 'window_minutes', 15, 5, 1440 ),
			'lockout_minutes'    => self::bounded_int( $input, 'lockout_minutes', 15, 1, 1440 ),
			'inactivity_minutes' => self::bounded_int( $input, 'inactivity_minutes', 30, 5, 1440 ),
			'minimum_password_length' => self::bounded_int( $input, 'minimum_password_length', 12, 10, 64 ),
			'firewall_enabled' => isset( $input['firewall_enabled'] ) && is_scalar( $input['firewall_enabled'] ) && '1' === (string) $input['firewall_enabled'] ? 1 : 0,
			'captcha_site_key' => isset( $input['captcha_site_key'] ) && is_string( $input['captcha_site_key'] ) ? sanitize_text_field( $input['captcha_site_key'] ) : '',
			'captcha_secret_key' => self::retained_secret( $input, 'captcha_secret_key' ),
			'backup_directory' => isset( $input['backup_directory'] ) && is_string( $input['backup_directory'] ) ? trim( sanitize_text_field( $input['backup_directory'] ) ) : self::settings()['backup_directory'],
			'backup_retention' => self::bounded_int( $input, 'backup_retention', 5, 1, 30 ),
			'file_monitoring_enabled' => isset( $input['file_monitoring_enabled'] ) && is_scalar( $input['file_monitoring_enabled'] ) && '1' === (string) $input['file_monitoring_enabled'] ? 1 : 0,
			'login_notifications_enabled' => isset( $input['login_notifications_enabled'] ) && is_scalar( $input['login_notifications_enabled'] ) && '1' === (string) $input['login_notifications_enabled'] ? 1 : 0,
		);
	}

	private static function retained_secret( $input, $key ) {
		if ( isset( $input[ $key ] ) && is_string( $input[ $key ] ) && '' !== trim( $input[ $key ] ) ) {
			return sanitize_text_field( $input[ $key ] );
		}
		$current = get_option( self::OPTION_NAME, array() );
		return isset( $current[ $key ] ) ? $current[ $key ] : '';
	}

	private static function bounded_int( $input, $key, $default, $minimum, $maximum ) {
		if ( ! isset( $input[ $key ] ) || ! is_numeric( $input[ $key ] ) ) {
			return $default;
		}

		return min( $maximum, max( $minimum, absint( $input[ $key ] ) ) );
	}

	public static function add_settings_page() {
		self::$settings_page_hook = add_options_page(
			__( 'Security Guard', 'security-guard' ),
			__( 'Security Guard', 'security-guard' ),
			'manage_options',
			self::SETTINGS_PAGE,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	public static function enqueue_admin_assets( $hook ) {
		if ( self::$settings_page_hook !== $hook ) {
			return;
		}
		wp_enqueue_style(
			'secure-login-guard-admin',
			plugins_url( 'assets/admin.css', __FILE__ ),
			array(),
			'0.4.4'
		);
		wp_enqueue_script(
			'secure-login-guard-admin',
			plugins_url( 'assets/admin.js', __FILE__ ),
			array( 'wp-element' ),
			'0.4.4',
			true
		);
		$settings = self::settings();
		$settings = array_intersect_key(
			$settings,
			array_flip(
				array(
					'failures_per_login',
					'failures_per_ip',
					'window_minutes',
					'lockout_minutes',
					'inactivity_minutes',
					'minimum_password_length',
					'firewall_enabled',
					'captcha_site_key',
					'backup_directory',
					'backup_retention',
					'file_monitoring_enabled',
					'login_notifications_enabled',
				)
			)
		);
		wp_localize_script(
			'secure-login-guard-admin',
			'SLGAdmin',
			array(
				'settings' => $settings,
				'captchaConfigured' => ! empty( self::settings()['captcha_secret_key'] ),
				'backup' => Secure_Login_Guard_Backups::get_admin_data(),
				'checks' => self::get_security_checks(),
				'scan' => self::get_database_scan_results(),
				'firewallEvents' => Secure_Login_Guard_Firewall::get_admin_events(),
				'urls' => array(
					'options' => admin_url( 'options.php' ),
					'adminPost' => admin_url( 'admin-post.php' ),
					'settingsNonce' => wp_create_nonce( 'secure_login_guard-options' ),
					'scanNonce' => wp_create_nonce( 'slg_scan_database' ),
					'downloadBackupNonce' => wp_create_nonce( 'slg_download_backup' ),
					'runBackupNonce' => wp_create_nonce( 'slg_run_backup' ),
					'scanFilesNonce' => wp_create_nonce( 'slg_scan_files' ),
					'runFileMonitoringNonce' => wp_create_nonce( 'slg_run_file_monitoring' ),
					'resetFileBaselineNonce' => wp_create_nonce( 'slg_reset_file_baseline' ),
					'profileUrl' => admin_url( 'profile.php' ),
				),
				'fileScan' => Secure_Login_Guard_Scanner::get_admin_data(),
				'fileMonitoring' => Secure_Login_Guard_Scanner::get_monitoring_data(),
				'text' => self::admin_text(),
			)
		);
	}

	public static function enqueue_profile_actions_script( $hook ) {
		if ( ! in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) ) {
			return;
		}
		wp_enqueue_script(
			'security-guard-profile-actions',
			plugins_url( 'assets/profile-actions.js', __FILE__ ),
			array( 'user-profile' ),
			'0.4.4',
			true
		);
	}

	private static function admin_text() {
		return array(
			'brand' => __( 'Security Guard', 'security-guard' ),
			'pageDescription' => __( 'Your site protection at a glance. Review status and manage your security controls below.', 'security-guard' ),
			'protection' => __( 'Protection settings', 'security-guard' ),
			'protectionDescription' => __( 'Tune login safeguards and spam prevention.', 'security-guard' ),
			'failuresPerLogin' => __( 'Failures per username and IP', 'security-guard' ),
			'failuresPerIp' => __( 'Failures per IP address', 'security-guard' ),
			'windowMinutes' => __( 'Counting window (minutes)', 'security-guard' ),
			'lockoutMinutes' => __( 'Lockout duration (minutes)', 'security-guard' ),
			'inactivityMinutes' => __( 'Inactivity logout (minutes)', 'security-guard' ),
			'passwordLength' => __( 'Minimum password length', 'security-guard' ),
			'passwordDescription' => __( 'New or changed passwords must meet this length and include at least three character classes: lowercase, uppercase, number, or symbol.', 'security-guard' ),
			'firewallDescription' => __( 'Inspect requests and temporarily block high-confidence malicious patterns', 'security-guard' ),
			'siteKey' => __( 'Cloudflare Turnstile site key', 'security-guard' ),
			'secretKey' => __( 'Cloudflare Turnstile secret key', 'security-guard' ),
			'configuredKeepKey' => __( 'Configured; leave blank to keep current key', 'security-guard' ),
			'notConfigured' => __( 'Not configured', 'security-guard' ),
			'backupRetention' => __( 'Scheduled backup retention', 'security-guard' ),
			'retentionDescription' => __( 'Keep this many successful database + file backup archives.', 'security-guard' ),
			'backupDirectory' => __( 'Private backup directory (optional)', 'security-guard' ),
			'backupDirectoryDescription' => __( 'Enter an absolute server path approved by your host and outside the public web root. Leave blank to use the automatic location. The directory must be writable by PHP; public paths are rejected. Changing this path does not move existing archives.', 'security-guard' ),
			'backupDirectoryPlaceholder' => __( 'Automatic private location', 'security-guard' ),
			'fileMonitoring' => __( 'Scheduled file integrity monitoring', 'security-guard' ),
			'fileMonitoringDescription' => __( 'Run a report-only file scan weekly and email the site administrator when new findings appear. The first successful scan establishes the baseline and does not send an alert. Scans use WordPress Cron and may be delayed on low-traffic sites.', 'security-guard' ),
			'fileMonitoringStatus' => __( 'Scheduled monitoring', 'security-guard' ),
			'fileMonitoringEnabled' => __( 'Enabled', 'security-guard' ),
			'fileMonitoringDisabled' => __( 'Disabled', 'security-guard' ),
			'fileMonitoringNext' => __( 'Next scan: %s UTC.', 'security-guard' ),
			'fileMonitoringLast' => __( 'Last scan: %s UTC.', 'security-guard' ),
			'fileMonitoringNoScan' => __( 'No scheduled scan has completed yet.', 'security-guard' ),
			'fileMonitoringAlert' => __( 'New findings detected: an email alert was sent to the site administrator.', 'security-guard' ),
			'fileMonitoringAlertFailed' => __( 'New findings were detected, but the alert email could not be sent. Check the site mail configuration.', 'security-guard' ),
			'fileMonitoringBaseline' => __( 'Baseline established. Email alerts are sent for new findings in later scans.', 'security-guard' ),
			'fileMonitoringError' => __( 'The scheduled scan failed: %s', 'security-guard' ),
			'loginNotifications' => __( 'Successful login email notifications', 'security-guard' ),
			'loginNotificationsDescription' => __( 'Email account owners after a successful sign-in. The message includes the login time, trusted server IP address, and browser label. It is disabled by default after you turn off this setting.', 'security-guard' ),
			'fileMonitoringRunning' => __( 'Scan in progress', 'security-guard' ),
			'fileMonitoringProgress' => __( 'PHP files scanned: %d.', 'security-guard' ),
			'runFileMonitoring' => __( 'Run file monitoring now', 'security-guard' ),
			'resetFileBaseline' => __( 'Reset file baseline', 'security-guard' ),
			'fileScan' => __( 'PRO preview: malware and file integrity scan', 'security-guard' ),
			'fileScanDescription' => __( 'Compare WordPress core files to official checksums and look for selected suspicious PHP patterns and executable files in uploads. This report-only scan never changes or quarantines files.', 'security-guard' ),
			'fileScanButton' => __( 'Scan site files', 'security-guard' ),
			'fileScanNoResults' => __( 'No findings matched the checks performed. This does not prove the site is malware-free.', 'security-guard' ),
			'fileScanStats' => __( 'Core files checked: %1$d; changed: %2$d; missing: %3$d. PHP files scanned: %4$d; suspicious patterns: %5$d; executable files in uploads: %6$d.', 'security-guard' ),
			'fileScanIncomplete' => __( 'Scan coverage was incomplete because some files could not be read, exceeded the scan size limits, or the findings display limit was reached.', 'security-guard' ),
			'fileScanSkippedFiles' => __( 'Oversized files skipped: %1$d. Unreadable files skipped: %2$d.', 'security-guard' ),
			'fileScanPath' => __( 'File', 'security-guard' ),
			'fileScanFinding' => __( 'Finding', 'security-guard' ),
			'fileScanDetails' => __( 'Details', 'security-guard' ),
			'fileScanFingerprint' => __( 'SHA-256 fingerprint', 'security-guard' ),
			'fileScanCaution' => __( 'A finding is not proof of compromise. Review each file in context and compare it with a trusted source. The scan does not modify files.', 'security-guard' ),
			'ipNote' => __( 'The IP address is taken only from the web server REMOTE_ADDR value. If your site is behind a proxy, configure the proxy/web server to set this value correctly; forwarded headers are intentionally not trusted.', 'security-guard' ),
			'twoFactor' => __( 'Two-factor authentication', 'security-guard' ),
			'twoFactorDescription' => __( 'Users can enable authenticator-app TOTP (compatible with Google Authenticator and Microsoft Authenticator) and recovery codes from their own profile under Users > Profile. Email OTP is available as a fallback for users with TOTP enabled.', 'security-guard' ),
			'accountSessionsDescription' => __( 'Review active sessions and log out other or all sessions from your profile.', 'security-guard' ),
			'openProfileSessions' => __( 'Open account and session settings', 'security-guard' ),
			'smsNote' => __( 'SMS OTP is not included because it requires a provider account, credentials, and delivery policy.', 'security-guard' ),
			'backups' => __( 'Backups and disaster recovery', 'security-guard' ),
			'backupDescription' => __( 'Weekly database + file backups are scheduled with WordPress Cron. Backups can take several minutes on larger sites. Archives are kept in a private directory outside the web root; public paths are rejected.', 'security-guard' ),
			'backupExecutionNote' => __( 'Keep this page open while a manual backup runs. The plugin requests unlimited PHP execution time; a host or web-server timeout may still stop a very large backup.', 'security-guard' ),
			'runBackup' => __( 'Run database + file backup now', 'security-guard' ),
			'availableArchives' => __( 'Available backup archives', 'security-guard' ),
			'download' => __( 'Download', 'security-guard' ),
			'manualBackupDescription' => __( 'Manual database-only download is also available. Backups contain sensitive data. Test restoration and keep a separate off-site copy.', 'security-guard' ),
			'downloadDatabase' => __( 'Download database backup', 'security-guard' ),
			'securityChecks' => __( 'Security checks', 'security-guard' ),
			'checksDescription' => __( 'These checks report configuration signals; they do not change permissions, database settings, or block traffic. Ask your host before changing server-level settings.', 'security-guard' ),
			'storedContentScan' => __( 'Stored content scan', 'security-guard' ),
			'scanDescription' => __( 'On-demand scan of core posts, comments, and options for a small set of suspicious SQL/XSS markers. Results are advisory and show fingerprints, not stored content.', 'security-guard' ),
			'scanButton' => __( 'Scan core database content', 'security-guard' ),
			'firewallEvents' => __( 'Firewall events', 'security-guard' ),
			'recentActivity' => __( 'Recent activity', 'security-guard' ),
			'active' => __( 'Active', 'security-guard' ),
			'disabled' => __( 'Disabled', 'security-guard' ),
			'configured' => __( 'Turnstile configured', 'security-guard' ),
			'setupRecommended' => __( 'Setup recommended', 'security-guard' ),
			'backupHealthy' => __( 'Backup healthy', 'security-guard' ),
			'backupAttention' => __( 'Backup needs attention', 'security-guard' ),
			'backupSucceeded' => __( 'Last backup succeeded', 'security-guard' ),
			'backupFailed' => __( 'Last backup failed', 'security-guard' ),
			'nextBackup' => __( 'Next scheduled backup: %s UTC.', 'security-guard' ),
			'requestFirewall' => __( 'Request firewall', 'security-guard' ),
			'captcha' => __( 'CAPTCHA', 'security-guard' ),
			'backupCard' => __( 'Backups', 'security-guard' ),
			'twoFactorCard' => __( 'Two-factor auth', 'security-guard' ),
			'userManaged' => __( 'User-managed', 'security-guard' ),
			'perUser' => __( 'Per user', 'security-guard' ),
			'reportOnly' => __( 'Report only', 'security-guard' ),
			'saveSettings' => __( 'Save settings', 'security-guard' ),
			'protectionNav' => __( 'Protection', 'security-guard' ),
			'twoFactorNav' => __( 'Two-factor', 'security-guard' ),
			'backupsNav' => __( 'Backups', 'security-guard' ),
			'checksNav' => __( 'Security checks', 'security-guard' ),
			'eventsNav' => __( 'Firewall events', 'security-guard' ),
			'statusOverview' => __( 'Security status overview', 'security-guard' ),
			'sections' => __( 'Dashboard sections', 'security-guard' ),
			'eyebrowSite' => __( 'SITE SECURITY', 'security-guard' ),
			'eyebrowProtection' => __( 'ACCESS & PREVENTION', 'security-guard' ),
			'eyebrowAccount' => __( 'ACCOUNT SECURITY', 'security-guard' ),
			'eyebrowRecovery' => __( 'RECOVERY', 'security-guard' ),
			'eyebrowHealth' => __( 'SITE HEALTH', 'security-guard' ),
			'eyebrowFirewall' => __( 'FIREWALL', 'security-guard' ),
			'check' => __( 'Check', 'security-guard' ),
			'result' => __( 'Result', 'security-guard' ),
			'noScan' => __( 'No configured suspicious markers were found in the scanned core tables.', 'security-guard' ),
			'scanAt' => __( 'Scan completed at %s UTC.', 'security-guard' ),
			'scanTruncated' => __( 'The display limit was reached; not all matching rows may be shown.', 'security-guard' ),
			'table' => __( 'Table', 'security-guard' ),
			'row' => __( 'Row', 'security-guard' ),
			'column' => __( 'Column', 'security-guard' ),
			'marker' => __( 'Marker', 'security-guard' ),
			'fingerprint' => __( 'Fingerprint', 'security-guard' ),
			'scanCaution' => __( 'Markers can appear in legitimate content. Review each row in context; this scan does not modify data.', 'security-guard' ),
			'noEvents' => __( 'No firewall events recorded.', 'security-guard' ),
			'eventsUnavailable' => __( 'Firewall event records are currently unavailable.', 'security-guard' ),
			'utcTime' => __( 'UTC time', 'security-guard' ),
			'ipFingerprint' => __( 'IP fingerprint', 'security-guard' ),
			'method' => __( 'Method', 'security-guard' ),
			'path' => __( 'Path', 'security-guard' ),
			'rule' => __( 'Rule', 'security-guard' ),
			'privacyNote' => __( 'Request bodies, header values, and raw IP addresses are not stored. IP fingerprints are keyed hashes for correlation.', 'security-guard' ),
			'backupFolder' => __( 'Private backup directory:', 'security-guard' ),
		);
	}

	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = self::settings();
		$captcha_configured = ! empty( $settings['captcha_site_key'] ) && ! empty( $settings['captcha_secret_key'] );
		$backup_status = get_option( 'slg_backup_last_result', array() );
		$backup_label = is_array( $backup_status ) && ! empty( $backup_status['success'] )
			? __( 'Backup healthy', 'security-guard' )
			: __( 'Backup needs attention', 'security-guard' );
		?>
		<div id="slg-dashboard-root" class="wrap slg-dashboard"><p><?php esc_html_e( 'The dashboard could not load. Reload the page or enable JavaScript.', 'security-guard' ); ?></p></div>
		<noscript>
		<div class="wrap slg-dashboard">
			<header class="slg-header">
				<div>
					<p class="slg-eyebrow"><?php esc_html_e( 'SITE SECURITY', 'security-guard' ); ?></p>
					<h1><?php esc_html_e( 'Security Guard', 'security-guard' ); ?></h1>
					<p><?php esc_html_e( 'Your site protection at a glance. Review status and manage your security controls below.', 'security-guard' ); ?></p>
				</div>
				<span class="slg-version"><?php esc_html_e( 'MVP 0.4.4', 'security-guard' ); ?></span>
			</header>

			<div class="slg-status-grid" aria-label="<?php esc_attr_e( 'Security status overview', 'security-guard' ); ?>">
				<a class="slg-status-card" href="#slg-protection">
					<span class="slg-status-icon slg-icon-shield" aria-hidden="true">S</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Request firewall', 'security-guard' ); ?></strong><span><?php echo ! empty( $settings['firewall_enabled'] ) ? esc_html__( 'Active', 'security-guard' ) : esc_html__( 'Disabled', 'security-guard' ); ?></span></span>
					<span class="slg-status-dot <?php echo ! empty( $settings['firewall_enabled'] ) ? 'is-good' : 'is-muted'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-protection">
					<span class="slg-status-icon slg-icon-captcha" aria-hidden="true">C</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'CAPTCHA', 'security-guard' ); ?></strong><span><?php echo $captcha_configured ? esc_html__( 'Turnstile configured', 'security-guard' ) : esc_html__( 'Setup recommended', 'security-guard' ); ?></span></span>
					<span class="slg-status-dot <?php echo $captcha_configured ? 'is-good' : 'is-warning'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-backups">
					<span class="slg-status-icon slg-icon-backup" aria-hidden="true">B</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Backups', 'security-guard' ); ?></strong><span><?php echo esc_html( $backup_label ); ?></span></span>
					<span class="slg-status-dot <?php echo is_array( $backup_status ) && ! empty( $backup_status['success'] ) ? 'is-good' : 'is-warning'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-two-factor">
					<span class="slg-status-icon slg-icon-2fa" aria-hidden="true">2F</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Two-factor auth', 'security-guard' ); ?></strong><span><?php esc_html_e( 'User-managed', 'security-guard' ); ?></span></span>
					<span class="slg-status-dot is-info"></span>
				</a>
			</div>

			<nav class="slg-nav" aria-label="<?php esc_attr_e( 'Dashboard sections', 'security-guard' ); ?>">
				<a href="#slg-protection"><?php esc_html_e( 'Protection', 'security-guard' ); ?></a>
				<a href="#slg-two-factor"><?php esc_html_e( 'Two-factor', 'security-guard' ); ?></a>
				<a href="#slg-backups"><?php esc_html_e( 'Backups', 'security-guard' ); ?></a>
				<a href="#slg-audit"><?php esc_html_e( 'Security checks', 'security-guard' ); ?></a>
				<a href="#slg-events"><?php esc_html_e( 'Firewall events', 'security-guard' ); ?></a>
			</nav>

			<section class="slg-panel" id="slg-protection">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'ACCESS & PREVENTION', 'security-guard' ); ?></p><h2><?php esc_html_e( 'Protection settings', 'security-guard' ); ?></h2></div>
					<p><?php esc_html_e( 'Tune login safeguards and spam prevention.', 'security-guard' ); ?></p>
				</div>
			<form action="options.php" method="post">
				<?php settings_fields( 'secure_login_guard' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="slg-failures-per-login"><?php esc_html_e( 'Failures per username and IP', 'security-guard' ); ?></label></th>
						<td><input id="slg-failures-per-login" type="number" min="3" max="20" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[failures_per_login]" value="<?php echo esc_attr( $settings['failures_per_login'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-failures-per-ip"><?php esc_html_e( 'Failures per IP address', 'security-guard' ); ?></label></th>
						<td><input id="slg-failures-per-ip" type="number" min="10" max="100" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[failures_per_ip]" value="<?php echo esc_attr( $settings['failures_per_ip'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-window-minutes"><?php esc_html_e( 'Counting window (minutes)', 'security-guard' ); ?></label></th>
						<td><input id="slg-window-minutes" type="number" min="5" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[window_minutes]" value="<?php echo esc_attr( $settings['window_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-lockout-minutes"><?php esc_html_e( 'Lockout duration (minutes)', 'security-guard' ); ?></label></th>
						<td><input id="slg-lockout-minutes" type="number" min="1" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[lockout_minutes]" value="<?php echo esc_attr( $settings['lockout_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-inactivity-minutes"><?php esc_html_e( 'Inactivity logout (minutes)', 'security-guard' ); ?></label></th>
						<td><input id="slg-inactivity-minutes" type="number" min="5" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[inactivity_minutes]" value="<?php echo esc_attr( $settings['inactivity_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-password-length"><?php esc_html_e( 'Minimum password length', 'security-guard' ); ?></label></th>
						<td><input id="slg-password-length" type="number" min="10" max="64" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[minimum_password_length]" value="<?php echo esc_attr( $settings['minimum_password_length'] ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'New or changed passwords must meet this length and include at least three character classes: lowercase, uppercase, number, or symbol.', 'security-guard' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Request firewall', 'security-guard' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[firewall_enabled]" value="1" <?php checked( $settings['firewall_enabled'], 1 ); ?>> <?php esc_html_e( 'Inspect requests and temporarily block high-confidence malicious patterns', 'security-guard' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-turnstile-site-key"><?php esc_html_e( 'Cloudflare Turnstile site key', 'security-guard' ); ?></label></th>
						<td><input id="slg-turnstile-site-key" type="text" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[captcha_site_key]" value="<?php echo esc_attr( $settings['captcha_site_key'] ); ?>" class="regular-text" autocomplete="off"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-turnstile-secret-key"><?php esc_html_e( 'Cloudflare Turnstile secret key', 'security-guard' ); ?></label></th>
						<td><input id="slg-turnstile-secret-key" type="password" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[captcha_secret_key]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr( $settings['captcha_secret_key'] ? __( 'Configured; leave blank to keep current key', 'security-guard' ) : __( 'Not configured', 'security-guard' ) ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-backup-directory"><?php esc_html_e( 'Private backup directory (optional)', 'security-guard' ); ?></label></th>
						<td><input id="slg-backup-directory" type="text" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[backup_directory]" value="<?php echo esc_attr( $settings['backup_directory'] ); ?>" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Automatic private location', 'security-guard' ); ?>"><p class="description"><?php esc_html_e( 'Enter an absolute server path approved by your host and outside the public web root. Leave blank to use the automatic location. The directory must be writable by PHP; public paths are rejected. Changing this path does not move existing archives.', 'security-guard' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-backup-retention"><?php esc_html_e( 'Scheduled backup retention', 'security-guard' ); ?></label></th>
						<td><input id="slg-backup-retention" type="number" min="1" max="30" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[backup_retention]" value="<?php echo esc_attr( $settings['backup_retention'] ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Keep this many successful database + file backup archives.', 'security-guard' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Scheduled file integrity monitoring', 'security-guard' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[file_monitoring_enabled]" value="1" <?php checked( ! empty( $settings['file_monitoring_enabled'] ) ); ?>> <?php esc_html_e( 'Run a report-only file scan weekly and email new findings.', 'security-guard' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Successful login email notifications', 'security-guard' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[login_notifications_enabled]" value="1" <?php checked( ! empty( $settings['login_notifications_enabled'] ) ); ?>> <?php esc_html_e( 'Email account owners after a successful sign-in.', 'security-guard' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<p class="description"><?php esc_html_e( 'The IP address is taken only from the web server REMOTE_ADDR value. If your site is behind a proxy, configure the proxy/web server to set this value correctly; forwarded headers are intentionally not trusted.', 'security-guard' ); ?></p>
			</section>

			<section class="slg-panel" id="slg-two-factor">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'ACCOUNT SECURITY', 'security-guard' ); ?></p><h2><?php esc_html_e( 'Two-factor authentication', 'security-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Per user', 'security-guard' ); ?></span>
				</div>
			<p><?php esc_html_e( 'Users can enable authenticator-app TOTP (compatible with Google Authenticator and Microsoft Authenticator) and recovery codes from their own profile under Users > Profile. Email OTP is available as a fallback for users with TOTP enabled.', 'security-guard' ); ?></p>
			<p><?php esc_html_e( 'SMS OTP is not included because it requires a provider account, credentials, and delivery policy.', 'security-guard' ); ?></p>
			</section>

			<section class="slg-panel" id="slg-backups">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'RECOVERY', 'security-guard' ); ?></p><h2><?php esc_html_e( 'Backups and disaster recovery', 'security-guard' ); ?></h2></div>
					<span class="slg-pill <?php echo is_array( $backup_status ) && ! empty( $backup_status['success'] ) ? 'slg-pill-good' : 'slg-pill-warning'; ?>"><?php echo esc_html( $backup_label ); ?></span>
				</div>
			<p><?php esc_html_e( 'Weekly database + file backups are scheduled with WordPress Cron. Backups can take several minutes on larger sites. Archives are kept in a private directory outside the web root; public paths are rejected.', 'security-guard' ); ?></p>
			<p class="description"><?php esc_html_e( 'Keep this page open while a manual backup runs. The plugin requests unlimited PHP execution time; a host or web-server timeout may still stop a very large backup.', 'security-guard' ); ?></p>
			<?php Secure_Login_Guard_Backups::render_admin_section(); ?>
			<p><?php esc_html_e( 'Manual database-only download is also available. Backups contain sensitive data. Test restoration and keep a separate off-site copy.', 'security-guard' ); ?></p>
			<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
				<input type="hidden" name="action" value="slg_download_backup">
				<?php wp_nonce_field( 'slg_download_backup' ); ?>
				<?php submit_button( __( 'Download database backup', 'security-guard' ), 'secondary', 'submit', false ); ?>
			</form>
			</section>

			<section class="slg-panel" id="slg-audit">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'SITE HEALTH', 'security-guard' ); ?></p><h2><?php esc_html_e( 'Security checks', 'security-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Report only', 'security-guard' ); ?></span>
				</div>
			<p><?php esc_html_e( 'These checks report configuration signals; they do not change permissions, database settings, or block traffic. Ask your host before changing server-level settings.', 'security-guard' ); ?></p>
			<?php self::render_security_checks(); ?>
			<h3><?php esc_html_e( 'Stored content scan', 'security-guard' ); ?></h3>
			<p><?php esc_html_e( 'On-demand scan of core posts, comments, and options for a small set of suspicious SQL/XSS markers. Results are advisory and show fingerprints, not stored content.', 'security-guard' ); ?></p>
			<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
				<input type="hidden" name="action" value="slg_scan_database">
				<?php wp_nonce_field( 'slg_scan_database' ); ?>
				<?php submit_button( __( 'Scan core database content', 'security-guard' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php self::render_database_scan_results(); ?>
			</section>

			<section class="slg-panel" id="slg-events">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'MONITORING', 'security-guard' ); ?></p><h2><?php esc_html_e( 'Firewall events', 'security-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Recent activity', 'security-guard' ); ?></span>
				</div>
			<?php Secure_Login_Guard_Firewall::render_admin_log(); ?>
			</section>
		</div>
		</noscript>
		<?php
	}

	public static function render_login_2fa_field() {
		?>
		<p>
			<label for="slg-totp-code"><?php esc_html_e( 'Authenticator or recovery code', 'security-guard' ); ?><br>
				<input type="text" name="slg_totp_code" id="slg-totp-code" class="input" value="" autocomplete="one-time-code" inputmode="numeric">
			</label>
		</p>
		<p class="description"><?php esc_html_e( 'Enter an authenticator or recovery code. Leave blank to receive a one-time email code if email delivery is available.', 'security-guard' ); ?></p>
		<?php
	}

	public static function check_two_factor( $user, $username, $password ) {
		unset( $username, $password );

		if (
			! $user instanceof WP_User
			|| ! isset( $_POST['log'], $_POST['pwd'] )
			|| ! get_user_meta( $user->ID, 'slg_2fa_enabled', true )
		) {
			return $user;
		}

		$code = self::posted_text( 'slg_totp_code' );
		$secret = get_user_meta( $user->ID, 'slg_2fa_secret', true );
		$step = self::verify_totp( $secret, $code );

		if ( false !== $step ) {
			$last_step = absint( get_user_meta( $user->ID, 'slg_2fa_last_step', true ) );
			if ( $step <= $last_step ) {
				return new WP_Error( 'slg_2fa_reused', __( 'That authentication code has already been used. Please try the next code.', 'security-guard' ) );
			}
			update_user_meta( $user->ID, 'slg_2fa_last_step', $step );
			return $user;
		}

		if ( self::consume_recovery_code( $user->ID, $code ) || self::verify_email_otp( $user->ID, $code ) ) {
			return $user;
		}

		if ( '' === $code ) {
			$sent = self::issue_email_otp( $user );
			if ( is_wp_error( $sent ) ) {
				return $sent;
			}
			return new WP_Error( 'slg_email_otp_sent', __( 'A one-time code was sent to the email address on your account. Enter it with your password to continue.', 'security-guard' ) );
		}

		return new WP_Error( 'slg_2fa_invalid', __( 'The authenticator or recovery code was not accepted.', 'security-guard' ) );
	}

	private static function issue_email_otp( $user ) {
		$cooldown_key = 'slg_email_cooldown_' . absint( $user->ID );
		if ( get_transient( $cooldown_key ) ) {
			return new WP_Error( 'slg_email_otp_cooldown', __( 'A code was sent recently. Check your email and wait before requesting another.', 'security-guard' ) );
		}
		$code = (string) random_int( 100000, 999999 );
		$sent = wp_mail(
			$user->user_email,
			__( 'Your Security Guard sign-in code', 'security-guard' ),
			sprintf(
				/* translators: %s is a one-time login code. */
				__( 'Your one-time sign-in code is %s. It expires in 10 minutes. If you did not try to sign in, you can ignore this email.', 'security-guard' ),
				$code
			)
		);
		if ( ! $sent ) {
			return new WP_Error( 'slg_email_otp_delivery_failed', __( 'The one-time code could not be emailed. Use your authenticator or recovery code, or contact the site administrator.', 'security-guard' ) );
		}
		set_transient(
			'slg_email_otp_' . absint( $user->ID ),
			array(
				'hash' => wp_hash_password( $code ),
				'attempts' => 0,
				'expires' => time() + 10 * MINUTE_IN_SECONDS,
			),
			10 * MINUTE_IN_SECONDS
		);
		set_transient( $cooldown_key, 1, MINUTE_IN_SECONDS );
		return true;
	}

	private static function posted_text( $key ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) {
			return '';
		}
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}

	private static function verify_email_otp( $user_id, $code ) {
		if ( ! is_string( $code ) || ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}
		$key = 'slg_email_otp_' . absint( $user_id );
		$record = get_transient( $key );
		if (
			! is_array( $record )
			|| ! isset( $record['hash'], $record['attempts'], $record['expires'] )
			|| absint( $record['attempts'] ) >= 5
			|| absint( $record['expires'] ) <= time()
		) {
			delete_transient( $key );
			return false;
		}
		if ( wp_check_password( $code, $record['hash'] ) ) {
			delete_transient( $key );
			return true;
		}
		$record['attempts'] = absint( $record['attempts'] ) + 1;
		set_transient( $key, $record, max( 1, absint( $record['expires'] ) - time() ) );
		return false;
	}

	public static function render_captcha_field() {
		$settings = self::settings();
		if ( empty( $settings['captcha_site_key'] ) || empty( $settings['captcha_secret_key'] ) ) {
			return;
		}
		?>
		<div class="cf-turnstile" data-sitekey="<?php echo esc_attr( $settings['captcha_site_key'] ); ?>"></div>
		<?php
	}

	public static function enqueue_captcha_script() {
		$settings = self::settings();
		if ( ! empty( $settings['captcha_site_key'] ) && ! empty( $settings['captcha_secret_key'] ) ) {
			wp_enqueue_script( 'slg-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true );
		}
	}

	public static function check_login_captcha( $user, $username, $password ) {
		unset( $username, $password );
		if ( ! $user instanceof WP_User || ! isset( $_POST['log'], $_POST['pwd'] ) ) {
			return $user;
		}
		$check = self::verify_captcha();
		return is_wp_error( $check ) ? $check : $user;
	}

	public static function validate_registration_captcha( $errors, $sanitized_user_login, $user_email ) {
		unset( $sanitized_user_login, $user_email );
		$check = self::verify_captcha();
		if ( is_wp_error( $check ) ) {
			$errors->add( 'slg_registration_captcha', $check->get_error_message() );
		}
		if ( '' !== self::posted_text( 'slg_registration_website' ) ) {
			$errors->add( 'slg_registration_honeypot', __( 'Registration could not be accepted.', 'security-guard' ) );
		}
		return $errors;
	}

	public static function check_comment_captcha( $commentdata ) {
		if ( ! isset( $_POST['comment_post_ID'] ) ) {
			return $commentdata;
		}
		$check = self::verify_captcha();
		if ( is_wp_error( $check ) ) {
			wp_die( esc_html( $check->get_error_message() ), '', array( 'response' => 403 ) );
		}
		return $commentdata;
	}

	public static function render_registration_honeypot() {
		?>
		<p aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden;">
			<label for="slg-registration-website"><?php esc_html_e( 'Leave this field empty', 'security-guard' ); ?></label>
			<input type="text" id="slg-registration-website" name="slg_registration_website" value="" tabindex="-1" autocomplete="off">
		</p>
		<?php
	}

	private static function verify_captcha() {
		$settings = self::settings();
		if ( empty( $settings['captcha_site_key'] ) || empty( $settings['captcha_secret_key'] ) ) {
			return true;
		}
		$token = self::posted_text( 'cf-turnstile-response' );
		if ( '' === $token ) {
			return new WP_Error( 'slg_captcha_missing', __( 'Complete the CAPTCHA challenge to continue.', 'security-guard' ) );
		}
		$request_body = array(
			'secret' => $settings['captcha_secret_key'],
			'response' => $token,
		);
		$ip = self::client_ip();
		if ( 'unknown' !== $ip ) {
			$request_body['remoteip'] = $ip;
		}
		$response = wp_remote_post(
			'https://challenges.cloudflare.com/turnstile/v0/siteverify',
			array(
				'timeout' => 5,
				'body' => $request_body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'slg_captcha_unavailable', __( 'CAPTCHA verification is unavailable. Please try again later.', 'security-guard' ) );
		}
		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'slg_captcha_unavailable', __( 'CAPTCHA verification is unavailable. Please try again later.', 'security-guard' ) );
		}
		$result = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $result ) || empty( $result['success'] ) ) {
			return new WP_Error( 'slg_captcha_invalid', __( 'CAPTCHA verification failed. Please try again.', 'security-guard' ) );
		}
		$expected_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$verified_host = isset( $result['hostname'] ) ? strtolower( (string) $result['hostname'] ) : '';
		if ( '' === $expected_host || ! hash_equals( $expected_host, $verified_host ) ) {
			return new WP_Error( 'slg_captcha_invalid', __( 'CAPTCHA verification failed. Please try again.', 'security-guard' ) );
		}
		return true;
	}

	public static function render_2fa_profile( $user ) {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		$enabled = (bool) get_user_meta( $user->ID, 'slg_2fa_enabled', true );
		$pending_secret = get_user_meta( $user->ID, 'slg_2fa_pending_secret', true );
		$notice = get_transient( 'slg_2fa_notice_' . absint( $user->ID ) );
		if ( is_string( $notice ) && '' !== $notice ) {
			delete_transient( 'slg_2fa_notice_' . absint( $user->ID ) );
			echo '<div class="notice notice-success inline"><p>' . esc_html( $notice ) . '</p></div>';
		}
		$recovery_codes = get_transient( 'slg_recovery_show_' . absint( $user->ID ) );
		if ( false !== $recovery_codes ) {
			delete_transient( 'slg_recovery_show_' . absint( $user->ID ) );
		}
		?>
		<h2><?php esc_html_e( 'Security Guard: Two-factor authentication', 'security-guard' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><?php esc_html_e( 'Authenticator app', 'security-guard' ); ?></th>
				<td>
					<?php if ( $enabled ) : ?>
						<p><?php esc_html_e( 'Two-factor authentication is enabled for this account.', 'security-guard' ); ?></p>
						<p><label for="slg-manage-code"><?php esc_html_e( 'Current authenticator or recovery code (required for your own account)', 'security-guard' ); ?></label>
							<input type="text" id="slg-manage-code" name="slg_2fa_manage_code" autocomplete="one-time-code"></p>
					<?php elseif ( $pending_secret ) : ?>
						<p><?php esc_html_e( 'Add this secret to a TOTP-compatible authenticator app, then enter a current code to finish setup.', 'security-guard' ); ?></p>
						<p><code><?php echo esc_html( $pending_secret ); ?></code></p>
						<p><label for="slg-confirm-code"><?php esc_html_e( 'Authenticator code', 'security-guard' ); ?></label>
							<input type="text" id="slg-confirm-code" name="slg_2fa_code" inputmode="numeric" autocomplete="one-time-code"></p>
					<?php else : ?>
						<p><?php esc_html_e( 'Not enabled.', 'security-guard' ); ?></p>
					<?php endif; ?>
					<?php if ( is_array( $recovery_codes ) && $recovery_codes ) : ?>
						<div class="notice notice-warning inline"><p><?php esc_html_e( 'Save these recovery codes now. They are shown only once.', 'security-guard' ); ?></p>
							<p><code><?php echo esc_html( implode( '  ', $recovery_codes ) ); ?></code></p></div>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php wp_nonce_field( 'slg_2fa_' . $user->ID, 'slg_2fa_nonce' ); ?>
		<?php if ( $enabled ) : ?>
			<p><button type="button" class="button" data-slg-profile-field="slg_2fa_action" data-slg-profile-value="regenerate"><?php esc_html_e( 'Generate new recovery codes', 'security-guard' ); ?></button>
				<button type="button" class="button" data-slg-profile-field="slg_2fa_action" data-slg-profile-value="disable"><?php esc_html_e( 'Disable two-factor authentication', 'security-guard' ); ?></button></p>
		<?php elseif ( $pending_secret ) : ?>
			<p><button type="button" class="button button-primary" data-slg-profile-field="slg_2fa_action" data-slg-profile-value="confirm"><?php esc_html_e( 'Confirm and enable two-factor authentication', 'security-guard' ); ?></button>
				<button type="button" class="button" data-slg-profile-field="slg_2fa_action" data-slg-profile-value="cancel"><?php esc_html_e( 'Cancel setup', 'security-guard' ); ?></button></p>
		<?php else : ?>
			<p><button type="button" class="button" data-slg-profile-field="slg_2fa_action" data-slg-profile-value="start"><?php esc_html_e( 'Set up two-factor authentication', 'security-guard' ); ?></button></p>
		<?php endif; ?>
		<?php
		self::render_account_sessions_profile( $user );
	}

	public static function render_account_sessions_profile( $user ) {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}
		if ( ! class_exists( 'WP_Session_Tokens' ) ) {
			echo '<h2>' . esc_html__( 'Security Guard: Account sessions', 'security-guard' ) . '</h2>';
			echo '<p>' . esc_html__( 'WordPress session management is unavailable in this installation.', 'security-guard' ) . '</p>';
			return;
		}

		$sessions = WP_Session_Tokens::get_instance( $user->ID )->get_all();
		?>
		<h2><?php esc_html_e( 'Security Guard: Account sessions', 'security-guard' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Session', 'security-guard' ); ?></th>
					<th><?php esc_html_e( 'Browser', 'security-guard' ); ?></th>
					<th><?php esc_html_e( 'IP address', 'security-guard' ); ?></th>
					<th><?php esc_html_e( 'Signed in', 'security-guard' ); ?></th>
					<th><?php esc_html_e( 'Expires', 'security-guard' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $sessions ) ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No active sessions.', 'security-guard' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $sessions as $session ) : ?>
						<tr>
							<td><?php esc_html_e( 'Active session', 'security-guard' ); ?></td>
							<td><?php echo esc_html( isset( $session['ua'] ) ? self::browser_label( sanitize_text_field( (string) $session['ua'] ) ) : __( 'Unknown browser', 'security-guard' ) ); ?></td>
							<td><code><?php echo esc_html( isset( $session['ip'] ) ? (string) $session['ip'] : __( 'Unknown', 'security-guard' ) ); ?></code></td>
							<td><?php echo esc_html( isset( $session['login'] ) ? gmdate( 'Y-m-d H:i:s', absint( $session['login'] ) ) . ' UTC' : __( 'Unknown', 'security-guard' ) ); ?></td>
							<td><?php echo esc_html( isset( $session['expiration'] ) ? gmdate( 'Y-m-d H:i:s', absint( $session['expiration'] ) ) . ' UTC' : __( 'Unknown', 'security-guard' ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<?php wp_nonce_field( 'slg_revoke_sessions_' . absint( $user->ID ), 'slg_revoke_nonce' ); ?>
		<p>
			<button type="button" class="button" data-slg-profile-field="slg_revoke_scope" data-slg-profile-value="others"><?php esc_html_e( 'Log out other sessions', 'security-guard' ); ?></button>
			<button type="button" class="button button-secondary" data-slg-profile-field="slg_revoke_scope" data-slg-profile-value="all"><?php esc_html_e( 'Log out all sessions', 'security-guard' ); ?></button>
		</p>
		<?php
	}


	public static function save_2fa_profile( $user_id ) {
		if (
			isset( $_POST['slg_revoke_scope'], $_POST['slg_revoke_nonce'] )
			&& is_string( $_POST['slg_revoke_scope'] )
			&& is_string( $_POST['slg_revoke_nonce'] )
		) {
			if ( ! current_user_can( 'edit_user', $user_id ) ) {
				return;
			}
			check_admin_referer( 'slg_revoke_sessions_' . $user_id, 'slg_revoke_nonce' );
			$scope = sanitize_key( wp_unslash( $_POST['slg_revoke_scope'] ) );
			if ( class_exists( 'WP_Session_Tokens' ) ) {
				$manager = WP_Session_Tokens::get_instance( $user_id );
				if ( 'others' === $scope && $user_id === get_current_user_id() ) {
					$current_token = wp_get_session_token();
					if ( '' !== $current_token ) {
						$manager->destroy_others( $current_token );
					} else {
						$manager->destroy_all();
					}
				} elseif ( 'all' === $scope || 'others' === $scope ) {
					$manager->destroy_all();
				}
			}
			set_transient(
				'slg_2fa_notice_' . absint( $user_id ),
				'all' === $scope ? __( 'All account sessions were logged out.', 'security-guard' ) : __( 'Other account sessions were logged out.', 'security-guard' ),
				MINUTE_IN_SECONDS
			);
			return;
		}

		if ( empty( $_POST['slg_2fa_action'] ) || ! is_string( $_POST['slg_2fa_action'] ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_user', $user_id ) || ! isset( $_POST['slg_2fa_nonce'] ) ) {
			return;
		}
		check_admin_referer( 'slg_2fa_' . $user_id, 'slg_2fa_nonce' );

		$action = sanitize_key( wp_unslash( $_POST['slg_2fa_action'] ) );

		if (
			$user_id === get_current_user_id()
			&& get_user_meta( $user_id, 'slg_2fa_enabled', true )
			&& in_array( $action, array( 'disable', 'regenerate' ), true )
			&& ! self::verify_user_2fa_code( $user_id, self::posted_text( 'slg_2fa_manage_code' ) )
		) {
			return;
		}

		if ( 'start' === $action && ! get_user_meta( $user_id, 'slg_2fa_enabled', true ) ) {
			update_user_meta( $user_id, 'slg_2fa_pending_secret', self::base32_encode( random_bytes( 20 ) ) );
			set_transient(
				'slg_2fa_notice_' . absint( $user_id ),
				__( 'Two-factor setup started. Add the displayed secret to your authenticator app, then enter a current code.', 'security-guard' ),
				MINUTE_IN_SECONDS
			);
		} elseif ( 'confirm' === $action ) {
			$secret = get_user_meta( $user_id, 'slg_2fa_pending_secret', true );
			$code = self::posted_text( 'slg_2fa_code' );
			$step = self::verify_totp( $secret, $code );
			if ( false !== $step ) {
				update_user_meta( $user_id, 'slg_2fa_secret', $secret );
				update_user_meta( $user_id, 'slg_2fa_enabled', 1 );
				update_user_meta( $user_id, 'slg_2fa_last_step', $step );
				delete_user_meta( $user_id, 'slg_2fa_pending_secret' );
				self::create_recovery_codes( $user_id );
				set_transient(
					'slg_2fa_notice_' . absint( $user_id ),
					__( 'Two-factor authentication is enabled for this account.', 'security-guard' ),
					MINUTE_IN_SECONDS
				);
			}
		} elseif ( 'disable' === $action ) {
			delete_user_meta( $user_id, 'slg_2fa_enabled' );
			delete_user_meta( $user_id, 'slg_2fa_secret' );
			delete_user_meta( $user_id, 'slg_2fa_recovery_codes' );
			delete_user_meta( $user_id, 'slg_2fa_last_step' );
			set_transient( 'slg_2fa_notice_' . absint( $user_id ), __( 'Two-factor authentication was disabled for this account.', 'security-guard' ), MINUTE_IN_SECONDS );
		} elseif ( 'cancel' === $action ) {
			delete_user_meta( $user_id, 'slg_2fa_pending_secret' );
			set_transient( 'slg_2fa_notice_' . absint( $user_id ), __( 'Two-factor setup was canceled.', 'security-guard' ), MINUTE_IN_SECONDS );
		} elseif ( 'regenerate' === $action && get_user_meta( $user_id, 'slg_2fa_enabled', true ) ) {
			self::create_recovery_codes( $user_id );
		}
	}

	private static function verify_user_2fa_code( $user_id, $code ) {
		$step = self::verify_totp( get_user_meta( $user_id, 'slg_2fa_secret', true ), $code );
		if ( false !== $step ) {
			$last_step = absint( get_user_meta( $user_id, 'slg_2fa_last_step', true ) );
			if ( $step <= $last_step ) {
				return false;
			}
			update_user_meta( $user_id, 'slg_2fa_last_step', $step );
			return true;
		}
		return self::consume_recovery_code( $user_id, $code );
	}

	private static function create_recovery_codes( $user_id ) {
		$codes = array();
		$hashes = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$code = strtoupper( bin2hex( random_bytes( 6 ) ) );
			$codes[] = $code;
			$hashes[] = wp_hash_password( $code );
		}
		update_user_meta( $user_id, 'slg_2fa_recovery_codes', $hashes );
		set_transient( 'slg_recovery_show_' . absint( $user_id ), $codes, 5 * MINUTE_IN_SECONDS );
	}

	private static function consume_recovery_code( $user_id, $code ) {
		$code = strtoupper( preg_replace( '/[^A-F0-9]/', '', $code ) );
		if ( 12 !== strlen( $code ) ) {
			return false;
		}
		$hashes = get_user_meta( $user_id, 'slg_2fa_recovery_codes', true );
		if ( ! is_array( $hashes ) ) {
			return false;
		}
		foreach ( $hashes as $index => $hash ) {
			if ( wp_check_password( $code, $hash ) ) {
				unset( $hashes[ $index ] );
				update_user_meta( $user_id, 'slg_2fa_recovery_codes', array_values( $hashes ) );
				return true;
			}
		}
		return false;
	}

	private static function valid_user_2fa_code( $user_id, $code ) {
		$step = self::verify_totp( get_user_meta( $user_id, 'slg_2fa_secret', true ), $code );
		if ( false !== $step ) {
			return $step > absint( get_user_meta( $user_id, 'slg_2fa_last_step', true ) );
		}
		$normalized = strtoupper( preg_replace( '/[^A-F0-9]/', '', $code ) );
		$hashes = get_user_meta( $user_id, 'slg_2fa_recovery_codes', true );
		if ( 12 !== strlen( $normalized ) || ! is_array( $hashes ) ) {
			return false;
		}
		foreach ( $hashes as $hash ) {
			if ( wp_check_password( $normalized, $hash ) ) {
				return true;
			}
		}
		return false;
	}

	private static function verify_totp( $secret, $code ) {
		$code = preg_replace( '/\s+/', '', (string) $code );
		if ( ! is_string( $secret ) || '' === $secret || ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}
		$binary_secret = self::base32_decode( $secret );
		if ( false === $binary_secret || '' === $binary_secret ) {
			return false;
		}
		$current_step = (int) floor( time() / 30 );
		for ( $offset = -1; $offset <= 1; $offset++ ) {
			$step = $current_step + $offset;
			if ( $step < 0 ) {
				continue;
			}
			$counter = pack( 'N2', 0, $step );
			$hash = hash_hmac( 'sha1', $counter, $binary_secret, true );
			$offset_byte = ord( $hash[19] ) & 0x0f;
			$number = ( ( ord( $hash[ $offset_byte ] ) & 0x7f ) << 24 )
				| ( ( ord( $hash[ $offset_byte + 1 ] ) & 0xff ) << 16 )
				| ( ( ord( $hash[ $offset_byte + 2 ] ) & 0xff ) << 8 )
				| ( ord( $hash[ $offset_byte + 3 ] ) & 0xff );
			if ( hash_equals( sprintf( '%06d', $number % 1000000 ), $code ) ) {
				return $step;
			}
		}
		return false;
	}

	private static function base32_encode( $data ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$bits = '';
		foreach ( str_split( $data ) as $character ) {
			$bits .= str_pad( decbin( ord( $character ) ), 8, '0', STR_PAD_LEFT );
		}
		$encoded = '';
		foreach ( str_split( $bits, 5 ) as $chunk ) {
			if ( strlen( $chunk ) < 5 ) {
				$chunk = str_pad( $chunk, 5, '0', STR_PAD_RIGHT );
			}
			$encoded .= $alphabet[ bindec( $chunk ) ];
		}
		return $encoded;
	}

	private static function base32_decode( $encoded ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$encoded = strtoupper( rtrim( $encoded, '=' ) );
		$bits = '';
		foreach ( str_split( $encoded ) as $character ) {
			$value = strpos( $alphabet, $character );
			if ( false === $value ) {
				return false;
			}
			$bits .= str_pad( decbin( $value ), 5, '0', STR_PAD_LEFT );
		}
		$decoded = '';
		foreach ( str_split( $bits, 8 ) as $byte ) {
			if ( 8 === strlen( $byte ) ) {
				$decoded .= chr( bindec( $byte ) );
			}
		}
		return $decoded;
	}

	public static function validate_registration_password( $errors, $sanitized_user_login, $user_email ) {
		unset( $sanitized_user_login, $user_email );
		$password = isset( $_POST['user_pass'] ) ? wp_unslash( $_POST['user_pass'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
		return $errors;
	}

	public static function validate_profile_password( $errors, $update, $user ) {
		$password = isset( $_POST['pass1'] ) ? wp_unslash( $_POST['pass1'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
		if ( empty( $_POST['slg_2fa_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['slg_2fa_action'] ) );
		if ( 'confirm' === $action ) {
			$secret = get_user_meta( $user->ID, 'slg_2fa_pending_secret', true );
			$code = self::posted_text( 'slg_2fa_code' );
			if ( false === self::verify_totp( $secret, $code ) ) {
				$errors->add( 'slg_2fa_invalid_setup_code', __( 'Enter a valid code from your authenticator app to enable two-factor authentication.', 'security-guard' ) );
			}
		} elseif (
			$user->ID === get_current_user_id()
			&& get_user_meta( $user->ID, 'slg_2fa_enabled', true )
			&& in_array( $action, array( 'disable', 'regenerate' ), true )
		) {
			$code = self::posted_text( 'slg_2fa_manage_code' );
			if ( ! self::valid_user_2fa_code( $user->ID, $code ) ) {
				$errors->add( 'slg_2fa_invalid_manage_code', __( 'Enter a valid, unused authenticator or recovery code to change two-factor settings.', 'security-guard' ) );
			}
		}
	}

	public static function validate_reset_password( $errors, $user ) {
		unset( $user );
		$password = isset( $_POST['pass1'] ) ? wp_unslash( $_POST['pass1'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
	}

	private static function strong_password( $password ) {
		if ( ! is_string( $password ) ) {
			return false;
		}
		$length = preg_match_all( '/./us', $password, $matches );
		$length = false === $length ? strlen( $password ) : $length;
		if ( $length < absint( self::settings()['minimum_password_length'] ) ) {
			return false;
		}
		$classes = 0;
		$classes += (bool) preg_match( '/[a-z]/', $password );
		$classes += (bool) preg_match( '/[A-Z]/', $password );
		$classes += (bool) preg_match( '/[0-9]/', $password );
		$classes += (bool) preg_match( '/[^a-zA-Z0-9]/', $password );
		return $classes >= 3;
	}

	private static function password_error_message() {
		return sprintf(
			/* translators: %d is the configured minimum password length. */
			__( 'Choose a password with at least %d characters and at least three of these: lowercase, uppercase, number, or symbol.', 'security-guard' ),
			absint( self::settings()['minimum_password_length'] )
		);
	}

	public static function render_comment_honeypot() {
		?>
		<p aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden;">
			<label for="slg-website"><?php esc_html_e( 'Leave this field empty', 'security-guard' ); ?></label>
			<input type="text" id="slg-website" name="slg_website" value="" tabindex="-1" autocomplete="off">
		</p>
		<?php
	}

	public static function mark_honeypot_comment_as_spam( $approved, $commentdata ) {
		unset( $commentdata );
		if ( '' !== self::posted_text( 'slg_website' ) ) {
			return 'spam';
		}
		return $approved;
	}

	public static function enqueue_inactivity_script() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$timeout = absint( self::settings()['inactivity_minutes'] ) * MINUTE_IN_SECONDS;
		wp_register_script( 'slg-inactivity', plugins_url( 'assets/inactivity.js', __FILE__ ), array(), '0.4.4', true );
		wp_enqueue_script( 'slg-inactivity' );
		wp_localize_script(
			'slg-inactivity',
			'SLGActivity',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'slg_activity' ),
				'timeoutMs' => $timeout * 1000,
				'loginUrl' => wp_login_url(),
				'warningText' => __( 'You will be signed out soon due to inactivity. Move the pointer or press a key to stay signed in.', 'security-guard' ),
			)
		);
	}

	public static function record_activity() {
		check_ajax_referer( 'slg_activity', 'nonce' );
		$user_id = get_current_user_id();
		$token = wp_get_session_token();
		if ( ! $user_id || '' === $token ) {
			wp_send_json_error( array( 'message' => 'No active session.' ), 401 );
		}
		$key = self::session_activity_key( $user_id, $token );
		$now = time();
		$timeout = absint( self::settings()['inactivity_minutes'] ) * MINUTE_IN_SECONDS;
		$last_activity = get_transient( $key );
		if ( false !== $last_activity && $now - absint( $last_activity ) >= $timeout ) {
			delete_transient( $key );
			wp_logout();
			wp_send_json_success( array( 'logout' => true ) );
		}
		if ( false === $last_activity || '1' === self::posted_text( 'active' ) ) {
			set_transient( $key, $now, YEAR_IN_SECONDS );
		}
		wp_send_json_success( array( 'logout' => false ) );
	}

	private static function session_activity_key( $user_id, $token ) {
		return 'slg_act_' . hash_hmac( 'sha256', absint( $user_id ) . '|' . $token, wp_salt( 'auth' ) );
	}

	public static function download_database_backup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to download this backup.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_download_backup' );
		global $wpdb;

		nocache_headers();
		header( 'Content-Type: application/sql; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wordpress-database-' . gmdate( 'Y-m-d-His' ) . '.sql"' );
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		echo "-- Database backup generated by Security Guard.\n";
		echo "-- Contains sensitive site data. Store securely.\n\n";
		echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		if ( ! is_array( $tables ) ) {
			wp_die( esc_html__( 'Could not list database tables for backup.', 'security-guard' ) );
		}
		foreach ( $tables as $table ) {
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			$create = $wpdb->get_row( "SHOW CREATE TABLE {$table_sql}", ARRAY_N );
			if ( ! is_array( $create ) || ! isset( $create[1] ) ) {
				wp_die( esc_html__( 'Could not read a database table definition.', 'security-guard' ) );
			}
			echo "\nDROP TABLE IF EXISTS {$table_sql};\n" . $create[1] . ";\n";
			$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table_sql}", 0 );
			if ( ! is_array( $columns ) || ! $columns ) {
				wp_die( esc_html__( 'Could not read the columns for a database table.', 'security-guard' ) );
			}
			$column_sql = implode( ', ', array_map( static function ( $column ) {
				return '`' . str_replace( '`', '``', $column ) . '`';
			}, $columns ) );
			$offset = 0;
			do {
				$rows = $wpdb->get_results( "SELECT * FROM {$table_sql} LIMIT 200 OFFSET " . absint( $offset ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					wp_die( esc_html__( 'Could not read rows from a database table.', 'security-guard' ) );
				}
				if ( ! is_array( $rows ) || ! $rows ) {
					break;
				}
				foreach ( $rows as $row ) {
					$values = array();
					foreach ( $columns as $column ) {
						$value = $row[ $column ];
						$values[] = null === $value ? 'NULL' : "'" . $wpdb->_real_escape( $value ) . "'";
					}
					echo 'INSERT INTO ' . $table_sql . ' (' . $column_sql . ') VALUES (' . implode( ', ', $values ) . ");\n";
				}
				$offset += count( $rows );
			} while ( count( $rows ) === 200 );
		}
		echo "\nSET FOREIGN_KEY_CHECKS=1;\n";
		exit;
	}

	public static function render_security_checks() {
		$checks = self::get_security_checks();

		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Check', 'security-guard' ) . '</th><th>' . esc_html__( 'Result', 'security-guard' ) . '</th></tr></thead><tbody>';
		foreach ( $checks as $check ) {
			echo '<tr><td>' . esc_html( $check['label'] ) . '</td><td>' . esc_html( $check['passed'] ? $check['success'] : $check['failure'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function get_security_checks() {
		global $wpdb;
		$checks = array();
		$checks[] = array( 'HTTPS for the site URL', 0 === strpos( home_url(), 'https://' ), 'HTTPS is enabled for the site URL.', 'Site URL is not HTTPS.' );
		$checks[] = array( 'XML-RPC exposure', ! apply_filters( 'xmlrpc_enabled', true ), 'XML-RPC is disabled by configuration.', 'XML-RPC appears enabled; disable it at the host or with a trusted security control if unused.' );
		$checks[] = array( 'Dashboard file editor', defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT, 'The built-in plugin/theme editor is disabled.', 'The built-in plugin/theme editor is available; consider defining DISALLOW_FILE_EDIT in wp-config.php.' );
		$checks[] = array( 'Debug mode', ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ), 'WordPress debug mode is off.', 'WP_DEBUG is enabled; avoid exposing debug output on a public site.' );
		$checks[] = self::permission_check( 'wp-content directory', WP_CONTENT_DIR );
		$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( untrailingslashit( ABSPATH ) ) . '/wp-config.php';
		$checks[] = self::permission_check( 'wp-config.php', $config );
		$ssl = $wpdb->get_row( "SHOW STATUS LIKE 'Ssl_cipher'", ARRAY_N );
		$checks[] = array( 'Database connection TLS', is_array( $ssl ) && ! empty( $ssl[1] ), 'A TLS cipher is reported for the database connection.', 'Database TLS was not detected or could not be confirmed; ask your host about encrypted DB connections.' );
		if ( 'wp_' === $wpdb->prefix ) {
			$checks[] = array( 'Database table prefix', false, 'A non-default table prefix is in use.', 'The default wp_ table prefix is in use. Changing it is operationally risky and is not a substitute for access controls.' );
		} else {
			$checks[] = array( 'Database table prefix', true, 'A non-default table prefix is in use.', 'The default wp_ table prefix is in use.' );
		}

		$result = array();
		foreach ( $checks as $check ) {
			$result[] = array(
				'label' => $check[0],
				'passed' => (bool) $check[1],
				'success' => $check[2],
				'failure' => $check[3],
			);
		}

		return $result;
	}

	public static function run_database_scan() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to scan the database.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_scan_database' );
		global $wpdb;
		$targets = array(
			array( $wpdb->posts, 'ID', array( 'post_title', 'post_content', 'post_excerpt' ) ),
			array( $wpdb->comments, 'comment_ID', array( 'comment_content' ) ),
			array( $wpdb->options, 'option_id', array( 'option_value' ) ),
			array( $wpdb->usermeta, 'umeta_id', array( 'meta_key', 'meta_value' ) ),
		);
		$markers = array(
			'xss_script_element' => '%<script%',
			'xss_javascript_url' => '%javascript:%',
			'xss_event_handler' => '%onerror=%',
			'sqli_union_select' => '%union select%',
			'sqli_system_schema' => '%information_schema%',
		);
		$results = array();
		$truncated = false;
		foreach ( $targets as $target ) {
			list( $table, $id_column, $columns ) = $target;
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			foreach ( $columns as $column ) {
				$column_sql = '`' . str_replace( '`', '``', $column ) . '`';
				$where = array();
				$values = array();
				foreach ( $markers as $marker ) {
					$where[] = "{$column_sql} LIKE %s";
					$values[] = $marker;
				}
				$query = "SELECT `" . str_replace( '`', '``', $id_column ) . "` AS row_id, {$column_sql} AS data FROM {$table_sql} WHERE (" . implode( ' OR ', $where ) . ') LIMIT 100';
				$rows = $wpdb->get_results( $wpdb->prepare( $query, $values ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					set_transient( 'slg_db_scan_' . get_current_user_id(), array( 'error' => __( 'The database scan could not read core content tables.', 'security-guard' ) ), 10 * MINUTE_IN_SECONDS );
					wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) );
					exit;
				}
				foreach ( $rows as $row ) {
					$matched_rule = '';
					foreach ( $markers as $rule => $marker ) {
						if ( false !== stripos( isset( $row['data'] ) ? (string) $row['data'] : '', trim( $marker, '%' ) ) ) {
							$matched_rule = $rule;
							break;
						}
					}
					$results[] = array(
						'table' => $table,
						'row_id' => absint( $row['row_id'] ),
						'column' => $column,
						'rule' => $matched_rule ? $matched_rule : 'suspicious_marker',
						'fingerprint' => substr( hash( 'sha256', (string) $row['data'] ), 0, 16 ),
					);
					if ( count( $results ) >= 250 ) {
						$truncated = true;
						break 2;
					}
				}
			}
		}
		set_transient(
			'slg_db_scan_' . get_current_user_id(),
			array(
				'results' => $results,
				'truncated' => $truncated,
				'scanned_at' => current_time( 'mysql', true ),
			),
			10 * MINUTE_IN_SECONDS
		);
		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) );
		exit;
	}

	private static function get_database_scan_results( $consume = false ) {
		$key = 'slg_db_scan_' . get_current_user_id();
		$scan = get_transient( $key );
		if ( ! is_array( $scan ) ) {
			return null;
		}
		if ( $consume ) {
			delete_transient( $key );
		}

		return $scan;
	}

	private static function render_database_scan_results() {
		$scan = self::get_database_scan_results( true );
		if ( ! is_array( $scan ) ) {
			return;
		}
		if ( isset( $scan['error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $scan['error'] ) . '</p></div>';
			return;
		}
		echo '<p>' . esc_html( sprintf( __( 'Scan completed at %s UTC.', 'security-guard' ), $scan['scanned_at'] ) ) . '</p>';
		if ( ! empty( $scan['truncated'] ) ) {
			echo '<p class="description">' . esc_html__( 'The display limit was reached; not all matching rows may be shown.', 'security-guard' ) . '</p>';
		}
		if ( empty( $scan['results'] ) ) {
			echo '<p>' . esc_html__( 'No configured suspicious markers were found in the scanned core tables.', 'security-guard' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Table', 'security-guard' ) . '</th><th>' . esc_html__( 'Row', 'security-guard' ) . '</th><th>' . esc_html__( 'Column', 'security-guard' ) . '</th><th>' . esc_html__( 'Marker', 'security-guard' ) . '</th><th>' . esc_html__( 'Fingerprint', 'security-guard' ) . '</th></tr></thead><tbody>';
		foreach ( $scan['results'] as $result ) {
			echo '<tr><td>' . esc_html( $result['table'] ) . '</td><td>' . esc_html( $result['row_id'] ) . '</td><td>' . esc_html( $result['column'] ) . '</td><td>' . esc_html( $result['rule'] ) . '</td><td><code>' . esc_html( $result['fingerprint'] ) . '</code></td></tr>';
		}
		echo '</tbody></table><p class="description">' . esc_html__( 'Markers can appear in legitimate content. Review each row in context; this scan does not modify data.', 'security-guard' ) . '</p>';
	}

	private static function permission_check( $label, $path ) {
		if ( ! file_exists( $path ) ) {
			return array( $label . ' permissions', false, '', 'Could not inspect this path; verify its location and permissions with your host.' );
		}
		$permissions = @fileperms( $path );
		if ( false === $permissions ) {
			return array( $label . ' permissions', false, '', 'Could not read permissions; verify them with your host.' );
		}
		$mode = $permissions & 0777;
		$recommended = 'wp-config.php' === $label ? '0600 or 0640' : ( is_dir( $path ) ? '0755 or 0750' : '0644 or 0640' );
		$group_or_world_writable = 0 !== ( $mode & 0022 );
		if ( $group_or_world_writable ) {
			return array( $label . ' permissions', false, '', sprintf( 'Current mode is %04o; review with your host. A typical target is %s. No automatic change was made.', $mode, $recommended ) );
		}
		return array( $label . ' permissions', true, sprintf( 'Current mode is %04o; typical target is %s.', $mode, $recommended ), '' );
	}

	public static function add_settings_link( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) ),
			esc_html__( 'Settings', 'security-guard' )
		);

		array_unshift( $links, $settings_link );
		return $links;
	}
}

register_activation_hook( __FILE__, array( 'Secure_Login_Guard', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Secure_Login_Guard', 'deactivate' ) );
Secure_Login_Guard::init();
