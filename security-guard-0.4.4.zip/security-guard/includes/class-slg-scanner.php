<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard_Scanner {
	const TRANSIENT_PREFIX = 'slg_file_scan_';
	const MONITORING_OPTION = 'slg_file_monitoring_state';
	const CRON_HOOK = 'slg_weekly_file_scan';
	const BATCH_HOOK = 'slg_file_scan_batch';
	const WEEKLY_SCHEDULE = 'slg_file_scan_weekly';
	const MAX_PHP_FILES = 10000;
	const MAX_FILE_BYTES = 1048576;
	const MAX_TOTAL_BYTES = 67108864;
	const MAX_FINDINGS = 250;
	const BATCH_PHP_FILES = 500;

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_weekly_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'begin_scheduled_scan' ) );
		add_action( self::BATCH_HOOK, array( __CLASS__, 'process_scheduled_batch' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
		add_action( 'admin_post_slg_scan_files', array( __CLASS__, 'run_scan' ) );
		add_action( 'admin_post_slg_run_file_monitoring', array( __CLASS__, 'run_monitoring_now' ) );
		add_action( 'admin_post_slg_reset_file_baseline', array( __CLASS__, 'reset_monitoring_baseline' ) );
	}

	public static function activate() {
		self::ensure_schedule();
	}

	public static function deactivate() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
			$timestamp = wp_next_scheduled( self::CRON_HOOK );
		}
		$timestamp = wp_next_scheduled( self::BATCH_HOOK );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::BATCH_HOOK );
			$timestamp = wp_next_scheduled( self::BATCH_HOOK );
		}
	}

	public static function add_weekly_schedule( $schedules ) {
		$schedules[ self::WEEKLY_SCHEDULE ] = array(
			'interval' => WEEK_IN_SECONDS,
			'display' => __( 'Once Weekly', 'security-guard' ),
		);
		return $schedules;
	}

	public static function ensure_schedule() {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		$enabled = is_array( $settings ) && ! empty( $settings['file_monitoring_enabled'] );
		if ( $enabled && ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, self::WEEKLY_SCHEDULE, self::CRON_HOOK );
		} elseif ( ! $enabled ) {
			self::deactivate();
		}
	}

	public static function settings_updated( $old_value, $new_value ) {
		unset( $old_value, $new_value );
		self::ensure_schedule();
	}

	public static function get_monitoring_data() {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		$state = get_option( self::MONITORING_OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		$next_run = wp_next_scheduled( self::CRON_HOOK );
		$notice = get_transient( 'slg_file_monitoring_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'slg_file_monitoring_notice_' . get_current_user_id() );
		}
		return array(
			'enabled' => is_array( $settings ) && ! empty( $settings['file_monitoring_enabled'] ),
			'next_run' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
			'last_scan' => isset( $state['last_scan'] ) && is_array( $state['last_scan'] ) ? $state['last_scan'] : null,
			'baseline_established' => isset( $state['baseline'] ) && is_array( $state['baseline'] ),
			'running' => isset( $state['chunk'] ) && is_array( $state['chunk'] ),
			'progress' => isset( $state['chunk']['progress'] ) && is_array( $state['chunk']['progress'] ) ? $state['chunk']['progress'] : null,
			'notice' => is_string( $notice ) ? $notice : '',
		);
	}

	public static function begin_scheduled_scan() {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		if ( ! is_array( $settings ) || empty( $settings['file_monitoring_enabled'] ) ) {
			return;
		}
		$state = get_option( self::MONITORING_OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		if ( isset( $state['chunk'] ) && is_array( $state['chunk'] ) ) {
			return;
		}

		$root = realpath( ABSPATH );
		if ( false === $root ) {
			$state['last_scan'] = array(
				'scanned_at' => current_time( 'mysql', true ),
				'error' => __( 'The WordPress directory could not be resolved for scanning.', 'security-guard' ),
			);
			update_option( self::MONITORING_OPTION, $state, false );
			return;
		}
		@set_time_limit( 0 );
		$report = self::empty_report();
		self::check_core_files( $root, $report );
		$state['chunk'] = array(
			'started_at' => current_time( 'mysql', true ),
			'offset' => 0,
			'report' => $report,
			'progress' => array(
				'phase' => 'php',
				'php_scanned' => 0,
			),
		);
		update_option( self::MONITORING_OPTION, $state, false );
		self::process_scheduled_batch();
	}

	public static function process_scheduled_batch() {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		if ( ! is_array( $settings ) || empty( $settings['file_monitoring_enabled'] ) ) {
			return;
		}
		$state = get_option( self::MONITORING_OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		if ( ! isset( $state['chunk'] ) || ! is_array( $state['chunk'] ) ) {
			return;
		}

		$root = realpath( ABSPATH );
		if ( false === $root ) {
			unset( $state['chunk'] );
			$state['last_scan'] = array(
				'scanned_at' => current_time( 'mysql', true ),
				'error' => __( 'The WordPress directory could not be resolved while processing the scan.', 'security-guard' ),
			);
			update_option( self::MONITORING_OPTION, $state, false );
			return;
		}

		@set_time_limit( 0 );
		$chunk = $state['chunk'];
		$report = isset( $chunk['report'] ) && is_array( $chunk['report'] ) ? $chunk['report'] : self::empty_report();
		$offset = isset( $chunk['offset'] ) ? absint( $chunk['offset'] ) : 0;
		$result = self::scan_php_files( $root, $report, $offset, self::BATCH_PHP_FILES );
		if ( is_wp_error( $result ) ) {
			unset( $state['chunk'] );
			$state['last_scan'] = array(
				'scanned_at' => current_time( 'mysql', true ),
				'error' => $result->get_error_message(),
			);
			update_option( self::MONITORING_OPTION, $state, false );
			error_log( 'Security Guard scheduled file scan failed: ' . sanitize_text_field( $result->get_error_message() ) );
			return;
		}

		$batch_scanned = isset( $report['batch_scanned'] ) ? absint( $report['batch_scanned'] ) : 0;
		$offset += $batch_scanned;
		$batch_done = ! empty( $report['batch_done'] );
		if ( ! $batch_done && $report['php_scanned'] < self::MAX_PHP_FILES ) {
			$chunk['offset'] = $offset;
			$chunk['report'] = $report;
			$chunk['progress'] = array(
				'phase' => 'php',
				'php_scanned' => $report['php_scanned'],
			);
			$state['chunk'] = $chunk;
			update_option( self::MONITORING_OPTION, $state, false );
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::BATCH_HOOK );
			return;
		}

		unset( $state['chunk'] );
		self::finalize_scheduled_scan( $state, $report );
	}

	private static function empty_report() {
		return array(
			'findings' => array(),
			'core_checked' => 0,
			'core_modified' => 0,
			'core_missing' => 0,
			'php_scanned' => 0,
			'suspicious_php' => 0,
			'executable_uploads' => 0,
			'oversized_skipped' => 0,
			'unreadable_skipped' => 0,
			'truncated' => false,
			'checksum_warning' => '',
			'batch_scanned' => 0,
			'batch_done' => false,
		);
	}

	private static function finalize_scheduled_scan( &$state, $result ) {
		$result['scanned_at'] = current_time( 'mysql', true );
		$signatures = self::finding_signatures( $result['findings'] );
		$has_baseline = isset( $state['baseline'] ) && is_array( $state['baseline'] );
		$alerted = isset( $state['alerted'] ) && is_array( $state['alerted'] ) ? $state['alerted'] : array();
		$new_signatures = $has_baseline ? array_diff_key( $signatures, $state['baseline'], $alerted ) : array();
		$new_findings = array();
		foreach ( $result['findings'] as $finding ) {
			$signature = self::finding_signature( $finding );
			if ( isset( $new_signatures[ $signature ] ) ) {
				$new_findings[] = $finding;
			}
		}

		$alert_sent = false;
		$alert_failed = false;
		$failed_signatures = array();
		if ( $new_findings ) {
			$alert_sent = self::send_findings_alert( $new_findings );
			$alert_failed = ! $alert_sent;
			if ( $alert_sent ) {
				$alerted = $alerted + $new_signatures;
			} else {
				$failed_signatures = $new_signatures;
			}
		}
		$complete = empty( $result['truncated'] )
			&& empty( $result['oversized_skipped'] )
			&& empty( $result['unreadable_skipped'] );
		if ( $complete ) {
			$state['baseline'] = $signatures;
			foreach ( $failed_signatures as $signature => $unused ) {
				unset( $state['baseline'][ $signature ] );
			}
			$state['alerted'] = array_diff_key( $signatures, $failed_signatures );
		} else {
			$state['alerted'] = $alerted;
		}
		$state['last_scan'] = array_merge(
			$result,
			array(
				'new_findings' => count( $new_findings ),
				'alert_sent' => $alert_sent,
				'alert_failed' => $alert_failed,
				'baseline_established' => ! $has_baseline && $complete,
			)
		);
		update_option( self::MONITORING_OPTION, $state, false );
	}

	private static function finding_signatures( $findings ) {
		$signatures = array();
		foreach ( $findings as $finding ) {
			$signatures[ self::finding_signature( $finding ) ] = true;
		}
		return $signatures;
	}

	private static function finding_signature( $finding ) {
		return hash(
			'sha256',
			(string) $finding['type'] . '|' . (string) $finding['path'] . '|' . (string) $finding['fingerprint']
		);
	}

	private static function send_findings_alert( $findings ) {
		$recipient = get_option( 'admin_email' );
		if ( ! is_string( $recipient ) || ! is_email( $recipient ) ) {
			error_log( 'Security Guard could not send a scheduled file scan alert: the site administrator email is invalid.' );
			return false;
		}
		$subject = sprintf(
			/* translators: 1: site name, 2: number of new file scan findings. */
			__( '[%1$s] %2$d new file scan finding(s)', 'security-guard' ),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			count( $findings )
		);
		$lines = array(
			__( 'Security Guard found new file scan findings. No files were changed.', 'security-guard' ),
			'',
		);
		foreach ( $findings as $finding ) {
			$lines[] = $finding['type'] . ': ' . $finding['path'];
			$lines[] = $finding['description'];
			$lines[] = '';
		}
		$lines[] = admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE . '#slg-audit' );
		$sent = wp_mail( $recipient, $subject, implode( "\n", $lines ) );
		if ( ! $sent ) {
			error_log( 'Security Guard could not send a scheduled file scan alert email.' );
		}
		return (bool) $sent;
	}

	public static function run_monitoring_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to run file monitoring.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_run_file_monitoring' );
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		if ( is_array( $settings ) && empty( $settings['file_monitoring_enabled'] ) ) {
			set_transient( 'slg_file_monitoring_notice_' . get_current_user_id(), __( 'Enable scheduled file monitoring before starting a scan.', 'security-guard' ), MINUTE_IN_SECONDS );
		} else {
			self::begin_scheduled_scan();
			set_transient( 'slg_file_monitoring_notice_' . get_current_user_id(), __( 'File monitoring scan started. Progress will continue through WordPress Cron.', 'security-guard' ), MINUTE_IN_SECONDS );
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE . '#slg-audit' ) );
		exit;
	}

	public static function reset_monitoring_baseline() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to reset file monitoring.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_reset_file_baseline' );
		$state = get_option( self::MONITORING_OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		unset( $state['baseline'], $state['alerted'], $state['chunk'] );
		update_option( self::MONITORING_OPTION, $state, false );
		set_transient( 'slg_file_monitoring_notice_' . get_current_user_id(), __( 'The file monitoring baseline was reset. The next complete scan will establish a new baseline.', 'security-guard' ), MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE . '#slg-audit' ) );
		exit;
	}

	public static function run_scan() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to scan site files.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_scan_files' );

		$result = self::scan_files();
		if ( is_wp_error( $result ) ) {
			set_transient(
				self::TRANSIENT_PREFIX . get_current_user_id(),
				array( 'error' => $result->get_error_message() ),
				10 * MINUTE_IN_SECONDS
			);
		} else {
			$result['scanned_at'] = current_time( 'mysql', true );
			set_transient( self::TRANSIENT_PREFIX . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE ) );
		exit;
	}

	public static function get_admin_data() {
		$result = get_transient( self::TRANSIENT_PREFIX . get_current_user_id() );
		return is_array( $result ) ? $result : null;
	}

	private static function scan_files() {
		$root = realpath( ABSPATH );
		if ( false === $root ) {
			return new WP_Error( 'slg_scan_root_missing', __( 'The WordPress directory could not be resolved for scanning.', 'security-guard' ) );
		}

		@set_time_limit( 0 );
		$report = array(
			'findings' => array(),
			'core_checked' => 0,
			'core_modified' => 0,
			'core_missing' => 0,
			'php_scanned' => 0,
			'suspicious_php' => 0,
			'executable_uploads' => 0,
			'oversized_skipped' => 0,
			'unreadable_skipped' => 0,
			'truncated' => false,
			'checksum_warning' => '',
		);

		self::check_core_files( $root, $report );
		$file_scan = self::scan_php_files( $root, $report );
		if ( is_wp_error( $file_scan ) ) {
			return $file_scan;
		}

		return $report;
	}

	private static function check_core_files( $root, &$report ) {
		global $wp_version;

		if ( ! function_exists( 'get_core_checksums' ) && file_exists( ABSPATH . 'wp-admin/includes/update.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		if ( ! function_exists( 'get_core_checksums' ) ) {
			$report['checksum_warning'] = __( 'WordPress core checksum verification is unavailable in this installation.', 'security-guard' );
			return;
		}

		$checksums = get_core_checksums( isset( $wp_version ) ? $wp_version : get_bloginfo( 'version' ), get_locale() );
		if ( ! is_array( $checksums ) || ! $checksums ) {
			$report['checksum_warning'] = __( 'Official WordPress core checksums could not be retrieved. Checksum verification was not completed; local file checks still ran.', 'security-guard' );
			return;
		}

		foreach ( $checksums as $relative_path => $expected_checksum ) {
			if (
				! is_string( $relative_path )
				|| ! is_string( $expected_checksum )
				|| ! preg_match( '/^[a-f0-9]{32}$/i', $expected_checksum )
				|| preg_match( '#(^|/)\.\.?(/|$)#', $relative_path )
			) {
				$report['checksum_warning'] = __( 'The official core checksum response contained an invalid entry. Some files may not have been verified.', 'security-guard' );
				continue;
			}

			$path = $root . DIRECTORY_SEPARATOR . str_replace( array( '/', '\\' ), DIRECTORY_SEPARATOR, $relative_path );
			$real_path = realpath( $path );
			$report['core_checked']++;

			if ( false === $real_path || 0 !== strpos( $real_path, $root . DIRECTORY_SEPARATOR ) || ! is_file( $real_path ) ) {
				$report['core_missing']++;
				self::add_finding(
					$report,
					'missing_core_file',
					$relative_path,
					__( 'A file expected by the official WordPress core checksums was not found.', 'security-guard' ),
					''
				);
				continue;
			}

			$actual_checksum = md5_file( $real_path );
			if ( false === $actual_checksum ) {
				$report['unreadable_skipped']++;
				continue;
			}
			if ( ! hash_equals( strtolower( $expected_checksum ), strtolower( $actual_checksum ) ) ) {
				$report['core_modified']++;
				self::add_finding(
					$report,
					'modified_core_file',
					$relative_path,
					__( 'The file does not match the official checksum for this WordPress version and locale.', 'security-guard' ),
					substr( $actual_checksum, 0, 16 )
				);
			}
		}
	}

	private static function scan_php_files( $root, &$report, $offset = 0, $batch_limit = 0 ) {
		$uploads_path = function_exists( 'wp_upload_dir' ) ? wp_upload_dir( null, false ) : array();
		$uploads_directory = isset( $uploads_path['basedir'] ) && is_string( $uploads_path['basedir'] ) ? $uploads_path['basedir'] : '';
		$uploads_root = '' !== $uploads_directory ? realpath( $uploads_directory ) : false;
		$total_bytes = 0;
		$scan_roots = array(
			array(
				'path' => $root,
				'prefix' => '',
			),
		);
		$content_root = defined( 'WP_CONTENT_DIR' ) ? realpath( WP_CONTENT_DIR ) : false;
		if (
			false !== $content_root
			&& ( is_link( WP_CONTENT_DIR ) || ! self::path_is_within( $content_root, $root ) )
		) {
			$scan_roots[] = array(
				'path' => $content_root,
				'prefix' => 'external-content/',
			);
		}
		if (
			false !== $uploads_root
			&& ( is_link( $uploads_directory ) || ! self::is_covered_by_scan_roots( $uploads_root, $scan_roots ) )
		) {
			$scan_roots[] = array(
				'path' => $uploads_root,
				'prefix' => is_link( $uploads_directory ) ? 'linked-uploads/' : 'external-uploads/',
			);
		}
		$php_index = 0;
		$batch_scanned = 0;
		$report['batch_done'] = false;
		$report['batch_scanned'] = 0;

		foreach ( $scan_roots as $scan_root ) {
			$scan_root_path = $scan_root['path'];
			$display_prefix = $scan_root['prefix'];
			try {
				$directory = new RecursiveDirectoryIterator( $scan_root_path, FilesystemIterator::SKIP_DOTS );
				$filter = new RecursiveCallbackFilterIterator(
					$directory,
					static function ( $current ) use ( $scan_root_path, $display_prefix ) {
						if ( $current->isLink() ) {
							return false;
						}
						if ( ! $current->isDir() ) {
							return true;
						}
						$relative = strtolower( self::relative_path( $current->getPathname(), $scan_root_path ) );
						$normalized = '/' . $relative . '/';
						$excluded = array( '/.git/', '/node_modules/' );
						if ( '' === $display_prefix ) {
							$excluded[] = '/wp-content/cache/';
							$excluded[] = '/wp-content/upgrade/';
						} elseif ( 'external-content/' === $display_prefix ) {
							$excluded[] = '/cache/';
							$excluded[] = '/upgrade/';
						}
						foreach ( $excluded as $path ) {
							if ( false !== strpos( $normalized, $path ) ) {
								return false;
							}
						}
						return true;
					}
				);
				$iterator = new RecursiveIteratorIterator( $filter, RecursiveIteratorIterator::LEAVES_ONLY );

				foreach ( $iterator as $file ) {
					if ( ! $file->isFile() || $file->isLink() ) {
						continue;
					}
					$path = $file->getRealPath();
					if ( false === $path || ! self::path_is_within( $path, $scan_root_path ) ) {
						continue;
					}
					$relative = $display_prefix . self::relative_path( $path, $scan_root_path );
					$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
					$is_php = in_array( $extension, array( 'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phar' ), true );
					$is_executable_upload = $is_php && false !== $uploads_root && self::path_is_within( $path, $uploads_root );
					if ( ! $is_php ) {
						continue;
					}
					if ( $php_index < $offset ) {
						$php_index++;
						continue;
					}
					if ( $batch_limit > 0 && $batch_scanned >= $batch_limit ) {
						$report['batch_done'] = false;
						break 2;
					}

					if ( $report['php_scanned'] >= self::MAX_PHP_FILES ) {
						$report['truncated'] = true;
						$report['batch_done'] = true;
						break 2;
					}
					$report['php_scanned']++;
					$php_index++;
					$batch_scanned++;
					$report['batch_scanned'] = $batch_scanned;

					if ( $is_executable_upload ) {
						$report['executable_uploads']++;
						self::add_finding(
							$report,
							'executable_upload',
							$relative,
							__( 'A PHP-executable file was found under the uploads directory. Review it; this can be legitimate but is uncommon.', 'security-guard' ),
							''
						);
					}

					$size = $file->getSize();
					$remaining_bytes = self::MAX_TOTAL_BYTES - $total_bytes;
					if ( $size > self::MAX_FILE_BYTES || $size > $remaining_bytes ) {
						$report['oversized_skipped']++;
						$report['truncated'] = true;
						continue;
					}
					$read_length = min( self::MAX_FILE_BYTES + 1, $remaining_bytes + 1 );
					$contents = file_get_contents( $path, false, null, 0, $read_length );
					if ( false === $contents ) {
						$report['unreadable_skipped']++;
						continue;
					}
					if ( strlen( $contents ) > self::MAX_FILE_BYTES || strlen( $contents ) > $remaining_bytes ) {
						$report['oversized_skipped']++;
						$report['truncated'] = true;
						continue;
					}
					$total_bytes += strlen( $contents );

					$rule = self::match_suspicious_php( $contents );
					if ( $rule ) {
						$report['suspicious_php']++;
						self::add_finding(
							$report,
							$rule,
							$relative,
							self::rule_description( $rule ),
							substr( hash( 'sha256', $contents ), 0, 16 )
						);
					}
				}
			} catch ( UnexpectedValueException $error ) {
				return new WP_Error( 'slg_scan_read_failed', __( 'The site files could not be completely scanned. Check filesystem permissions and try again.', 'security-guard' ) );
			}
		}

		if ( 0 === $batch_limit || $batch_scanned < $batch_limit ) {
			$report['batch_done'] = true;
		}
		return true;
	}

	private static function is_covered_by_scan_roots( $path, $scan_roots ) {
		foreach ( $scan_roots as $scan_root ) {
			if ( self::path_is_within( $path, $scan_root['path'] ) ) {
				return true;
			}
		}
		return false;
	}

	private static function match_suspicious_php( $contents ) {
		$rules = array(
			'obfuscated_eval' => '/\b(?:eval|assert)\s*\(\s*(?:base64_decode|gzinflate|gzuncompress)\s*\(/i',
			'request_parameter_execution' => '/\b(?:eval|assert)\s*\(\s*\$_(?:GET|POST|REQUEST|COOKIE)\b/i',
			'decoded_payload_execution' => '/\b(?:base64_decode|gzinflate|gzuncompress)\s*\([^;]{0,512}\)\s*;?\s*(?:eval|assert)\s*\(/is',
		);
		foreach ( $rules as $rule => $pattern ) {
			if ( preg_match( $pattern, $contents ) ) {
				return $rule;
			}
		}
		return '';
	}

	private static function rule_description( $rule ) {
		$descriptions = array(
			'obfuscated_eval' => __( 'The file combines dynamic code execution with a common payload-decoding or decompression function. Review its source and origin.', 'security-guard' ),
			'request_parameter_execution' => __( 'The file appears to execute code supplied directly through a request parameter. Review its source and origin.', 'security-guard' ),
			'decoded_payload_execution' => __( 'The file appears to execute a decoded or decompressed payload. Review its source and origin.', 'security-guard' ),
		);
		return isset( $descriptions[ $rule ] ) ? $descriptions[ $rule ] : __( 'A suspicious code pattern was found. Review the file in context.', 'security-guard' );
	}

	private static function add_finding( &$report, $type, $path, $description, $fingerprint ) {
		if ( count( $report['findings'] ) >= self::MAX_FINDINGS ) {
			$report['truncated'] = true;
			return;
		}
		$report['findings'][] = array(
			'type' => sanitize_key( $type ),
			'path' => sanitize_text_field( $path ),
			'description' => $description,
			'fingerprint' => $fingerprint,
		);
	}

	private static function relative_path( $path, $root ) {
		return ltrim( str_replace( '\\', '/', substr( $path, strlen( $root ) ) ), '/' );
	}

	private static function path_is_within( $path, $directory ) {
		$path = wp_normalize_path( $path );
		$directory = untrailingslashit( wp_normalize_path( $directory ) );
		if ( DIRECTORY_SEPARATOR === '\\' ) {
			$path = strtolower( $path );
			$directory = strtolower( $directory );
		}
		return $path === $directory || 0 === strpos( $path, trailingslashit( $directory ) );
	}
}
