<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard_Backups {
	const CRON_HOOK = 'slg_weekly_backup';
	const WEEKLY_SCHEDULE = 'slg_weekly';
	const MAX_ARCHIVE_FILES = 25000;

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_weekly_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'scheduled_backup' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
		add_action( 'admin_post_slg_run_backup', array( __CLASS__, 'run_backup_now' ) );
		add_action( 'admin_post_slg_download_archive', array( __CLASS__, 'download_archive' ) );
	}

	public static function activate() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, self::WEEKLY_SCHEDULE, self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
			$timestamp = wp_next_scheduled( self::CRON_HOOK );
		}
	}

	public static function add_weekly_schedule( $schedules ) {
		$schedules[ self::WEEKLY_SCHEDULE ] = array(
			'interval' => WEEK_IN_SECONDS,
			'display' => __( 'Once Weekly', 'security-guard' ),
		);
		return $schedules;
	}

	public static function ensure_schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			self::activate();
		}
	}

	public static function scheduled_backup() {
		$result = self::create_backup();
		if ( is_wp_error( $result ) ) {
			error_log( 'Security Guard scheduled backup failed: ' . sanitize_text_field( $result->get_error_message() ) );
			self::save_status( false, $result->get_error_message() );
			return;
		}
		self::save_status( true, basename( $result ) );
	}

	public static function render_admin_section() {
		$path = self::backup_directory();
		$files = is_wp_error( $path ) ? array() : self::backup_files( $path );
		$notice = get_transient( 'slg_backup_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'slg_backup_notice_' . get_current_user_id() );
			echo '<div class="notice notice-info inline"><p>' . esc_html( $notice ) . '</p></div>';
		}
		if ( is_wp_error( $path ) ) {
			echo '<p class="notice notice-error inline"><span>' . esc_html( $path->get_error_message() ) . '</span></p>';
		}
		$status = get_option( 'slg_backup_last_result', array() );
		if ( is_array( $status ) && isset( $status['time'], $status['success'], $status['message'] ) ) {
			$label = $status['success'] ? __( 'Last backup succeeded', 'security-guard' ) : __( 'Last backup failed', 'security-guard' );
			echo '<p>' . esc_html( $label . ' — ' . $status['time'] . ' UTC: ' . $status['message'] ) . '</p>';
		}
		$next_run = wp_next_scheduled( self::CRON_HOOK );
		if ( $next_run ) {
			echo '<p class="description">' . esc_html( sprintf( __( 'Next scheduled backup: %s UTC.', 'security-guard' ), gmdate( 'Y-m-d H:i:s', $next_run ) ) ) . '</p>';
		}
		?>
		<p>
			<?php
			if ( $path && ! is_wp_error( $path ) ) {
				esc_html_e( 'Private backup directory:', 'security-guard' );
				echo ' <code>' . esc_html( $path ) . '</code>';
			}
			?>
		</p>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="slg_run_backup">
			<?php wp_nonce_field( 'slg_run_backup' ); ?>
			<?php submit_button( __( 'Run database + file backup now', 'security-guard' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php if ( $files ) : ?>
			<h3><?php esc_html_e( 'Available backup archives', 'security-guard' ); ?></h3>
			<ul>
				<?php foreach ( $files as $file ) : ?>
					<li>
						<?php echo esc_html( gmdate( 'Y-m-d H:i:s', filemtime( $file ) ) . ' UTC — ' . size_format( filesize( $file ) ) ); ?>
						<?php
						$url = wp_nonce_url(
							add_query_arg(
								array(
									'action' => 'slg_download_archive',
									'file' => basename( $file ),
								),
								admin_url( 'admin-post.php' )
							),
							'slg_download_archive_' . basename( $file )
						);
						?>
						<a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Download', 'security-guard' ); ?></a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php
	}

	public static function get_admin_data() {
		$path = self::backup_directory();
		$files = is_wp_error( $path ) ? array() : self::backup_files( $path );
		$notice = get_transient( 'slg_backup_notice_' . get_current_user_id() );
		$status = get_option( 'slg_backup_last_result', array() );
		$status = is_array( $status ) ? array(
			'success' => ! empty( $status['success'] ),
			'time' => isset( $status['time'] ) && is_string( $status['time'] ) ? $status['time'] : '',
			'message' => isset( $status['message'] ) && is_string( $status['message'] ) ? $status['message'] : '',
		) : array();
		$next_run = wp_next_scheduled( self::CRON_HOOK );
		$archives = array();

		foreach ( $files as $file ) {
			$filename = basename( $file );
			$url = add_query_arg(
				array(
					'action' => 'slg_download_archive',
					'file' => $filename,
					'_wpnonce' => wp_create_nonce( 'slg_download_archive_' . $filename ),
				),
				admin_url( 'admin-post.php' )
			);
			$archives[] = array(
				'label' => gmdate( 'Y-m-d H:i:s', filemtime( $file ) ) . ' UTC — ' . size_format( filesize( $file ) ),
				'url' => esc_url_raw( $url ),
			);
		}

		return array(
			'directory' => is_wp_error( $path ) ? '' : $path,
			'error' => is_wp_error( $path ) ? $path->get_error_message() : '',
			'notice' => is_string( $notice ) ? $notice : '',
			'status' => is_array( $status ) ? $status : array(),
			'nextRun' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
			'archives' => $archives,
		);
	}

	public static function run_backup_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to run backups.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_run_backup' );
		$result = self::create_backup();
		if ( is_wp_error( $result ) ) {
			set_transient( 'slg_backup_notice_' . get_current_user_id(), $result->get_error_message(), MINUTE_IN_SECONDS );
			self::save_status( false, $result->get_error_message() );
		} else {
			set_transient( 'slg_backup_notice_' . get_current_user_id(), __( 'Database + file backup completed successfully.', 'security-guard' ), MINUTE_IN_SECONDS );
			self::save_status( true, basename( $result ) );
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE ) );
		exit;
	}

	public static function download_archive() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to download this backup.', 'security-guard' ), '', array( 'response' => 403 ) );
		}
		$file = isset( $_GET['file'] ) && is_string( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		check_admin_referer( 'slg_download_archive_' . $file );
		if ( ! preg_match( '/^slg-backup-\d{8}-\d{6}-[a-f0-9]{6}\.zip$/', $file ) ) {
			wp_die( esc_html__( 'Invalid backup archive name.', 'security-guard' ), '', array( 'response' => 400 ) );
		}
		$directory = self::backup_directory();
		if ( is_wp_error( $directory ) ) {
			wp_die( esc_html( $directory->get_error_message() ), '', array( 'response' => 500 ) );
		}
		$path = $directory . DIRECTORY_SEPARATOR . $file;
		$real_path = realpath( $path );
		if ( false === $real_path || ! is_file( $real_path ) || dirname( $real_path ) !== realpath( $directory ) ) {
			wp_die( esc_html__( 'Backup archive not found.', 'security-guard' ), '', array( 'response' => 404 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Length: ' . (string) filesize( $real_path ) );
		header( 'Content-Disposition: attachment; filename="' . $file . '"' );
		readfile( $real_path );
		exit;
	}

	private static function create_backup() {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'slg_zip_missing', __( 'The PHP ZipArchive extension is required for database + file backups. Ask your host to enable it.', 'security-guard' ) );
		}
		$directory = self::backup_directory();
		if ( is_wp_error( $directory ) ) {
			return $directory;
		}
		if ( ! function_exists( 'set_time_limit' ) || ! @set_time_limit( 0 ) ) {
			return new WP_Error( 'slg_time_limit_unavailable', __( 'PHP could not extend the execution time for this backup. Ask your host to permit set_time_limit(0) or increase max_execution_time before retrying.', 'security-guard' ) );
		}
		$site_files = self::get_site_files();
		if ( is_wp_error( $site_files ) ) {
			return $site_files;
		}
		$temporary_sql = tempnam( sys_get_temp_dir(), 'slg-db-' );
		if ( false === $temporary_sql ) {
			return new WP_Error( 'slg_temp_failed', __( 'A temporary database export file could not be created.', 'security-guard' ) );
		}
		$stream = fopen( $temporary_sql, 'wb' );
		if ( false === $stream ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_temp_open_failed', __( 'The temporary database export file could not be opened.', 'security-guard' ) );
		}
		$dump = self::write_database_dump( $stream );
		$closed = fclose( $stream );
		if ( ! $closed && ! is_wp_error( $dump ) ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_db_close_failed', __( 'The temporary database export could not be finalized.', 'security-guard' ) );
		}
		if ( is_wp_error( $dump ) ) {
			unlink( $temporary_sql );
			return $dump;
		}

		$filename = 'slg-backup-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 3 ) ) . '.zip';
		$archive_path = $directory . DIRECTORY_SEPARATOR . $filename;
		$archive = new ZipArchive();
		$opened = $archive->open( $archive_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );
		if ( true !== $opened ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_zip_open_failed', __( 'The backup archive could not be created in the private directory.', 'security-guard' ) );
		}
		if ( ! $archive->addFile( $temporary_sql, 'database.sql' ) ) {
			self::discard_archive( $archive, $archive_path );
			unlink( $temporary_sql );
			return new WP_Error( 'slg_zip_database_failed', __( 'The database export could not be added to the backup archive.', 'security-guard' ) );
		}

		$file_result = self::add_site_files( $archive, $site_files );
		if ( is_wp_error( $file_result ) ) {
			self::discard_archive( $archive, $archive_path );
			unlink( $temporary_sql );
			return $file_result;
		}
		if ( ! $archive->close() ) {
			unlink( $temporary_sql );
			self::remove_archive_artifacts( $archive_path );
			return new WP_Error( 'slg_zip_close_failed', __( 'The backup archive could not be finalized.', 'security-guard' ) );
		}
		unlink( $temporary_sql );
		if ( ! chmod( $archive_path, 0600 ) ) {
			self::remove_archive_artifacts( $archive_path );
			return new WP_Error( 'slg_archive_permissions', __( 'The completed backup archive permissions could not be restricted.', 'security-guard' ) );
		}
		self::apply_retention( $directory );
		return $archive_path;
	}

	private static function write_database_dump( $stream ) {
		global $wpdb;
		if ( ! self::write_all( $stream, "-- Security Guard database backup\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n" ) ) {
			return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'security-guard' ) );
		}
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		if ( ! is_array( $tables ) ) {
			return new WP_Error( 'slg_db_tables_failed', __( 'Could not list database tables for backup.', 'security-guard' ) );
		}
		foreach ( $tables as $table ) {
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			$create = $wpdb->get_row( "SHOW CREATE TABLE {$table_sql}", ARRAY_N );
			if ( ! is_array( $create ) || ! isset( $create[1] ) ) {
				return new WP_Error( 'slg_db_schema_failed', __( 'Could not read a database table definition.', 'security-guard' ) );
			}
			if ( ! self::write_all( $stream, "\nDROP TABLE IF EXISTS {$table_sql};\n" . $create[1] . ";\n" ) ) {
				return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'security-guard' ) );
			}
			$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table_sql}", 0 );
			if ( ! is_array( $columns ) ) {
				return new WP_Error( 'slg_db_columns_failed', __( 'Could not read database table columns.', 'security-guard' ) );
			}
			if ( ! $columns ) {
				continue;
			}
			$column_sql = implode( ', ', array_map( static function ( $column ) {
				return '`' . str_replace( '`', '``', $column ) . '`';
			}, $columns ) );
			$offset = 0;
			do {
				$rows = $wpdb->get_results( "SELECT * FROM {$table_sql} LIMIT 200 OFFSET " . absint( $offset ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					return new WP_Error( 'slg_db_rows_failed', __( 'Could not read rows from a database table.', 'security-guard' ) );
				}
				foreach ( $rows as $row ) {
					$values = array();
					foreach ( $columns as $column ) {
						$value = $row[ $column ];
						$values[] = null === $value ? 'NULL' : "'" . $wpdb->_real_escape( $value ) . "'";
					}
					if ( ! self::write_all( $stream, 'INSERT INTO ' . $table_sql . ' (' . $column_sql . ') VALUES (' . implode( ', ', $values ) . ");\n" ) ) {
						return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'security-guard' ) );
					}
				}
				$offset += count( $rows );
			} while ( count( $rows ) === 200 );
		}
		if ( ! self::write_all( $stream, "\nSET FOREIGN_KEY_CHECKS=1;\n" ) ) {
			return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be finalized.', 'security-guard' ) );
		}
		return true;
	}

	private static function write_all( $stream, $contents ) {
		$length = strlen( $contents );
		$written = 0;
		while ( $written < $length ) {
			$result = fwrite( $stream, substr( $contents, $written ) );
			if ( false === $result || 0 === $result ) {
				return false;
			}
			$written += $result;
		}
		return true;
	}

	private static function get_site_files() {
		$root = realpath( ABSPATH );
		if ( false === $root ) {
			return new WP_Error( 'slg_files_root_missing', __( 'The WordPress directory could not be resolved for backup.', 'security-guard' ) );
		}
		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
			$files = array();
			$count = 0;
			foreach ( $iterator as $file ) {
				if ( $file->isLink() || ! $file->isFile() ) {
					continue;
				}
				$path = $file->getRealPath();
				if ( false === $path || 0 !== strpos( $path, $root . DIRECTORY_SEPARATOR ) ) {
					continue;
				}
				$relative = substr( $path, strlen( $root ) + 1 );
				if ( preg_match( '#^wp-content/cache(?:/|$)#', str_replace( DIRECTORY_SEPARATOR, '/', $relative ) ) ) {
					continue;
				}
				if ( ++$count > self::MAX_ARCHIVE_FILES ) {
					return new WP_Error( 'slg_file_limit', __( 'The site contains more files than this MVP backup limit supports. Use a host backup solution for this site.', 'security-guard' ) );
				}
				$files[] = array(
					'path' => $path,
					'relative' => str_replace( DIRECTORY_SEPARATOR, '/', $relative ),
				);
			}
		} catch ( UnexpectedValueException $error ) {
			return new WP_Error( 'slg_file_scan_failed', __( 'The site files could not be completely scanned for backup. Check filesystem permissions.', 'security-guard' ) );
		}
		return $files;
	}

	private static function add_site_files( $archive, $files ) {
		foreach ( $files as $file ) {
			if ( ! $archive->addFile( $file['path'], $file['relative'] ) ) {
				return new WP_Error( 'slg_file_add_failed', __( 'A site file could not be added to the backup archive.', 'security-guard' ) );
			}
		}
		return true;
	}

	private static function discard_archive( $archive, $archive_path ) {
		$archive->unchangeAll();
		$archive->close();
		self::remove_archive_artifacts( $archive_path );
	}

	private static function remove_archive_artifacts( $archive_path ) {
		if ( file_exists( $archive_path ) && ! unlink( $archive_path ) ) {
			error_log( 'Security Guard could not remove an incomplete backup archive.' );
		}
		$pattern = $archive_path . '.*';
		$temporary_files = glob( $pattern );
		if ( ! is_array( $temporary_files ) ) {
			return;
		}
		$expected_prefix = basename( $archive_path ) . '.';
		foreach ( $temporary_files as $temporary_file ) {
			if (
				! is_file( $temporary_file )
				|| 0 !== strpos( basename( $temporary_file ), $expected_prefix )
				|| ! preg_match( '/^[A-Za-z0-9]+$/', substr( basename( $temporary_file ), strlen( $expected_prefix ) ) )
			) {
				continue;
			}
			if ( ! unlink( $temporary_file ) ) {
				error_log( 'Security Guard could not remove a temporary backup archive file.' );
			}
		}
	}

	private static function backup_directory() {
		$document_root = isset( $_SERVER['DOCUMENT_ROOT'] ) && is_string( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( wp_unslash( $_SERVER['DOCUMENT_ROOT'] ) ) : false;
		if ( false === $document_root ) {
			return new WP_Error( 'slg_docroot_unknown', __( 'The web server document root could not be determined. Secure backup storage cannot be verified.', 'security-guard' ) );
		}

		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		$configured_directory = isset( $settings['backup_directory'] ) && is_string( $settings['backup_directory'] )
			? trim( $settings['backup_directory'] )
			: '';
		$directory = '' !== $configured_directory
			? wp_normalize_path( $configured_directory )
			: dirname( $document_root ) . DIRECTORY_SEPARATOR . '.secure-login-guard-' . substr( hash( 'sha256', home_url() ), 0, 12 );

		if ( '' !== $configured_directory && ! preg_match( '#^(?:/|[A-Za-z]:/)#', $directory ) ) {
			return new WP_Error( 'slg_backup_dir_not_absolute', __( 'The backup directory must be an absolute server path. Update it under Settings > Security Guard.', 'security-guard' ) );
		}
		if ( preg_match( '#^[A-Za-z]:/$#', $directory ) ) {
			return new WP_Error( 'slg_backup_dir_root', __( 'A filesystem root cannot be used for backup storage. Choose a dedicated private directory outside the web root.', 'security-guard' ) );
		}
		if ( preg_match( '#(^|/)\.{1,2}(/|$)#', $directory ) ) {
			return new WP_Error( 'slg_backup_dir_relative_segments', __( 'The backup directory cannot contain dot or parent-directory path segments.', 'security-guard' ) );
		}

		$resolved_directory = self::resolve_backup_directory_path( $directory );
		if ( is_wp_error( $resolved_directory ) ) {
			return $resolved_directory;
		}
		if ( '/' === $resolved_directory || preg_match( '#^[A-Za-z]:/$#', $resolved_directory ) ) {
			return new WP_Error( 'slg_backup_dir_root', __( 'A filesystem root cannot be used for backup storage. Choose a dedicated private directory outside the web root.', 'security-guard' ) );
		}
		if ( self::path_is_within( $resolved_directory, $document_root ) ) {
			return new WP_Error( 'slg_backup_dir_public', __( 'The backup directory is inside the public web root. Choose a private path outside it; no backup was written.', 'security-guard' ) );
		}

		if ( ! is_dir( $resolved_directory ) && ! wp_mkdir_p( $resolved_directory ) ) {
			return new WP_Error( 'slg_backup_dir_create_failed', __( 'The private backup directory could not be created. Ask your host for a writable path outside the public web root, then set it under Settings > Security Guard.', 'security-guard' ) );
		}

		$real_directory = realpath( $resolved_directory );
		if ( false === $real_directory || ! is_dir( $real_directory ) ) {
			return new WP_Error( 'slg_backup_dir_unavailable', __( 'The private backup directory could not be resolved after creation. Check the configured path and filesystem permissions.', 'security-guard' ) );
		}
		if ( self::path_is_within( $real_directory, $document_root ) ) {
			return new WP_Error( 'slg_backup_dir_public', __( 'The configured backup directory is inside the public web root. No backup was written.', 'security-guard' ) );
		}
		if ( ! is_writable( $real_directory ) || ! @chmod( $real_directory, 0700 ) ) {
			return new WP_Error( 'slg_backup_dir_permissions', __( 'The private backup directory is not writable or its permissions could not be restricted to the PHP account. Ask your host to adjust the directory ownership and permissions.', 'security-guard' ) );
		}
		return $real_directory;
	}

	private static function resolve_backup_directory_path( $directory ) {
		$path = untrailingslashit( $directory );
		if ( '' === $path ) {
			$path = '/';
		}
		$missing = array();

		while ( ! file_exists( $path ) && ! is_link( $path ) ) {
			$parent = dirname( $path );
			if ( $parent === $path ) {
				return new WP_Error( 'slg_backup_dir_invalid', __( 'The backup directory path could not be resolved. Check that it is an absolute path on this server.', 'security-guard' ) );
			}
			$missing[] = basename( $path );
			$path = $parent;
		}

		$resolved = realpath( $path );
		if ( false === $resolved || ! is_dir( $resolved ) ) {
			return new WP_Error( 'slg_backup_dir_parent_invalid', __( 'The backup directory or its existing parent is not a directory. Choose a valid private directory path.', 'security-guard' ) );
		}

		foreach ( array_reverse( $missing ) as $component ) {
			$resolved = trailingslashit( $resolved ) . $component;
		}

		return '/' === $resolved ? '/' : untrailingslashit( $resolved );
	}

	private static function path_is_within( $path, $directory ) {
		$path = wp_normalize_path( $path );
		$directory = wp_normalize_path( $directory );
		$path = '/' === $path ? '/' : untrailingslashit( $path );
		$directory = '/' === $directory ? '/' : untrailingslashit( $directory );
		if ( '' === $directory ) {
			$directory = '/';
		}
		if ( DIRECTORY_SEPARATOR === '\\' ) {
			$path = strtolower( $path );
			$directory = strtolower( $directory );
		}
		if ( $path === $directory || '/' === $directory ) {
			return true;
		}

		return 0 === strpos( $path, trailingslashit( $directory ) );
	}

	private static function apply_retention( $directory ) {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		$keep = isset( $settings['backup_retention'] ) ? min( 30, max( 1, absint( $settings['backup_retention'] ) ) ) : 5;
		$files = self::backup_files( $directory );
		usort( $files, static function ( $first, $second ) {
			return filemtime( $second ) <=> filemtime( $first );
		} );
		foreach ( array_slice( $files, $keep ) as $old_file ) {
			if ( ! unlink( $old_file ) ) {
				error_log( 'Security Guard could not remove an expired backup archive.' );
			}
		}
	}

	private static function save_status( $success, $message ) {
		update_option(
			'slg_backup_last_result',
			array(
				'time' => gmdate( 'Y-m-d H:i:s' ),
				'success' => (bool) $success,
				'message' => sanitize_text_field( $message ),
			),
			false
		);
	}

	private static function backup_files( $directory ) {
		$files = glob( $directory . DIRECTORY_SEPARATOR . 'slg-backup-*.zip' );
		if ( ! is_array( $files ) ) {
			return array();
		}
		return array_values(
			array_filter( $files, static function ( $path ) {
				return is_file( $path ) && preg_match( '/^slg-backup-\d{8}-\d{6}-[a-f0-9]{6}\.zip$/', basename( $path ) );
			} )
		);
	}
}
