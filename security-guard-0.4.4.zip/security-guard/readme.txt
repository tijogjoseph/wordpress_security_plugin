=== Security Guard ===
Contributors: security-guard
Tags: security, login, firewall, two-factor, backup, rate-limit
Requires at least: 6.0
Requires PHP: 8.2
Stable tag: 0.4.4
License: GPL-2.0-or-later

Adds login protection and site security checks to WordPress.

== Description ==

Features:

* Configurable failed-login rate limits by username/IP pair and by IP address.
* Optional per-user TOTP two-factor authentication and one-time recovery codes.
* Configurable inactivity logout for active browser sessions.
* Server-side password strength checks on WordPress registration, profile, and
  password-reset flows supported by core.
* A honeypot for comments made through the standard WordPress comment form.
* Cloudflare Turnstile for login, registration, and standard comment forms when keys are configured.
* Heuristic request filtering for common high-confidence SQL injection, XSS, traversal, and unsupported-method patterns.
* Temporary IP blocks and privacy-conscious firewall event records.
* Weekly database + site file ZIP backups, private local storage, and configurable retention.
* Manual database-only SQL download.
* Report-only file/database checks and an on-demand scan of common core content tables.
* Report-only file integrity and suspicious PHP-pattern scan (PRO preview).
* Optional weekly report-only file monitoring with email alerts for new findings.
* Successful-login email notifications and account-session revocation controls.
* Dashboard-style admin page with status cards and routed section navigation.

The admin dashboard UI uses React from WordPress's bundled `wp-element` package.
Security checks, settings validation, backup operations, and privileged actions
remain server-side in PHP; the dashboard submits through WordPress's Settings
API and authenticated admin-post handlers.

Login counters and temporary blocks are stored as WordPress transients.
Transient keys are HMAC-hashed. Firewall logs retain a keyed IP fingerprint,
request method, redacted path, rule code, and time; request bodies, raw IP
addresses, and header values are not logged.

== Installation ==

1. In WordPress, go to Plugins > Add New Plugin > Upload Plugin and select the
   installable security-guard.zip package. The ZIP must contain the
   security-guard folder at its top level, with
   security-guard/security-guard.php inside it.
   Alternatively, copy the security-guard folder into wp-content/plugins/.
2. Activate Security Guard in the WordPress Plugins screen.
3. Configure limits and review checks under Settings > Security Guard.
4. Configure Turnstile keys under Settings > Security Guard to enable CAPTCHA.
5. Users may enable TOTP and generate recovery codes under Users > Profile.

== Upgrade from secure-login-guard ==

The plugin folder and main file changed in version 0.3.4. WordPress treats the
new path as a different plugin, so deactivate the old Secure Login Guard
version before installing and activating Security Guard. Do not leave both
copies active. Settings and user 2FA data are retained. The private backup
directory keeps its existing name so previously created archives remain
available.

== Important ==

The IP address is read only from the web server REMOTE_ADDR value. Forwarded
headers are not trusted because clients can spoof them. If the site is behind
a reverse proxy, configure the proxy/web server to provide the correct
REMOTE_ADDR value before enabling IP-based limits.

Sites behind a shared NAT may see multiple users sharing an IP-based limit.
Tune the limits to suit the site and ensure administrators have an alternative
recovery path before deployment.

Two-factor enrollment is optional per user. Users must save the recovery codes
shown after enrollment or regeneration; the codes are displayed once. Test
recovery before requiring 2FA operationally. TOTP requires the server clock to
be reasonably accurate. TOTP works with Google Authenticator, Microsoft
Authenticator, and compatible apps. Email OTP is offered as a fallback after
the password is verified. SMS OTP is not included because it requires a
third-party provider account and credentials.

Inactivity logout uses periodic authenticated browser requests and JavaScript
activity listeners, with a brief warning before logout. It requires JavaScript
and a browser tab on the site; a network failure is logged to the browser
console and prevents the activity check from completing.

Password checks require a configured minimum length (12 by default) and at
least three of lowercase, uppercase, number, and symbol. Passwords created by
custom plugins, external identity providers, or APIs may not use the core
flows covered by these checks.

The comment and registration honeypots apply to standard WordPress forms.
Turnstile verification is also applied to those forms once both keys are set.
Custom form plugins need their own spam controls.

Scheduled backups run weekly through WordPress Cron and include the database
and regular site files. WordPress Cron is traffic-triggered; low-traffic sites
should configure a real server cron to call wp-cron.php. The plugin requires
PHP ZipArchive and a writable private directory outside the web root. By
default, it derives a location from the server document root. If the host does
not permit this, ask the host for an absolute private directory path and enter
it in Settings > Security Guard > Protection settings. The plugin rejects
paths inside the web root and does not fall back to public storage. Changing
the configured path does not move existing archives; they remain in their
previous location. The default retention is five successful archives;
cache files are excluded and sites above the 25,000-file MVP limit are refused.
Manual backups can take several minutes. The plugin requests unlimited PHP
execution time, but the web server or host can still impose its own request
timeout.
Archives contain sensitive user data and site code. Download them securely,
keep an off-site copy, and test restoration. This MVP does not automate restore.

The request firewall uses bounded heuristic inspection of methods, headers,
URL parameters, and a limited portion of request bodies. It may block
legitimate requests containing script or SQL-like text and does not inspect
uploaded file contents. Review event records and disable the firewall if it
interferes with site content or plugins. It is not a replacement for a
maintained host/network WAF. Temporary IP blocks use only REMOTE_ADDR and can
affect users sharing a NAT; forwarded headers are never trusted.

File permissions are reported with typical targets, not changed automatically.
Database scanning is on-demand and limited to common WordPress posts,
comments, options, and user metadata; markers can occur in legitimate content
and require manual review. Neither report is a complete audit.

Turnstile requires valid site and secret keys from Cloudflare. When configured,
verification fails closed if the provider is unavailable, and the request IP
may be sent to Cloudflare for verification. SMS OTP is deferred.
The security checks are advisory; the plugin does not automatically alter
server permissions or database settings.

The file integrity scan compares WordPress core files to the official checksums
for the installed version and locale when available. It also checks PHP files
for a small set of suspicious code patterns and reports PHP-executable files in
uploads. Custom content and uploads directories outside the WordPress root are
also included when WordPress reports their paths. The scan is bounded to 10,000
PHP files, 1 MiB per file, and 64 MiB of PHP source content; cache, upgrade,
Git, and node_modules directories are excluded. It does not inspect every file
type, and pattern matches can be legitimate. Checksum lookup may require an
internet connection. Results are advisory and do not modify, delete, or
quarantine files; this is not a comprehensive malware scanner.

Weekly file monitoring is disabled by default and can be enabled in Protection
settings. It uses WordPress Cron, so scans may be delayed on low-traffic sites
unless a real server cron calls wp-cron.php. The first complete scan establishes
a baseline without sending an alert; later scans email new findings to the site
administrator address. Email delivery depends on the site's mail configuration.
Scheduled scans use the same file-count and source-size limits as the manual
scan but are divided into small PHP-file batches. Progress is stored between
WordPress Cron runs, allowing scans to resume after a timeout or interrupted
request. Administrators can start a scan now or reset the baseline. Only one
scan run is resumed at a time. Findings remain report-only and no files are
changed.

== Changelog ==

= 0.4.4 =
* Prevented profile 2FA and session actions from triggering WordPress's misleading unsaved-changes warning.

= 0.4.3 =
* Fixed 2FA profile setup by removing an invalid nested profile/session form.
* Added visible setup, confirmation, cancellation, disable, and session-revoke notices.

= 0.4.2 =
* Added successful-login email notifications.
* Added account session visibility and controls to log out other or all sessions.

= 0.4.1 =
* Made scheduled file monitoring resumable in bounded batches.
* Added manual monitoring start and baseline-reset actions.

= 0.4.0 =
* Added optional weekly file monitoring and administrator email alerts for new findings.

= 0.3.9 =
* Changed dashboard sections to routed pages, showing one section at a time.

= 0.3.8 =
* Added a report-only PRO-preview file integrity and suspicious PHP-pattern scan.

= 0.3.7 =
* Fixed dashboard backup download links to preserve query separators and valid nonces.

= 0.3.6 =
* Prevented PHP's default execution limit from interrupting backup creation when the host permits it.
* Scan and enforce the file-count limit before creating an archive.
* Discard staged archive entries when a file cannot be added.

= 0.3.5 =
* Added a configurable private backup directory with web-root and permission checks.

= 0.3.4 =
* Renamed the plugin folder, main file, and translation text domain to Security Guard.
* Raised the documented minimum PHP version to 8.2.

= 0.3.3 =
* Raised the documented minimum PHP version to 8.2.

= 0.3.2 =
* Renamed the plugin and admin dashboard to Security Guard.
= 0.3.1 =
* Redesigned the admin page as a responsive security dashboard.
= 0.3.0 =
* Added optional TOTP two-factor authentication and recovery codes.
* Added email OTP fallback, Turnstile support, and registration spam controls.
* Added heuristic request firewall, temporary IP blocking, and event records.
* Added scheduled database + file backups with private storage and retention.
* Added advisory stored-content scanning and file-permission recommendations.
* Retained inactivity logout, password rules, and failed-login rate limiting.
