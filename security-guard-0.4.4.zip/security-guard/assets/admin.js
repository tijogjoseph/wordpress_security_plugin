( function () {
	'use strict';

	var config = window.SLGAdmin;
	var element = window.wp && window.wp.element;
	if ( ! config || ! element || ! document.getElementById( 'slg-dashboard-root' ) ) {
		return;
	}

	var h = element.createElement;
	var settings = config.settings;
	var text = config.text;
	var settingsName = 'secure_login_guard_settings';

	function fieldRow( label, id, control ) {
		return h( 'tr', { key: id },
			h( 'th', { scope: 'row' }, h( 'label', { htmlFor: id }, label ) ),
			h( 'td', null, control )
		);
	}

	function numberInput( id, key, min, max ) {
		return h( 'input', {
			id: id,
			type: 'number',
			min: min,
			max: max,
			name: settingsName + '[' + key + ']',
			defaultValue: settings[ key ],
			className: 'small-text'
		} );
	}

	function panelHeading( eyebrow, title, detail, pill ) {
		return h( 'div', { className: 'slg-panel-heading' },
			h( 'div', null,
				h( 'p', { className: 'slg-eyebrow' }, eyebrow ),
				h( 'h2', null, title )
			),
			pill ? h( 'span', { className: 'slg-pill slg-pill-info' }, pill ) :
				( detail ? h( 'p', null, detail ) : null )
		);
	}

	function formTable( rows ) {
		return h( 'table', { className: 'form-table', role: 'presentation' },
			h( 'tbody', null, rows )
		);
	}

	function routeFromHash() {
		var route = window.location.hash.slice( 1 );
		var routes = [ 'slg-protection', 'slg-two-factor', 'slg-backups', 'slg-audit', 'slg-events' ];
		return routes.indexOf( route ) !== -1 ? route : 'slg-protection';
	}

	function statusCard( title, value, target, icon, iconClass, statusClass, onNavigate ) {
		return h( 'a', {
			className: 'slg-status-card',
			href: '#' + target,
			key: title,
			onClick: function ( event ) {
				onNavigate( event, target );
			}
		},
			h( 'span', { className: 'slg-status-icon ' + iconClass, 'aria-hidden': 'true' }, icon ),
			h( 'span', { className: 'slg-status-copy' },
				h( 'strong', null, title ),
				h( 'span', null, value )
			),
			h( 'span', { className: 'slg-status-dot ' + statusClass } )
		);
	}

	function hiddenField( name, value ) {
		return h( 'input', { type: 'hidden', name: name, value: value } );
	}

	function actionForm( action, nonce, label ) {
		return h( 'form', { action: config.urls.adminPost, method: 'post' },
			hiddenField( 'action', action ),
			hiddenField( '_wpnonce', nonce ),
			h( 'button', { type: 'submit', className: 'button' }, label )
		);
	}

	function backupPanel() {
		var backup = config.backup || {};
		var status = backup.status || {};
		var archiveList = ( backup.archives || [] ).map( function ( archive, index ) {
			return h( 'li', { key: index },
				archive.label + ' — ',
				h( 'a', { href: archive.url }, text.download )
			);
		} );

		return h( 'section', { className: 'slg-panel', id: 'slg-backups' },
			panelHeading(
				text.eyebrowRecovery,
				text.backups,
				null,
				status.success ? text.backupHealthy : text.backupAttention
			),
			h( 'p', null, text.backupDescription ),
			h( 'p', { className: 'description' }, text.backupExecutionNote ),
			backup.notice ? h( 'div', { className: 'notice notice-info inline' }, h( 'p', null, backup.notice ) ) : null,
			backup.error ? h( 'div', { className: 'notice notice-error inline' }, h( 'p', null, backup.error ) ) : null,
			status.time && status.message ? h( 'p', null,
				( status.success ? text.backupSucceeded : text.backupFailed ) +
					' — ' + status.time + ' UTC: ' + status.message
			) : null,
			backup.nextRun ? h( 'p', { className: 'description' }, text.nextBackup.replace( '%s', backup.nextRun ) ) : null,
			backup.directory ? h( 'p', null, text.backupFolder + ' ', h( 'code', null, backup.directory ) ) : null,
			actionForm( 'slg_run_backup', config.urls.runBackupNonce, text.runBackup ),
			archiveList.length ? h( 'div', null,
				h( 'h3', null, text.availableArchives ),
				h( 'ul', null, archiveList )
			) : null,
			h( 'p', null, text.manualBackupDescription ),
			actionForm( 'slg_download_backup', config.urls.downloadBackupNonce, text.downloadDatabase )
		);
	}

	function checksTable() {
		var rows = ( config.checks || [] ).map( function ( check, index ) {
			return h( 'tr', { key: index },
				h( 'td', null, check.label ),
				h( 'td', null, check.passed ? check.success : check.failure )
			);
		} );
		return h( 'table', { className: 'widefat striped' },
			h( 'thead', null, h( 'tr', null,
				h( 'th', null, text.check ),
				h( 'th', null, text.result )
			) ),
			h( 'tbody', null, rows )
		);
	}

	function scanResults() {
		var scan = config.scan;
		if ( ! scan ) {
			return null;
		}
		if ( scan.error ) {
			return h( 'div', { className: 'notice notice-error inline' }, h( 'p', null, scan.error ) );
		}
		var timestamp = text.scanAt.replace( '%s', scan.scanned_at || '' );
		if ( ! scan.results || ! scan.results.length ) {
			return h( 'div', null,
				h( 'p', null, timestamp ),
				h( 'p', null, text.noScan )
			);
		}

		var rows = scan.results.map( function ( result, index ) {
			return h( 'tr', { key: index },
				h( 'td', null, result.table ),
				h( 'td', null, result.row_id ),
				h( 'td', null, result.column ),
				h( 'td', null, result.rule ),
				h( 'td', null, h( 'code', null, result.fingerprint ) )
			);
		} );

		return h( 'div', null,
			h( 'p', null, timestamp ),
			scan.truncated ? h( 'p', { className: 'description' }, text.scanTruncated ) : null,
			h( 'table', { className: 'widefat striped' },
				h( 'thead', null, h( 'tr', null,
					h( 'th', null, text.table ),
					h( 'th', null, text.row ),
					h( 'th', null, text.column ),
					h( 'th', null, text.marker ),
					h( 'th', null, text.fingerprint )
				) ),
				h( 'tbody', null, rows )
			),
			h( 'p', { className: 'description' }, text.scanCaution )
		);
	}

	function fileScanResults( scan ) {
		if ( typeof scan === 'undefined' ) {
			scan = config.fileScan;
		}
		if ( ! scan ) {
			return null;
		}
		if ( scan.error ) {
			return h( 'div', { className: 'notice notice-error inline' }, h( 'p', null, scan.error ) );
		}

		var summary = text.fileScanStats
			.replace( '%1$d', scan.core_checked || 0 )
			.replace( '%2$d', scan.core_modified || 0 )
			.replace( '%3$d', scan.core_missing || 0 )
			.replace( '%4$d', scan.php_scanned || 0 )
			.replace( '%5$d', scan.suspicious_php || 0 )
			.replace( '%6$d', scan.executable_uploads || 0 );
		var findings = scan.findings || [];
		var rows = findings.map( function ( finding, index ) {
			return h( 'tr', { key: index },
				h( 'td', null, finding.path ),
				h( 'td', null, finding.type ),
				h( 'td', null, finding.description ),
				h( 'td', null, finding.fingerprint ? h( 'code', null, finding.fingerprint ) : '—' )
			);
		} );

		return h( 'div', null,
			scan.scanned_at ? h( 'p', null, text.scanAt.replace( '%s', scan.scanned_at ) ) : null,
			h( 'p', null, summary ),
			scan.checksum_warning ? h( 'p', { className: 'notice notice-warning inline' }, scan.checksum_warning ) : null,
			scan.truncated || scan.oversized_skipped || scan.unreadable_skipped
				? h( 'p', { className: 'notice notice-warning inline' },
					( scan.truncated ? text.fileScanIncomplete + ' ' : '' ) +
					text.fileScanSkippedFiles
						.replace( '%1$d', scan.oversized_skipped || 0 )
						.replace( '%2$d', scan.unreadable_skipped || 0 )
				)
				: null,
			findings.length ? h( 'table', { className: 'widefat striped' },
				h( 'thead', null, h( 'tr', null,
					h( 'th', null, text.fileScanPath ),
					h( 'th', null, text.fileScanFinding ),
					h( 'th', null, text.fileScanDetails ),
					h( 'th', null, text.fileScanFingerprint )
				) ),
				h( 'tbody', null, rows )
			) : h( 'p', null, text.fileScanNoResults ),
			h( 'p', { className: 'description' }, text.fileScanCaution )
		);
	}

	function scheduledMonitoringPanel() {
		var monitoring = config.fileMonitoring || {};
		var lastScan = monitoring.last_scan;
		return h( 'div', { className: 'slg-monitoring-status' },
			h( 'h3', null, text.fileMonitoringStatus ),
			h( 'p', null, monitoring.enabled ? text.fileMonitoringEnabled : text.fileMonitoringDisabled ),
			monitoring.notice ? h( 'div', { className: 'notice notice-info inline' }, h( 'p', null, monitoring.notice ) ) : null,
			monitoring.next_run ? h( 'p', { className: 'description' }, text.fileMonitoringNext.replace( '%s', monitoring.next_run ) ) : null,
			monitoring.running ? h( 'p', { className: 'notice notice-info inline' },
				text.fileMonitoringRunning + ' ' +
				text.fileMonitoringProgress.replace( '%d', monitoring.progress && monitoring.progress.php_scanned ? monitoring.progress.php_scanned : 0 )
			) : null,
			lastScan && lastScan.scanned_at ? h( 'p', null, text.fileMonitoringLast.replace( '%s', lastScan.scanned_at ) ) : null,
			! lastScan ? h( 'p', { className: 'description' }, text.fileMonitoringNoScan ) : null,
			lastScan && lastScan.baseline_established ? h( 'p', null, text.fileMonitoringBaseline ) : null,
			lastScan && lastScan.new_findings && lastScan.alert_sent ? h( 'p', { className: 'notice notice-warning inline' }, text.fileMonitoringAlert ) : null,
			lastScan && lastScan.new_findings && lastScan.alert_failed ? h( 'p', { className: 'notice notice-error inline' }, text.fileMonitoringAlertFailed ) : null,
			lastScan && lastScan.error ? h( 'p', { className: 'notice notice-error inline' }, text.fileMonitoringError.replace( '%s', lastScan.error ) ) : null,
			actionForm( 'slg_run_file_monitoring', config.urls.runFileMonitoringNonce, text.runFileMonitoring ),
			actionForm( 'slg_reset_file_baseline', config.urls.resetFileBaselineNonce, text.resetFileBaseline ),
			lastScan && ! lastScan.error ? fileScanResults( lastScan ) : null
		);
	}

	function eventsTable() {
		var events = config.firewallEvents;
		if ( events === false ) {
			return h( 'p', null, text.eventsUnavailable );
		}
		if ( ! events || ! events.length ) {
			return h( 'p', null, text.noEvents );
		}
		var rows = events.map( function ( event, index ) {
			return h( 'tr', { key: index },
				h( 'td', null, event.event_time ),
				h( 'td', null, h( 'code', null, event.ip_hash ) ),
				h( 'td', null, event.request_method ),
				h( 'td', null, h( 'code', null, event.request_path ) ),
				h( 'td', null, event.rule_code )
			);
		} );
		return h( 'div', null,
			h( 'table', { className: 'widefat striped' },
				h( 'thead', null, h( 'tr', null,
					h( 'th', null, text.utcTime ),
					h( 'th', null, text.ipFingerprint ),
					h( 'th', null, text.method ),
					h( 'th', null, text.path ),
					h( 'th', null, text.rule )
				) ),
				h( 'tbody', null, rows )
			),
			h( 'p', { className: 'description' }, text.privacyNote )
		);
	}

	function Dashboard() {
		var routeState = element.useState( routeFromHash() );
		var activeRoute = routeState[ 0 ];
		var setActiveRoute = routeState[ 1 ];
		element.useEffect( function () {
			function syncRoute() {
				setActiveRoute( routeFromHash() );
				window.scrollTo( 0, 0 );
			}
			window.addEventListener( 'popstate', syncRoute );
			window.addEventListener( 'hashchange', syncRoute );
			return function () {
				window.removeEventListener( 'popstate', syncRoute );
				window.removeEventListener( 'hashchange', syncRoute );
			};
		}, [] );

		function navigate( event, target ) {
			if ( event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
				return;
			}
			event.preventDefault();
			if ( window.location.hash !== '#' + target ) {
				window.history.pushState( null, '', '#' + target );
				window.scrollTo( 0, 0 );
			}
			setActiveRoute( target );
		}

		var captchaConfigured = Boolean( config.captchaConfigured && settings.captcha_site_key );
		var backupHealthy = Boolean( config.backup && config.backup.status && config.backup.status.success );
		var protectionRows = [
			fieldRow( text.failuresPerLogin, 'slg-failures-per-login', numberInput( 'slg-failures-per-login', 'failures_per_login', 3, 20 ) ),
			fieldRow( text.failuresPerIp, 'slg-failures-per-ip', numberInput( 'slg-failures-per-ip', 'failures_per_ip', 10, 100 ) ),
			fieldRow( text.windowMinutes, 'slg-window-minutes', numberInput( 'slg-window-minutes', 'window_minutes', 5, 1440 ) ),
			fieldRow( text.lockoutMinutes, 'slg-lockout-minutes', numberInput( 'slg-lockout-minutes', 'lockout_minutes', 1, 1440 ) ),
			fieldRow( text.inactivityMinutes, 'slg-inactivity-minutes', numberInput( 'slg-inactivity-minutes', 'inactivity_minutes', 5, 1440 ) ),
			fieldRow( text.passwordLength, 'slg-password-length', h( 'div', null,
				numberInput( 'slg-password-length', 'minimum_password_length', 10, 64 ),
				h( 'p', { className: 'description' }, text.passwordDescription )
			) ),
			h( 'tr', { key: 'firewall' },
				h( 'th', { scope: 'row' }, text.requestFirewall ),
				h( 'td', null, h( 'label', null,
					h( 'input', {
						type: 'checkbox',
						name: settingsName + '[firewall_enabled]',
						value: '1',
						defaultChecked: Boolean( Number( settings.firewall_enabled ) )
					} ),
					' ' + text.firewallDescription
				) )
			),
			fieldRow( text.siteKey, 'slg-turnstile-site-key', h( 'input', {
				id: 'slg-turnstile-site-key',
				type: 'text',
				name: settingsName + '[captcha_site_key]',
				defaultValue: settings.captcha_site_key,
				className: 'regular-text',
				autoComplete: 'off'
			} ) ),
			fieldRow( text.secretKey, 'slg-turnstile-secret-key', h( 'input', {
				id: 'slg-turnstile-secret-key',
				type: 'password',
				name: settingsName + '[captcha_secret_key]',
				defaultValue: '',
				className: 'regular-text',
				autoComplete: 'new-password',
				placeholder: config.captchaConfigured ? text.configuredKeepKey : text.notConfigured
			} ) ),
			fieldRow( text.backupRetention, 'slg-backup-retention', h( 'div', null,
				numberInput( 'slg-backup-retention', 'backup_retention', 1, 30 ),
				h( 'p', { className: 'description' }, text.retentionDescription )
			) ),
			fieldRow( text.backupDirectory, 'slg-backup-directory', h( 'div', null,
				h( 'input', {
					id: 'slg-backup-directory',
					type: 'text',
					name: settingsName + '[backup_directory]',
					defaultValue: settings.backup_directory,
					className: 'regular-text',
					autoComplete: 'off',
					placeholder: text.backupDirectoryPlaceholder
				} ),
				h( 'p', { className: 'description' }, text.backupDirectoryDescription )
			) ),
			h( 'tr', { key: 'file-monitoring' },
				h( 'th', { scope: 'row' }, text.fileMonitoring ),
				h( 'td', null, h( 'label', null,
					h( 'input', {
						type: 'checkbox',
						name: settingsName + '[file_monitoring_enabled]',
						value: '1',
						defaultChecked: Boolean( Number( settings.file_monitoring_enabled ) )
					} ),
					' ' + text.fileMonitoringDescription
				) )
			),
			h( 'tr', { key: 'login-notifications' },
				h( 'th', { scope: 'row' }, text.loginNotifications ),
				h( 'td', null, h( 'label', null,
					h( 'input', {
						type: 'checkbox',
						name: settingsName + '[login_notifications_enabled]',
						value: '1',
						defaultChecked: Boolean( Number( settings.login_notifications_enabled ) )
					} ),
					' ' + text.loginNotificationsDescription
				) )
			),
		];

		var settingForm = h( 'form', { action: config.urls.options, method: 'post' },
			hiddenField( 'option_page', 'secure_login_guard' ),
			hiddenField( 'action', 'update' ),
			hiddenField( '_wpnonce', config.urls.settingsNonce ),
			formTable( protectionRows ),
			h( 'p', { className: 'submit' },
				h( 'button', { type: 'submit', className: 'button button-primary' }, text.saveSettings )
			)
		);

		var pages = {
			'slg-protection': h( 'section', { className: 'slg-panel', id: 'slg-protection' },
				panelHeading( text.eyebrowProtection, text.protection, text.protectionDescription ),
				settingForm,
				h( 'p', { className: 'description' }, text.ipNote )
			),
			'slg-two-factor': h( 'section', { className: 'slg-panel', id: 'slg-two-factor' },
				panelHeading( text.eyebrowAccount, text.twoFactor, null, text.perUser ),
				h( 'p', null, text.twoFactorDescription ),
				h( 'p', null, text.smsNote ),
				h( 'h3', null, text.accountSessionsDescription ),
				h( 'p', null, h( 'a', { className: 'button', href: config.urls.profileUrl }, text.openProfileSessions ) )
			),
			'slg-backups': backupPanel(),
			'slg-audit': h( 'section', { className: 'slg-panel', id: 'slg-audit' },
				panelHeading( text.eyebrowHealth, text.securityChecks, null, text.reportOnly ),
				h( 'p', null, text.checksDescription ),
				checksTable(),
				scheduledMonitoringPanel(),
				h( 'h3', null, text.storedContentScan ),
				h( 'p', null, text.scanDescription ),
				actionForm( 'slg_scan_database', config.urls.scanNonce, text.scanButton ),
				scanResults(),
				h( 'h3', null, text.fileScan ),
				h( 'p', null, text.fileScanDescription ),
				actionForm( 'slg_scan_files', config.urls.scanFilesNonce, text.fileScanButton ),
				fileScanResults()
			),
			'slg-events': h( 'section', { className: 'slg-panel', id: 'slg-events' },
				panelHeading( text.eyebrowFirewall, text.firewallEvents, null, text.recentActivity ),
				eventsTable()
			)
		};

		return h( 'div', null,
			h( 'header', { className: 'slg-header' },
				h( 'div', null,
					h( 'p', { className: 'slg-eyebrow' }, text.eyebrowSite ),
					h( 'h1', null, text.brand ),
					h( 'p', null, text.pageDescription )
				),
				h( 'span', { className: 'slg-version' }, 'MVP 0.4.3' )
			),
			h( 'div', { className: 'slg-status-grid', 'aria-label': 'Security status overview' },
				statusCard( text.requestFirewall, Number( settings.firewall_enabled ) ? text.active : text.disabled, 'slg-protection', 'S', 'slg-icon-shield', Number( settings.firewall_enabled ) ? 'is-good' : 'is-muted', navigate ),
				statusCard( text.captcha, captchaConfigured ? text.configured : text.setupRecommended, 'slg-protection', 'C', 'slg-icon-captcha', captchaConfigured ? 'is-good' : 'is-warning', navigate ),
				statusCard( text.backupCard, backupHealthy ? text.backupHealthy : text.backupAttention, 'slg-backups', 'B', 'slg-icon-backup', backupHealthy ? 'is-good' : 'is-warning', navigate ),
				statusCard( text.twoFactorCard, text.userManaged, 'slg-two-factor', '2F', 'slg-icon-2fa', 'is-info', navigate )
			),
			h( 'nav', { className: 'slg-nav', 'aria-label': text.sections },
				h( 'a', { href: '#slg-protection', className: activeRoute === 'slg-protection' ? 'is-active' : '', 'aria-current': activeRoute === 'slg-protection' ? 'page' : null, onClick: function ( event ) { navigate( event, 'slg-protection' ); } }, text.protectionNav ),
				h( 'a', { href: '#slg-two-factor', className: activeRoute === 'slg-two-factor' ? 'is-active' : '', 'aria-current': activeRoute === 'slg-two-factor' ? 'page' : null, onClick: function ( event ) { navigate( event, 'slg-two-factor' ); } }, text.twoFactorNav ),
				h( 'a', { href: '#slg-backups', className: activeRoute === 'slg-backups' ? 'is-active' : '', 'aria-current': activeRoute === 'slg-backups' ? 'page' : null, onClick: function ( event ) { navigate( event, 'slg-backups' ); } }, text.backupsNav ),
				h( 'a', { href: '#slg-audit', className: activeRoute === 'slg-audit' ? 'is-active' : '', 'aria-current': activeRoute === 'slg-audit' ? 'page' : null, onClick: function ( event ) { navigate( event, 'slg-audit' ); } }, text.checksNav ),
				h( 'a', { href: '#slg-events', className: activeRoute === 'slg-events' ? 'is-active' : '', 'aria-current': activeRoute === 'slg-events' ? 'page' : null, onClick: function ( event ) { navigate( event, 'slg-events' ); } }, text.eventsNav )
			),
			pages[ activeRoute ] || pages[ 'slg-protection' ]
		);
	}

	element.render( h( Dashboard ), document.getElementById( 'slg-dashboard-root' ) );
} )();
