( function () {
	'use strict';

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		var button = target && target.closest
			? target.closest( '[data-slg-profile-field][data-slg-profile-value]' )
			: null;
		if ( ! button ) {
			return;
		}

		var form = button.closest( 'form' );
		var submitButton = form && form.querySelector( '#submit, #wp-submit' );
		if ( ! form || ! submitButton ) {
			return;
		}

		event.preventDefault();
		var fieldName = button.getAttribute( 'data-slg-profile-field' );
		var fieldValue = button.getAttribute( 'data-slg-profile-value' );
		var field = form.querySelector( 'input[name="' + fieldName + '"]' );
		if ( ! field ) {
			field = document.createElement( 'input' );
			field.type = 'hidden';
			field.name = fieldName;
			form.appendChild( field );
		}
		field.value = fieldValue;
		submitButton.click();
	} );
} )();
