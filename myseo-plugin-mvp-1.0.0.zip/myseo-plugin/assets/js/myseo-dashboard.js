(function (wp) {
    'use strict';

    if (!wp || !wp.element || !wp.apiFetch) return;

    var el = wp.element.createElement;
    var useState = wp.element.useState;
    var useEffect = wp.element.useEffect;
    var apiFetch = wp.apiFetch;
    var config = window.myseoDashboardConfig || {};
    apiFetch.use(apiFetch.createNonceMiddleware(config.nonce));

    function Icon(props) {
        return el('span', { className: 'dashicons ' + (props.name || '') + ' myseo-icon', 'aria-hidden': 'true' });
    }

    var navItems = [
        { id: 'overview', label: 'Overview', icon: 'dashicons-dashboard' },
        { id: 'content', label: 'Content Audit', icon: 'dashicons-media-document' },
        { id: 'images', label: 'Image Audit', icon: 'dashicons-format-image' },
        { id: 'technical', label: 'Technical SEO', icon: 'dashicons-admin-tools' },
        { id: 'health', label: 'Content Health', icon: 'dashicons-clock' },
        { id: 'performance', label: 'SEO Performance', icon: 'dashicons-chart-area' },
        { id: 'settings', label: 'Settings', icon: 'dashicons-admin-settings' }
    ];

    function MetricCard(props) {
        return el('div', { className: 'myseo-metric-card' },
            el('div', { className: 'myseo-metric-top' },
                el('span', { className: 'myseo-metric-label' }, props.label),
                el(Icon, { name: props.icon })
            ),
            el('div', { className: 'myseo-metric-value' }, props.value),
            el('p', { className: 'myseo-metric-help' }, props.help)
        );
    }

    function Notice(props) {
        return el('div', { className: 'myseo-notice ' + (props.type || 'info'), role: 'status' },
            el('strong', null, props.title),
            el('p', null, props.children)
        );
    }

    function Overview(props) {
        var data = props.data || {};
        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'SEO overview'),
                    el('p', null, 'A quick view of your WordPress SEO setup and content metadata.')
                ),
                el('span', { className: 'myseo-version-pill' }, 'MySEO v' + (data.version || config.version || '0.9.0'))
            ),
            data.schema_plugin_conflict ? el(Notice, {
                type: 'warning',
                title: 'Another SEO plugin is active',
                children: 'MySEO detects a supported SEO plugin. MySEO schema output is suppressed to reduce duplicate structured data.'
            }) : null,
            el('div', { className: 'myseo-metric-grid' },
                el(MetricCard, { label: 'Published content', value: number(data.published_content), icon: 'dashicons-admin-page', help: number(data.published_posts) + ' posts · ' + number(data.published_pages) + ' pages' }),
                el(MetricCard, { label: 'SEO titles configured', value: number(data.seo_titles_configured), icon: 'dashicons-editor-textcolor', help: 'Published content with a custom SEO title' }),
                el(MetricCard, { label: 'Meta descriptions configured', value: number(data.meta_descriptions_configured), icon: 'dashicons-text', help: 'Published content with a custom description' }),
                el(MetricCard, { label: 'Schema output', value: data.schema_output_enabled ? 'Enabled' : 'Disabled', icon: 'dashicons-code-standards', help: data.schema_plugin_conflict ? 'Suppressed while another SEO plugin is active' : 'Article and WebPage JSON-LD setting' })
            ),
            el('div', { className: 'myseo-content-grid' },
                el('section', { className: 'myseo-panel' },
                    el('div', { className: 'myseo-panel-heading' }, el('h2', null, 'SEO setup'), el('span', { className: 'myseo-status-dot' })),
                    el('div', { className: 'myseo-setting-row' },
                        el('span', null, 'Meta description output'),
                        el('strong', { className: data.meta_output_enabled ? 'myseo-state-on' : 'myseo-state-off' }, data.meta_output_enabled ? 'Enabled' : 'Disabled')
                    ),
                    el('div', { className: 'myseo-setting-row' },
                        el('span', null, 'Structured data output'),
                        el('strong', { className: data.schema_output_enabled ? 'myseo-state-on' : 'myseo-state-off' }, data.schema_output_enabled ? 'Enabled' : 'Disabled')
                    ),
                    el('button', { className: 'button button-primary', onClick: props.openSettings }, 'Manage settings')
                ),
                el('section', { className: 'myseo-panel' },
                    el('h2', null, 'Continue improving your site'),
                    el('p', null, 'Use the post editor for live keyphrase, readability, heading and image checks. Site-wide audits are planned for upcoming releases.'),
                    el('a', { className: 'button', href: config.adminUrl + 'edit.php' }, 'View posts'),
                    el('a', { className: 'button myseo-button-gap', href: config.adminUrl + 'edit.php?post_type=page' }, 'View pages')
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Dashboard counts are based on published WordPress content and saved MySEO metadata. This is not an SEO score or a Google ranking report.')
        );
    }

    function ContentAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedSearchState = useState('');
        var appliedSearch = appliedSearchState[0], setAppliedSearch = appliedSearchState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            var path = '/myseo/v1/content-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '');
            apiFetch({ path: path }).then(function (data) {
                setResult(data);
                setPage(nextPage);
            }).catch(function (err) {
                setError(err && err.message ? err.message : 'Unable to load content audit.');
            }).finally(function () { setLoading(false); });
        }

        useEffect(function () { load(1, ''); }, []);

        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var labels = {
            missing_seo_title: 'Missing SEO title',
            missing_meta_description: 'Missing meta description',
            missing_focus_keyphrase: 'Missing focus keyphrase',
            duplicate_seo_title: 'Duplicate SEO title',
            duplicate_meta_description: 'Duplicate meta description'
        };

        function issueBadges(issues) {
            if (!issues || !issues.length) {
                return el('span', { className: 'myseo-audit-clean' }, 'No field issues');
            }
            return el('div', { className: 'myseo-audit-issue-list' }, issues.map(function (issue) {
                return el('span', { key: issue, className: 'myseo-audit-issue' }, labels[issue] || issue);
            }));
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Content audit'),
                    el('p', null, 'Review saved MySEO metadata across published public content.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, appliedSearch); } }, 'Refresh audit')
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Published content', value: number(summary.total_content), icon: 'dashicons-admin-page', help: 'All published public post types' }),
                el(MetricCard, { label: 'Missing SEO titles', value: number(summary.missing_seo_title), icon: 'dashicons-editor-textcolor', help: 'No custom MySEO title saved' }),
                el(MetricCard, { label: 'Missing descriptions', value: number(summary.missing_meta_description), icon: 'dashicons-text', help: 'No custom MySEO description saved' }),
                el(MetricCard, { label: 'Missing keyphrases', value: number(summary.missing_focus_keyphrase), icon: 'dashicons-tag', help: 'No focus keyphrase saved' })
            ),
            el('div', { className: 'myseo-audit-secondary-summary' },
                el('span', null, 'Duplicate SEO title groups: ', el('strong', null, number(summary.duplicate_seo_title_groups))),
                el('span', null, 'Duplicate description groups: ', el('strong', null, number(summary.duplicate_meta_description_groups))),
                el('span', null, 'Content missing one or more custom fields: ', el('strong', null, number(summary.content_with_issues)))
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null, el('h2', null, 'Published content'), el('p', null, 'Search by post or page title. Select Edit to update its SEO fields.')),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) { event.preventDefault(); setAppliedSearch(search); load(1, search); } },
                        el('input', { type: 'search', value: search, placeholder: 'Search content…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Scanning published content…')) :
                    result && result.items && result.items.length
                        ? el('div', { className: 'myseo-audit-table-wrap' },
                            el('table', { className: 'myseo-audit-table' },
                                el('thead', null, el('tr', null,
                                    el('th', null, 'Content'),
                                    el('th', null, 'Type'),
                                    el('th', null, 'Issues'),
                                    el('th', null, 'Action')
                                )),
                                el('tbody', null, result.items.map(function (item) {
                                    return el('tr', { key: item.id },
                                        el('td', null,
                                            el('strong', null, item.title || '(Untitled)'),
                                            el('small', null, 'ID: ' + item.id)
                                        ),
                                        el('td', null, item.post_type),
                                        el('td', null, issueBadges(item.issues)),
                                        el('td', null, item.edit_url ? el('a', { className: 'button button-small', href: item.edit_url }, 'Edit') : '—')
                                    );
                                }))
                            )
                        )
                        : el('p', { className: 'myseo-empty-state' }, 'No published content matched this search.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Page ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1) + ' · ' + number(pagination.total_items) + ' matching items'),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, appliedSearch); } }, 'Previous'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, appliedSearch); } }, 'Next')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'This audit checks whether custom MySEO fields are saved. WordPress may still output a fallback document title and excerpt-based description when these fields are blank. Duplicate counts refer to groups of identical non-empty custom values. The audit does not measure Google rankings.')
        );
    }


    function ImageAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedState = useState('');
        var applied = appliedState[0], setApplied = appliedState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            apiFetch({ path: '/myseo/v1/image-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '') })
                .then(function (data) { setResult(data); setPage(nextPage); })
                .catch(function (err) { setError(err && err.message ? err.message : 'Unable to load image audit.'); })
                .finally(function () { setLoading(false); });
        }
        useEffect(function () { load(1, ''); }, []);

        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var items = result && result.items ? result.items : [];

        function statusLabel(status) {
            if (status === 'missing') return el('span', { className: 'myseo-audit-issue' }, 'Missing alt');
            if (status === 'empty') return el('span', { className: 'myseo-image-review' }, 'Empty alt · review');
            return el('span', { className: 'myseo-audit-clean' }, 'Alt text set');
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Site-wide image audit'),
                    el('p', null, 'Review image alt attributes in published content. Each page of results scans a batch of published posts.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, applied); }, disabled: loading }, 'Refresh audit')
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Image occurrences', value: number(summary.image_occurrences), icon: 'dashicons-format-image', help: 'Images found in this post batch' }),
                el(MetricCard, { label: 'Missing alt', value: number(summary.missing_alt), icon: 'dashicons-warning', help: 'Alt attribute is not present' }),
                el(MetricCard, { label: 'Empty alt', value: number(summary.empty_alt), icon: 'dashicons-visibility', help: 'May be decorative; review in context' }),
                el(MetricCard, { label: 'Alt text set', value: number(summary.with_alt), icon: 'dashicons-yes-alt', help: 'Non-empty alt attribute found' })
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Image usage in published content'),
                        el('p', null, number(summary.posts_in_batch) + ' posts scanned in this batch · ' +
                            number(summary.posts_with_images) + ' posts contain images · ' +
                            number(pagination.total_posts) + ' published posts match')
                    ),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) {
                        event.preventDefault(); setApplied(search); load(1, search);
                    } },
                        el('input', { type: 'search', value: search, placeholder: 'Search posts…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Scanning this batch…')) :
                    items.length ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table myseo-image-audit-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Image'),
                                el('th', null, 'Alt status'),
                                el('th', null, 'Alt text'),
                                el('th', null, 'Content'),
                                el('th', null, 'Actions')
                            )),
                            el('tbody', null, items.map(function (item) {
                                return el('tr', { key: item.key },
                                    el('td', null,
                                        el('strong', null, item.filename || '(Unknown file)'),
                                        item.src ? el('small', null, item.src) : null
                                    ),
                                    el('td', null, statusLabel(item.status)),
                                    el('td', null, item.alt || (item.status === 'empty' ? '(empty)' : '—')),
                                    el('td', null,
                                        el('strong', null, item.post_title),
                                        el('small', null, item.post_type + ' · ID: ' + item.post_id)
                                    ),
                                    el('td', null,
                                        item.post_edit_url ? el('a', { className: 'button button-small', href: item.post_edit_url }, 'Edit content') : null,
                                        item.attachment_edit_url ? el('a', { className: 'button button-small myseo-button-gap', href: item.attachment_edit_url }, 'Media file') : null
                                    )
                                );
                            }))
                        )
                    ) : el('p', { className: 'myseo-empty-state' }, 'No images found in this batch of published content.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Post batch ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1)),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, applied); } }, 'Previous batch'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, applied); } }, 'Next batch')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Scope: images found in saved post content (including Gutenberg block markup) for published public post types. Theme-generated images, shortcode output, CSS background images, and dynamically rendered content are not scanned. Missing alt means the attribute is absent; alt="" is shown for review because it can be correct for decorative images. Summary metrics apply only to the currently displayed batch. Search filters posts by WordPress title/content search.')
        );
    }


    function TechnicalAudit() {
        var resultState = useState(null);
        var result = resultState[0], setResult = resultState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var pageState = useState(1);
        var page = pageState[0], setPage = pageState[1];
        var searchState = useState('');
        var search = searchState[0], setSearch = searchState[1];
        var appliedState = useState('');
        var applied = appliedState[0], setApplied = appliedState[1];

        function load(nextPage, term) {
            setLoading(true);
            setError('');
            apiFetch({ path: '/myseo/v1/technical-audit?page=' + encodeURIComponent(nextPage) +
                '&per_page=20&search=' + encodeURIComponent(term || '') })
                .then(function (data) { setResult(data); setPage(nextPage); })
                .catch(function (err) { setError(err && err.message ? err.message : 'Unable to load technical audit.'); })
                .finally(function () { setLoading(false); });
        }
        useEffect(function () { load(1, ''); }, []);

        var checks = result && result.site_checks ? result.site_checks : [];
        var summary = result && result.summary ? result.summary : {};
        var pagination = result && result.pagination ? result.pagination : {};
        var items = result && result.items ? result.items : [];

        function checkCard(check) {
            var statusText = check.status === 'good' ? 'Looks good' : (check.status === 'issue' ? 'Action needed' : 'Review');
            return el('div', { className: 'myseo-technical-check', key: check.id },
                el('div', { className: 'myseo-technical-check-top' },
                    el('strong', null, check.label),
                    el('span', { className: 'myseo-technical-status ' + check.status }, statusText)
                ),
                el('p', null, check.detail),
                check.url ? el('a', { href: check.url, target: '_blank', rel: 'noopener noreferrer' }, check.id === 'sitemap' ? 'Open sitemap' : (check.id === 'visibility' ? 'Reading settings' : 'Open site')) : null
            );
        }

        return el('div', { className: 'myseo-page-content' },
            el('div', { className: 'myseo-welcome-row' },
                el('div', null,
                    el('h1', null, 'Technical SEO audit'),
                    el('p', null, 'Review important WordPress SEO configuration and internal links in published content.')
                ),
                el('button', { className: 'button', onClick: function () { load(page, applied); }, disabled: loading }, 'Refresh audit')
            ),
            el('section', { className: 'myseo-panel myseo-technical-site-panel' },
                el('h2', null, 'Site configuration checks'),
                el('div', { className: 'myseo-technical-check-grid' }, checks.map(checkCard))
            ),
            el('div', { className: 'myseo-audit-summary-grid' },
                el(MetricCard, { label: 'Internal links', value: number(summary.internal_link_occurrences), icon: 'dashicons-admin-links', help: 'Internal link occurrences in this post batch' }),
                el(MetricCard, { label: 'Mixed-content links', value: number(summary.mixed_content_links), icon: 'dashicons-warning', help: 'HTTP links found on an HTTPS site' }),
                el(MetricCard, { label: 'Unresolved links', value: number(summary.unresolved_internal_links), icon: 'dashicons-search', help: 'Could not map to a WordPress post; review required' }),
                el(MetricCard, { label: 'Posts scanned', value: number(summary.posts_in_batch), icon: 'dashicons-media-document', help: number(pagination.total_posts) + ' published posts match' })
            ),
            el('section', { className: 'myseo-panel myseo-audit-panel' },
                el('div', { className: 'myseo-audit-toolbar' },
                    el('div', null,
                        el('h2', null, 'Internal link review'),
                        el('p', null, number(summary.posts_with_internal_links) + ' posts in this batch contain internal links.')
                    ),
                    el('form', { className: 'myseo-audit-search', onSubmit: function (event) {
                        event.preventDefault(); setApplied(search); load(1, search);
                    } },
                        el('input', { type: 'search', value: search, placeholder: 'Search posts…', onChange: function (event) { setSearch(event.target.value); } }),
                        el('button', { type: 'submit', className: 'button button-primary' }, 'Search')
                    )
                ),
                error ? el(Notice, { type: 'error', title: 'Audit error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('span', null, 'Checking published content…')) :
                    items.length ? el('div', { className: 'myseo-audit-table-wrap' },
                        el('table', { className: 'myseo-audit-table myseo-technical-table' },
                            el('thead', null, el('tr', null,
                                el('th', null, 'Internal URL'),
                                el('th', null, 'Finding'),
                                el('th', null, 'Source content'),
                                el('th', null, 'Action')
                            )),
                            el('tbody', null, items.map(function (item) {
                                var finding = item.mixed_content ? 'HTTP link on HTTPS site' :
                                    (item.unresolved ? 'Target not mapped · review' : 'Internal link');
                                return el('tr', { key: item.key },
                                    el('td', null, el('a', { href: item.href, target: '_blank', rel: 'noopener noreferrer' }, item.href)),
                                    el('td', null, item.mixed_content ? el('span', { className: 'myseo-audit-issue' }, finding) :
                                        (item.unresolved ? el('span', { className: 'myseo-image-review' }, finding) : el('span', { className: 'myseo-audit-clean' }, finding))),
                                    el('td', null, el('strong', null, item.post_title), el('small', null, item.post_type + ' · ID: ' + item.post_id)),
                                    el('td', null, item.post_edit_url ? el('a', { className: 'button button-small', href: item.post_edit_url }, 'Edit content') : '—')
                                );
                            }))
                        )
                    ) : el('p', { className: 'myseo-empty-state' }, 'No internal links were found in this post batch.'),
                el('div', { className: 'myseo-audit-pagination' },
                    el('span', null, 'Post batch ' + number(pagination.page || 1) + ' of ' + number(pagination.total_pages || 1)),
                    el('div', null,
                        el('button', { className: 'button', disabled: loading || page <= 1, onClick: function () { load(page - 1, applied); } }, 'Previous batch'),
                        el('button', { className: 'button', disabled: loading || page >= (pagination.total_pages || 1), onClick: function () { load(page + 1, applied); } }, 'Next batch')
                    )
                )
            ),
            el('p', { className: 'myseo-footnote' }, 'Important: unresolved internal URLs are review candidates, not confirmed broken links. WordPress cannot map archive pages, custom routes, some multilingual URLs, or external rewrite rules to a post ID. This scan examines saved post content only and does not crawl rendered pages or send HTTP requests to every link. Counts apply to the current post batch.')
        );
    }

    function Placeholder(props) {
        var copy = {
            content: ['Content audit', 'A site-wide content audit is planned next. For now, use the MySEO panel inside each post or page to review its title, description, keyphrase, readability and headings.'],
            images: ['Image audit', 'Site-wide image usage audit is available.'],
            technical: ['Technical SEO', 'Technical SEO audit is available.'],
            health: ['Content health', 'Content freshness and content-decay monitoring are planned for a future release.'],
            performance: ['SEO performance', 'Google Search Console integration is not connected yet. Search clicks, impressions and query data will appear here after that integration is built.']
        }[props.section];
        return el('div', { className: 'myseo-page-content' },
            el('h1', null, copy[0]),
            el(Notice, { title: 'Coming in a future release', children: copy[1] }),
            el('p', { className: 'myseo-footnote' }, 'We are keeping this section visible so the dashboard navigation and planned modules are clear. It does not currently run a site-wide scan.')
        );
    }

    function Settings(props) {
        var settings = props.settings;
        var setSettings = props.setSettings;
        var saving = props.saving;
        var saveMessage = props.saveMessage;
        function toggle(key) {
            var next = Object.assign({}, settings);
            next[key] = !next[key];
            setSettings(next);
        }
        return el('div', { className: 'myseo-page-content' },
            el('h1', null, 'Settings'),
            el('p', { className: 'myseo-page-intro' }, 'Control which MySEO metadata and structured data outputs are added to your public pages.'),
            el('section', { className: 'myseo-panel myseo-settings-panel' },
                el('div', { className: 'myseo-toggle-row' },
                    el('div', null, el('h3', null, 'Meta description output'), el('p', null, 'Print the MySEO meta description on singular pages when one is saved, with an excerpt fallback.')),
                    el('label', { className: 'myseo-switch' },
                        el('input', { type: 'checkbox', checked: !!settings.enable_meta_output, onChange: function () { toggle('enable_meta_output'); } }),
                        el('span', { className: 'myseo-switch-slider' })
                    )
                ),
                el('div', { className: 'myseo-toggle-row' },
                    el('div', null, el('h3', null, 'Structured data (JSON-LD)'), el('p', null, 'Generate basic BlogPosting schema for posts and WebPage schema for other singular content.')),
                    el('label', { className: 'myseo-switch' },
                        el('input', { type: 'checkbox', checked: !!settings.enable_schema_output, onChange: function () { toggle('enable_schema_output'); } }),
                        el('span', { className: 'myseo-switch-slider' })
                    )
                ),
                el('div', { className: 'myseo-settings-actions' },
                    el('button', { className: 'button button-primary', disabled: saving, onClick: props.save }, saving ? 'Saving…' : 'Save settings'),
                    saveMessage ? el('span', { className: 'myseo-save-message', role: 'status' }, saveMessage) : null
                )
            ),
            el(Notice, { title: 'Compatibility note', children: 'If another SEO plugin is active, review its metadata and schema settings to avoid duplicate output. MySEO currently suppresses its schema when selected supported SEO plugins are detected.' })
        );
    }

    function number(value) {
        return Number(value || 0).toLocaleString();
    }

    function App() {
        var activeState = useState('overview');
        var active = activeState[0], setActive = activeState[1];
        var dataState = useState(null);
        var data = dataState[0], setData = dataState[1];
        var settingsState = useState({ enable_meta_output: true, enable_schema_output: true });
        var settings = settingsState[0], setSettings = settingsState[1];
        var loadingState = useState(true);
        var loading = loadingState[0], setLoading = loadingState[1];
        var savingState = useState(false);
        var saving = savingState[0], setSaving = savingState[1];
        var errorState = useState('');
        var error = errorState[0], setError = errorState[1];
        var messageState = useState('');
        var message = messageState[0], setMessage = messageState[1];

        function refresh() {
            setLoading(true);
            Promise.all([
                apiFetch({ path: '/myseo/v1/dashboard' }),
                apiFetch({ path: '/myseo/v1/settings' })
            ]).then(function (results) {
                setData(results[0]);
                setSettings(results[1]);
                setError('');
            }).catch(function (err) {
                setError(err && err.message ? err.message : 'Could not load dashboard data.');
            }).finally(function () { setLoading(false); });
        }

        useEffect(function () { refresh(); }, []);

        function saveSettings() {
            setSaving(true);
            setMessage('');
            apiFetch({
                path: '/myseo/v1/settings',
                method: 'POST',
                data: settings
            }).then(function (result) {
                setSettings({
                    enable_meta_output: result.enable_meta_output,
                    enable_schema_output: result.enable_schema_output
                });
                setMessage('Settings saved successfully.');
                refresh();
            }).catch(function (err) {
                setMessage(err && err.message ? err.message : 'Unable to save settings.');
            }).finally(function () { setSaving(false); });
        }

        var page = active === 'overview'
            ? el(Overview, { data: data || {}, openSettings: function () { setActive('settings'); } })
            : active === 'settings'
                ? el(Settings, { settings: settings, setSettings: setSettings, saving: saving, saveMessage: message, save: saveSettings })
                : active === 'content'
                    ? el(ContentAudit)
                    : active === 'images'
                        ? el(ImageAudit)
                        : active === 'technical'
                            ? el(TechnicalAudit)
                            : el(Placeholder, { section: active });

        return el('div', { className: 'myseo-app' },
            el('aside', { className: 'myseo-sidebar' },
                el('div', { className: 'myseo-brand' },
                    el('span', { className: 'myseo-brand-mark' }, 'M'),
                    el('div', null, el('strong', null, 'MySEO'), el('small', null, 'Website optimization'))
                ),
                el('nav', { className: 'myseo-navigation', 'aria-label': 'MySEO navigation' },
                    navItems.map(function (item) {
                        return el('button', {
                            key: item.id,
                            type: 'button',
                            className: 'myseo-nav-item' + (active === item.id ? ' active' : ''),
                            onClick: function () { setActive(item.id); setMessage(''); }
                        }, el(Icon, { name: item.icon }), el('span', null, item.label));
                    })
                ),
                el('div', { className: 'myseo-sidebar-footer' }, 'MySEO ' + (config.version || '0.9.0'))
            ),
            el('main', { className: 'myseo-main' },
                el('div', { className: 'myseo-topbar' },
                    el('span', null, 'WordPress SEO workspace'),
                    el('button', { type: 'button', className: 'button', onClick: refresh }, 'Refresh data')
                ),
                error ? el(Notice, { type: 'error', title: 'Dashboard error', children: error }) : null,
                loading ? el('div', { className: 'myseo-loading' }, el('span', { className: 'spinner is-active' }), el('p', null, 'Loading dashboard…')) : page
            )
        );
    }

    var root = document.getElementById('myseo-dashboard-root');
    if (root) {
        if (wp.element.createRoot) {
            wp.element.createRoot(root).render(el(App));
        } else {
            wp.element.render(el(App), root);
        }
    }
})(window.wp);
