# MySEO MVP – development notes

## Current starter scope
- WordPress plugin bootstrap and activation.
- OOP classes with a small, explicit initialization flow.
- Post editor fields for SEO title, meta description, and one focus keyphrase.
- REST exposure for registered post metadata.
- Live editor-side focus keyphrase checks for title, description, slug, introduction, headings, and article body.
- PHP readability analyzer service and live editor-side readability recommendations.
- PHP heading structure analyzer and live editor-side heading outline/issues.
- PHP image analyzer and live editor-side image alt audit, including attachment edit links when the image ID is available.
- JSON-LD schema manager for BlogPosting/WebPage, using post metadata, dates, author, featured image, site name, and optional site logo.
- Schema output toggle and conservative duplicate avoidance for common SEO plugins.
- Frontend title filtering and meta description output.
- React-powered admin dashboard using the WordPress wp.element runtime (no separate build toolchain).
- Capability-protected REST endpoints for dashboard metrics and MySEO settings.
- Dashboard navigation with clearly marked roadmap placeholders for future site-wide audit modules.
- Paginated site-wide Content Audit with summary counts for missing custom MySEO metadata and duplicate custom SEO title/description groups.

## Local setup
1. Copy `myseo-plugin` into `wp-content/plugins/`.
2. Activate it in WordPress.
3. Edit a post/page and use the MySEO meta box.
4. View the published page source to inspect the title and description.

## Important next steps
1. Add automated tests for REST permissions, dashboard metrics, and settings persistence.
2. Add compatibility arbitration so MySEO does not duplicate output from another SEO plugin.
3. Add Gutenberg sidebar integration.
4. Add automated tests for keyphrase, readability, heading, and image analysis.
5. Expand schema coverage only after testing the current Article/WebPage output and duplicate-schema safeguards.
6. Add nonce/capability-protected REST endpoints for analysis.

## Design notes
- Uses WordPress post meta and options; no custom tables in this MVP foundation.
- Does not delete SEO metadata on uninstall.
- Does not call external services.
- The focus keyphrase is stored but is not yet analyzed.
- Structured data generation is not yet implemented.


## Image analysis notes
- Missing `alt` attributes are flagged as issues.
- Empty `alt=""` values are shown for review, not automatically treated as errors; they are appropriate for decorative images.
- The editor-side scan reads image tags in the post content. Theme-generated images, shortcode output, and some dynamic block output are not covered.
- Media Library edit links are shown only when a WordPress attachment ID can be identified from the image class or `data-id`.


## Structured data notes
- Standard WordPress posts emit `BlogPosting`; other singular published content emits `WebPage`.
- Uses SEO title/description metadata when available, with WordPress title/excerpt fallbacks.
- Includes publication/modification dates, language, page URL, post author (for posts), featured image, and site publisher/logo where available.
- Output is controlled by the **Structured data (JSON-LD)** setting on the MySEO dashboard.
- MySEO skips its schema output when Yoast SEO, Rank Math, All in One SEO, SEOPress, or Slim SEO is active. This is a conservative safeguard, not a universal schema-conflict detector.
- Developers can customize the schema array with the `myseo_schema_data` filter.
- Validate output on a staging site with Google's Rich Results Test and Schema.org Validator. Structured data does not guarantee rich-result display or improved rankings.


## Dashboard UI (v0.7.0)
- Admin page is mounted into `#myseo-dashboard-root` and rendered with WordPress `wp.element`.
- Dashboard JavaScript and CSS are enqueued only on the MySEO admin screen.
- REST endpoints: `GET /wp-json/myseo/v1/dashboard`, `GET /wp-json/myseo/v1/settings`, and `POST /wp-json/myseo/v1/settings`.
- Endpoints require the `manage_options` capability; the dashboard uses the WordPress REST nonce middleware.
- Overview metrics show published post/page counts and counts of published content with saved MySEO title/description metadata.
- Settings are persisted in the existing `myseo_settings` option.
- Audit/performance navigation items are visual placeholders and do not claim to run scans or provide Search Console data yet.


## Content Audit (v0.8.0)
- REST endpoint: `GET /wp-json/myseo/v1/content-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; query arguments are sanitized and page size is capped at 50.
- Audits published public post types, with paginated content rows and global summary counts.
- Checks missing saved MySEO SEO title, meta description, and focus keyphrase values, plus duplicate non-empty custom SEO titles and descriptions.
- The audit reports missing *custom MySEO fields*. The frontend may still output WordPress title/excerpt fallbacks; blank custom fields do not necessarily mean no title/description is rendered.
- Search filters the displayed list; summary totals describe all published public content, not only the filtered search results.
- This is a metadata completeness audit, not a ranking score or Google Search Console report.


## Site-wide Image Audit (v0.9.0)
- REST endpoint: `GET /wp-json/myseo/v1/image-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; page size is capped at 50 published content records per request.
- Scans saved `post_content` for `<img>` tags across published public post types (attachments are excluded).
- Reports each image occurrence with its parent content, filename/source URL, alt attribute status, and edit links.
- Missing `alt` is an issue; `alt=""` is a review item because empty alt is appropriate for decorative images; non-empty alt is marked as set.
- Summary counts apply only to the current post batch, not the entire site. Pagination is over posts, not individual images.
- Does not scan theme templates, CSS background images, shortcode output, or dynamically rendered image markup. It does not infer alt text from Media Library attachment metadata.


## Technical SEO Audit (v1.0.0)
- REST endpoint: `GET /wp-json/myseo/v1/technical-audit?page=1&per_page=20&search=...`.
- Requires `manage_options`; scans a paginated batch of published public post types, with a maximum of 50 posts per request and 500 link occurrences processed per request.
- Site configuration checks include HTTPS in the WordPress home URL, the `blog_public` search visibility option, WordPress core sitemap support, and whether core `rel_canonical` is registered on `wp_head`.
- Content checks inspect saved anchor markup for internal links, HTTP links on HTTPS sites, and internal URLs that `url_to_postid()` cannot map to a post.
- Unresolved internal URLs are review candidates, not confirmed broken links. Archive routes, custom rewrite rules, multilingual paths, and other non-post URLs can be legitimate.
- Does not crawl rendered pages, test every URL with HTTP requests, inspect robots.txt directives, or validate the actual rendered canonical tag. Sitemap support means core sitemap generation is enabled; it does not prove external reachability or search engine submission.
- Summary counts apply to the currently displayed post batch.
