<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Meta_Manager
{
    public const META_TITLE = '_myseo_title';
    public const META_DESCRIPTION = '_myseo_description';
    public const META_KEYPHRASE = '_myseo_focus_keyphrase';

    public function register_hooks(): void
    {
        add_action('add_meta_boxes', [$this, 'register_meta_box']);
        add_action('save_post', [$this, 'save_meta_box'], 10, 2);
        add_filter('pre_get_document_title', [$this, 'filter_document_title'], 20);
        add_action('wp_head', [$this, 'render_meta_description'], 2);

        add_action('init', [$this, 'register_meta_for_rest']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_editor_assets']);
    }

    public function enqueue_editor_assets(string $hook): void
    {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) { return; }
        $screen = get_current_screen();
        if (!$screen || $screen->base !== 'post') { return; }
        wp_enqueue_script('myseo-keyphrase-analysis', MYSEO_URL . 'assets/js/myseo-keyphrase.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_style('myseo-admin', MYSEO_URL . 'assets/css/myseo-admin.css', [], MYSEO_VERSION);
        wp_enqueue_script('myseo-heading-analysis', MYSEO_URL . 'assets/js/myseo-heading.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-readability-analysis', MYSEO_URL . 'assets/js/myseo-readability.js', ['wp-data'], MYSEO_VERSION, true);
        wp_enqueue_script('myseo-image-analysis', MYSEO_URL . 'assets/js/myseo-image.js', ['wp-data'], MYSEO_VERSION, true);
        wp_localize_script('myseo-image-analysis', 'myseoImageSettings', [
            'mediaEditBase' => admin_url('post.php'),
        ]);
    }

    public function register_meta_for_rest(): void
    {
        $post_types = get_post_types(['public' => true], 'names');

        foreach ($post_types as $post_type) {
            register_post_meta($post_type, self::META_TITLE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_DESCRIPTION, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_textarea_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);

            register_post_meta($post_type, self::META_KEYPHRASE, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
            ]);
        }
    }

    public function register_meta_box(): void
    {
        $post_types = get_post_types(['public' => true], 'names');

        foreach ($post_types as $post_type) {
            add_meta_box(
                'myseo-seo-fields',
                __('MySEO – Search appearance', 'myseo'),
                [$this, 'render_meta_box'],
                $post_type,
                'normal',
                'high'
            );
        }
    }

    public function render_meta_box(WP_Post $post): void
    {
        wp_nonce_field('myseo_save_post_meta', 'myseo_nonce');

        $seo_title = get_post_meta($post->ID, self::META_TITLE, true);
        $description = get_post_meta($post->ID, self::META_DESCRIPTION, true);
        $keyphrase = get_post_meta($post->ID, self::META_KEYPHRASE, true);
        ?>
        <p>
            <label for="myseo_title"><strong><?php esc_html_e('SEO title', 'myseo'); ?></strong></label>
            <input type="text" id="myseo_title" name="myseo_title" class="widefat"
                   maxlength="200" value="<?php echo esc_attr($seo_title); ?>"
                   placeholder="<?php echo esc_attr(get_the_title($post)); ?>">
            <span class="description"><?php esc_html_e('Leave blank to use the WordPress post title.', 'myseo'); ?></span>
        </p>
        <p>
            <label for="myseo_description"><strong><?php esc_html_e('Meta description', 'myseo'); ?></strong></label>
            <textarea id="myseo_description" name="myseo_description" class="widefat"
                      rows="3" maxlength="320"><?php echo esc_textarea($description); ?></textarea>
            <span class="description"><?php esc_html_e('A concise summary of this page. Suggested working range: around 150–160 characters; this is not a Google ranking rule.', 'myseo'); ?></span>
        </p>
        <p>
            <label for="myseo_keyphrase"><strong><?php esc_html_e('Focus keyphrase', 'myseo'); ?></strong></label>
            <input type="text" id="myseo_keyphrase" name="myseo_keyphrase" class="widefat"
                   maxlength="200" value="<?php echo esc_attr($keyphrase); ?>">
            <span class="description"><?php esc_html_e('The single phrase this article is being optimized for.', 'myseo'); ?></span>
        </p>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Readability analysis', 'myseo'); ?></h4>
            <div id="myseo-readability-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add article content to see readability suggestions.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Heading structure analysis', 'myseo'); ?></h4>
            <div id="myseo-heading-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add headings to your article to see the structure analysis.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Image SEO analysis', 'myseo'); ?></h4>
            <div id="myseo-image-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Add images to your article to check their alternative text.', 'myseo'); ?></p>
            </div>
        </div>
        <div class="myseo-analysis">
            <h4><?php esc_html_e('Focus keyphrase recommendations', 'myseo'); ?></h4>
            <div id="myseo-keyphrase-results" aria-live="polite">
                <p class="myseo-empty"><?php esc_html_e('Enter a focus keyphrase to see recommendations.', 'myseo'); ?></p>
            </div>
        </div>
        <?php
    }

    public function save_meta_box(int $post_id, WP_Post $post): void
    {
        if (
            !isset($_POST['myseo_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['myseo_nonce'])), 'myseo_save_post_meta')
        ) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
            return;
        }

        $fields = [
            'myseo_title' => self::META_TITLE,
            'myseo_description' => self::META_DESCRIPTION,
            'myseo_keyphrase' => self::META_KEYPHRASE,
        ];

        foreach ($fields as $request_key => $meta_key) {
            if (!isset($_POST[$request_key])) {
                continue;
            }

            $value = sanitize_text_field(wp_unslash($_POST[$request_key]));

            if ($value === '') {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, $value);
            }
        }
    }

    public function filter_document_title(string $title): string
    {
        if (is_admin() || !is_singular()) {
            return $title;
        }

        $post_id = get_queried_object_id();
        if (!$post_id) {
            return $title;
        }

        $custom_title = get_post_meta($post_id, self::META_TITLE, true);

        return $custom_title !== '' ? $custom_title : $title;
    }

    public function render_meta_description(): void
    {
        if (is_admin() || !is_singular()) {
            return;
        }

        $settings = get_option('myseo_settings', []);
        if (empty($settings['enable_meta_output'])) {
            return;
        }

        $post_id = get_queried_object_id();
        if (!$post_id) {
            return;
        }

        $description = get_post_meta($post_id, self::META_DESCRIPTION, true);

        if ($description === '') {
            $excerpt = get_the_excerpt($post_id);
            $description = wp_trim_words(wp_strip_all_tags($excerpt), 30, '');
        }

        if ($description !== '') {
            printf(
                "<meta name=\"description\" content=\"%s\" />\n",
                esc_attr($description)
            );
        }
    }
}
