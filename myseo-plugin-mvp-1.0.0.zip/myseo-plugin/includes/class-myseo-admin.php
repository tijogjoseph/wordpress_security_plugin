<?php
if (!defined('ABSPATH')) {
    exit;
}

final class MySEO_Admin
{
    public function register_hooks(): void
    {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_dashboard_assets']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    public function register_menu(): void
    {
        add_menu_page(
            __('MySEO', 'myseo'),
            __('MySEO', 'myseo'),
            'manage_options',
            'myseo',
            [$this, 'render_dashboard'],
            'dashicons-search',
            58
        );
    }

    public function register_settings(): void
    {
        register_setting('myseo_settings_group', 'myseo_settings', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => ['enable_meta_output' => 1, 'enable_schema_output' => 1],
        ]);
    }

    public function sanitize_settings($input): array
    {
        $input = is_array($input) ? $input : [];
        return [
            'enable_meta_output' => !empty($input['enable_meta_output']) ? 1 : 0,
            'enable_schema_output' => !empty($input['enable_schema_output']) ? 1 : 0,
        ];
    }

    public function enqueue_dashboard_assets(string $hook): void
    {
        if ($hook !== 'toplevel_page_myseo') {
            return;
        }

        wp_enqueue_script(
            'myseo-dashboard',
            MYSEO_URL . 'assets/js/myseo-dashboard.js',
            ['wp-element', 'wp-api-fetch'],
            MYSEO_VERSION,
            true
        );
        wp_enqueue_style('myseo-dashboard', MYSEO_URL . 'assets/css/myseo-dashboard.css', [], MYSEO_VERSION);
        wp_localize_script('myseo-dashboard', 'myseoDashboardConfig', [
            'apiRoot' => esc_url_raw(rest_url('myseo/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
            'version' => MYSEO_VERSION,
        ]);
    }

    public function register_rest_routes(): void
    {
        register_rest_route('myseo/v1', '/dashboard', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_dashboard_data'],
            'permission_callback' => [$this, 'can_manage_myseo'],
        ]);

        register_rest_route('myseo/v1', '/technical-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_technical_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/image-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_image_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/content-audit', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_content_audit'],
            'permission_callback' => [$this, 'can_manage_myseo'],
            'args' => [
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 20, 'sanitize_callback' => 'absint'],
                'search' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('myseo/v1', '/settings', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_settings'],
                'permission_callback' => [$this, 'can_manage_myseo'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_settings'],
                'permission_callback' => [$this, 'can_manage_myseo'],
                'args' => [
                    'enable_meta_output' => ['type' => 'boolean', 'required' => true],
                    'enable_schema_output' => ['type' => 'boolean', 'required' => true],
                ],
            ],
        ]);
    }

    public function get_technical_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Technical_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function get_image_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Site_Image_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function get_content_audit(WP_REST_Request $request): WP_REST_Response
    {
        $auditor = new MySEO_Content_Auditor();
        $result = $auditor->audit(
            max(1, (int) $request->get_param('page')),
            min(50, max(1, (int) $request->get_param('per_page'))),
            (string) $request->get_param('search')
        );
        return new WP_REST_Response($result);
    }

    public function can_manage_myseo(): bool
    {
        return current_user_can('manage_options');
    }

    public function get_dashboard_data(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $post_counts = wp_count_posts('post');
        $page_counts = wp_count_posts('page');
        $published_posts = isset($post_counts->publish) ? (int) $post_counts->publish : 0;
        $published_pages = isset($page_counts->publish) ? (int) $page_counts->publish : 0;

        $public_types = get_post_types(['public' => true], 'names');
        $placeholders = implode(',', array_fill(0, count($public_types), '%s'));
        $title_count = 0;
        $description_count = 0;

        if ($public_types) {
            $title_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                WHERE p.post_status = 'publish' AND p.post_type IN ($placeholders)
                AND pm.meta_key = %s AND pm.meta_value <> ''";
            $title_args = array_merge(array_values($public_types), [MySEO_Meta_Manager::META_TITLE]);
            $title_count = (int) $wpdb->get_var($wpdb->prepare($title_sql, $title_args));

            $description_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                WHERE p.post_status = 'publish' AND p.post_type IN ($placeholders)
                AND pm.meta_key = %s AND pm.meta_value <> ''";
            $description_args = array_merge(array_values($public_types), [MySEO_Meta_Manager::META_DESCRIPTION]);
            $description_count = (int) $wpdb->get_var($wpdb->prepare($description_sql, $description_args));
        }

        $settings = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
        ]);

        return new WP_REST_Response([
            'published_posts' => $published_posts,
            'published_pages' => $published_pages,
            'published_content' => $published_posts + $published_pages,
            'seo_titles_configured' => $title_count,
            'meta_descriptions_configured' => $description_count,
            'meta_output_enabled' => !empty($settings['enable_meta_output']),
            'schema_output_enabled' => !empty($settings['enable_schema_output']),
            'schema_plugin_conflict' => $this->has_known_seo_plugin_active(),
            'version' => MYSEO_VERSION,
        ]);
    }

    public function get_settings(WP_REST_Request $request): WP_REST_Response
    {
        $settings = wp_parse_args(get_option('myseo_settings', []), [
            'enable_meta_output' => 1,
            'enable_schema_output' => 1,
        ]);
        return new WP_REST_Response([
            'enable_meta_output' => (bool) $settings['enable_meta_output'],
            'enable_schema_output' => (bool) $settings['enable_schema_output'],
        ]);
    }

    public function update_settings(WP_REST_Request $request): WP_REST_Response
    {
        $settings = [
            'enable_meta_output' => $request->get_param('enable_meta_output') ? 1 : 0,
            'enable_schema_output' => $request->get_param('enable_schema_output') ? 1 : 0,
        ];
        update_option('myseo_settings', $settings);
        return new WP_REST_Response([
            'saved' => true,
            'enable_meta_output' => (bool) $settings['enable_meta_output'],
            'enable_schema_output' => (bool) $settings['enable_schema_output'],
        ]);
    }

    private function has_known_seo_plugin_active(): bool
    {
        $known = [
            'wordpress-seo/wp-seo.php',
            'seo-by-rank-math/rank-math.php',
            'all-in-one-seo-pack/all_in_one_seo_pack.php',
            'wp-seopress/seopress.php',
            'slim-seo/slim-seo.php',
        ];
        $active = (array) get_option('active_plugins', []);
        if (is_multisite()) {
            $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', [])));
        }
        return (bool) array_intersect($known, $active);
    }

    public function render_dashboard(): void
    {
        if (!$this->can_manage_myseo()) {
            wp_die(esc_html__('You do not have permission to access MySEO.', 'myseo'));
        }
        ?>
        <div class="wrap myseo-dashboard-wrap">
            <div id="myseo-dashboard-root">
                <div class="myseo-loading">
                    <span class="spinner is-active"></span>
                    <p><?php esc_html_e('Loading MySEO dashboard…', 'myseo'); ?></p>
                </div>
            </div>
            <noscript><?php esc_html_e('MySEO dashboard requires JavaScript to be enabled.', 'myseo'); ?></noscript>
        </div>
        <?php
    }
}
