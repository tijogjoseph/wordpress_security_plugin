<?php
/**
 * Technical SEO audit for site configuration and published content.
 */
if (!defined('ABSPATH')) {
    exit;
}

class MySEO_Technical_Auditor
{
    public function audit(int $page = 1, int $per_page = 20, string $search = ''): array
    {
        $page = max(1, $page);
        $per_page = min(50, max(1, $per_page));
        $post_types = array_values(array_diff(get_post_types(['public' => true], 'names'), ['attachment']));
        $query = new WP_Query([
            'post_type' => $post_types ?: 'post',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            's' => sanitize_text_field($search),
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => false,
            'ignore_sticky_posts' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        $https = wp_parse_url(home_url('/'), PHP_URL_SCHEME) === 'https';
        $public = (string) get_option('blog_public', '1') === '1';
        $sitemaps_enabled = function_exists('wp_sitemaps_enabled') ? wp_sitemaps_enabled() : false;
        $canonical_hooked = has_action('wp_head', 'rel_canonical') !== false;
        $site_checks = [
            [
                'id' => 'https',
                'label' => 'HTTPS site URL',
                'status' => $https ? 'good' : 'issue',
                'detail' => $https ? 'The WordPress home URL uses HTTPS.' : 'The WordPress home URL does not use HTTPS. Configure SSL and update the WordPress Address and Site Address where appropriate.',
                'url' => home_url('/'),
            ],
            [
                'id' => 'visibility',
                'label' => 'Search engine visibility',
                'status' => $public ? 'good' : 'issue',
                'detail' => $public ? 'WordPress is not configured to discourage search engines.' : 'WordPress is configured to discourage search engines from indexing this site. Check Settings → Reading.',
                'url' => admin_url('options-reading.php'),
            ],
            [
                'id' => 'sitemap',
                'label' => 'XML sitemap support',
                'status' => $sitemaps_enabled ? 'good' : 'review',
                'detail' => $sitemaps_enabled ? 'WordPress core XML sitemap generation is enabled. Confirm the sitemap is reachable and submitted to search engines.' : 'WordPress core XML sitemaps are not currently enabled. Another SEO plugin or custom sitemap may provide this feature.',
                'url' => home_url('/wp-sitemap.xml'),
            ],
            [
                'id' => 'canonical',
                'label' => 'Canonical tag support',
                'status' => $canonical_hooked ? 'good' : 'review',
                'detail' => $canonical_hooked ? 'WordPress core canonical output is registered on wp_head. Verify the rendered page source and check for duplicate canonical tags.' : 'WordPress core canonical output was not detected on wp_head. A theme or plugin may provide canonical tags instead.',
                'url' => '',
            ],
        ];

        $items = [];
        $summary = ['posts_in_batch' => count($query->posts), 'posts_with_internal_links' => 0, 'internal_link_occurrences' => 0, 'mixed_content_links' => 0, 'unresolved_internal_links' => 0];
        $posts_with_links = [];

        foreach ($query->posts as $post) {
            $content = (string) $post->post_content;
            if (!preg_match_all('/<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $content, $matches, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($matches as $match) {
                if (count($items) >= 500) {
                    break 2;
                }
                $href = html_entity_decode($match[1] !== '' ? $match[1] : ($match[2] !== '' ? $match[2] : ($match[3] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $href = trim($href);
                if ($href === '' || str_starts_with($href, '#') || preg_match('/^(mailto:|tel:|javascript:|data:)/i', $href)) {
                    continue;
                }
                $absolute = (string) (wp_parse_url($href, PHP_URL_SCHEME) ? $href : (str_starts_with($href, '//') ? (is_ssl() ? 'https:' : 'http:') . $href : home_url($href)));
                $host = strtolower((string) wp_parse_url($absolute, PHP_URL_HOST));
                $site_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
                if (!$host || $host !== $site_host) {
                    continue;
                }

                $summary['internal_link_occurrences']++;
                $posts_with_links[(int) $post->ID] = true;
                $mixed = $https && strtolower((string) wp_parse_url($absolute, PHP_URL_SCHEME)) === 'http';
                if ($mixed) {
                    $summary['mixed_content_links']++;
                }
                $path = (string) wp_parse_url($absolute, PHP_URL_PATH);
                $is_home = untrailingslashit($path) === untrailingslashit((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
                $target_id = $is_home ? 1 : url_to_postid($absolute);
                $unresolved = !$is_home && !$target_id;
                if ($unresolved) {
                    $summary['unresolved_internal_links']++;
                }

                $items[] = [
                    'key' => (int) $post->ID . '-' . count($items),
                    'post_id' => (int) $post->ID,
                    'post_title' => get_the_title($post) ?: '(Untitled)',
                    'post_type' => (string) $post->post_type,
                    'href' => esc_url_raw($absolute),
                    'mixed_content' => $mixed,
                    'unresolved' => $unresolved,
                    'post_edit_url' => get_edit_post_link($post->ID, 'raw'),
                ];
            }
        }
        $summary['posts_with_internal_links'] = count($posts_with_links);

        return [
            'site_checks' => $site_checks,
            'items' => $items,
            'summary' => $summary,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total_posts' => (int) $query->found_posts,
                'total_pages' => max(1, (int) $query->max_num_pages),
            ],
        ];
    }
}
