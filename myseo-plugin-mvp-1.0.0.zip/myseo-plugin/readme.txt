=== MySEO ===
Contributors: myseo
Tags: seo, metadata, search
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

A lightweight SEO plugin MVP foundation.

== MVP features in this starter ==
* Custom SEO title field for public post types.
* Custom meta description field.
* One focus keyphrase field.
* Custom SEO title output through WordPress document title filtering.
* Meta description output in the document head, with excerpt fallback.
* Basic plugin settings page.
* Live focus keyphrase checks for title, description, slug, introduction, headings, and article body.
* Live readability checks for sentence length, paragraph length, likely passive voice, transition words, and repeated sentence openings.
* Heading structure analysis for missing/multiple H1, empty headings, skipped heading levels, and a heading outline.
* Image SEO analysis for missing alt attributes and empty alt values, with Media Library edit links when an attachment ID is available.
* Basic JSON-LD structured data: BlogPosting for standard posts and WebPage for other singular public content.
* Structured data output setting and duplicate-output avoidance when selected SEO plugins are active.
* React-powered WordPress admin dashboard with overview metrics, navigation, and settings management via authenticated REST API.
* Paginated Content Audit for published public content: missing custom SEO titles, meta descriptions, focus keyphrases, and duplicate custom titles/descriptions.

== Dashboard ==
The MySEO dashboard provides an overview of published content, configured SEO titles and meta descriptions, schema status, and settings. Content Audit is implemented with paginated results. Content Health and SEO Performance remain roadmap placeholders. Image and Technical SEO audits scan saved content in paginated post batches.

== Installation ==
1. Upload the myseo-plugin folder to /wp-content/plugins/.
2. Activate MySEO from the WordPress Plugins screen.
3. Edit a post or page and find the “MySEO – Search appearance” panel.
4. Enter an SEO title, meta description, and focus keyphrase.

== Important compatibility note ==
If another SEO plugin or theme is already generating title and description metadata, duplicate output may occur. For this first starter, test on a staging site with other SEO plugins disabled. Compatibility detection and output arbitration are planned before a production release.

== Development status ==
This is an early MVP foundation, not a finished SEO product. Gutenberg sidebar UI, advanced schema types, and automated tests are not included yet.
