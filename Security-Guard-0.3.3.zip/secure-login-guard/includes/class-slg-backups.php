<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard_Backups {
	const CRON_HOOK = 'slg_weekly_backup';
	const WEEKLY_SCHEDULE = 'slg_weekly';
	const MAX_ARCHIVE_FILES = 25000;

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_weekly_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'scheduled_backup' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
		add_action( 'admin_post_slg_run_backup', array( __CLASS__, 'run_backup_now' ) );
		add_action( 'admin_post_slg_download_archive', array( __CLASS__, 'download_archive' ) );
	}

	public static function activate() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, self::WEEKLY_SCHEDULE, self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
			$timestamp = wp_next_scheduled( self::CRON_HOOK );
		}
	}

	public static function add_weekly_schedule( $schedules ) {
		$schedules[ self::WEEKLY_SCHEDULE ] = array(
			'interval' => WEEK_IN_SECONDS,
			'display' => __( 'Once Weekly', 'secure-login-guard' ),
		);
		return $schedules;
	}

	public static function ensure_schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			self::activate();
		}
	}

	public static function scheduled_backup() {
		$result = self::create_backup();
		if ( is_wp_error( $result ) ) {
			error_log( 'Security Guard scheduled backup failed: ' . sanitize_text_field( $result->get_error_message() ) );
			self::save_status( false, $result->get_error_message() );
			return;
		}
		self::save_status( true, basename( $result ) );
	}

	public static function render_admin_section() {
		$path = self::backup_directory();
		$files = is_wp_error( $path ) ? array() : self::backup_files( $path );
		$notice = get_transient( 'slg_backup_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'slg_backup_notice_' . get_current_user_id() );
			echo '<div class="notice notice-info inline"><p>' . esc_html( $notice ) . '</p></div>';
		}
		if ( is_wp_error( $path ) ) {
			echo '<p class="notice notice-error inline"><span>' . esc_html( $path->get_error_message() ) . '</span></p>';
		}
		$status = get_option( 'slg_backup_last_result', array() );
		if ( is_array( $status ) && isset( $status['time'], $status['success'], $status['message'] ) ) {
			$label = $status['success'] ? __( 'Last backup succeeded', 'secure-login-guard' ) : __( 'Last backup failed', 'secure-login-guard' );
			echo '<p>' . esc_html( $label . ' — ' . $status['time'] . ' UTC: ' . $status['message'] ) . '</p>';
		}
		$next_run = wp_next_scheduled( self::CRON_HOOK );
		if ( $next_run ) {
			echo '<p class="description">' . esc_html( sprintf( __( 'Next scheduled backup: %s UTC.', 'secure-login-guard' ), gmdate( 'Y-m-d H:i:s', $next_run ) ) ) . '</p>';
		}
		?>
		<p>
			<?php
			if ( $path && ! is_wp_error( $path ) ) {
				esc_html_e( 'Private backup directory:', 'secure-login-guard' );
				echo ' <code>' . esc_html( $path ) . '</code>';
			}
			?>
		</p>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="slg_run_backup">
			<?php wp_nonce_field( 'slg_run_backup' ); ?>
			<?php submit_button( __( 'Run database + file backup now', 'secure-login-guard' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php if ( $files ) : ?>
			<h3><?php esc_html_e( 'Available backup archives', 'secure-login-guard' ); ?></h3>
			<ul>
				<?php foreach ( $files as $file ) : ?>
					<li>
						<?php echo esc_html( gmdate( 'Y-m-d H:i:s', filemtime( $file ) ) . ' UTC — ' . size_format( filesize( $file ) ) ); ?>
						<?php
						$url = wp_nonce_url(
							add_query_arg(
								array(
									'action' => 'slg_download_archive',
									'file' => basename( $file ),
								),
								admin_url( 'admin-post.php' )
							),
							'slg_download_archive_' . basename( $file )
						);
						?>
						<a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Download', 'secure-login-guard' ); ?></a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php
	}

	public static function get_admin_data() {
		$path = self::backup_directory();
		$files = is_wp_error( $path ) ? array() : self::backup_files( $path );
		$notice = get_transient( 'slg_backup_notice_' . get_current_user_id() );
		$status = get_option( 'slg_backup_last_result', array() );
		$status = is_array( $status ) ? array(
			'success' => ! empty( $status['success'] ),
			'time' => isset( $status['time'] ) && is_string( $status['time'] ) ? $status['time'] : '',
			'message' => isset( $status['message'] ) && is_string( $status['message'] ) ? $status['message'] : '',
		) : array();
		$next_run = wp_next_scheduled( self::CRON_HOOK );
		$archives = array();

		foreach ( $files as $file ) {
			$filename = basename( $file );
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'slg_download_archive',
						'file' => $filename,
					),
					admin_url( 'admin-post.php' )
				),
				'slg_download_archive_' . $filename
			);
			$archives[] = array(
				'label' => gmdate( 'Y-m-d H:i:s', filemtime( $file ) ) . ' UTC — ' . size_format( filesize( $file ) ),
				'url' => $url,
			);
		}

		return array(
			'directory' => is_wp_error( $path ) ? '' : $path,
			'error' => is_wp_error( $path ) ? $path->get_error_message() : '',
			'notice' => is_string( $notice ) ? $notice : '',
			'status' => is_array( $status ) ? $status : array(),
			'nextRun' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
			'archives' => $archives,
		);
	}

	public static function run_backup_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to run backups.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_run_backup' );
		$result = self::create_backup();
		if ( is_wp_error( $result ) ) {
			set_transient( 'slg_backup_notice_' . get_current_user_id(), $result->get_error_message(), MINUTE_IN_SECONDS );
			self::save_status( false, $result->get_error_message() );
		} else {
			set_transient( 'slg_backup_notice_' . get_current_user_id(), __( 'Database + file backup completed successfully.', 'secure-login-guard' ), MINUTE_IN_SECONDS );
			self::save_status( true, basename( $result ) );
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Secure_Login_Guard::SETTINGS_PAGE ) );
		exit;
	}

	public static function download_archive() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to download this backup.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
		}
		$file = isset( $_GET['file'] ) && is_string( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		check_admin_referer( 'slg_download_archive_' . $file );
		if ( ! preg_match( '/^slg-backup-\d{8}-\d{6}-[a-f0-9]{6}\.zip$/', $file ) ) {
			wp_die( esc_html__( 'Invalid backup archive name.', 'secure-login-guard' ), '', array( 'response' => 400 ) );
		}
		$directory = self::backup_directory();
		if ( is_wp_error( $directory ) ) {
			wp_die( esc_html( $directory->get_error_message() ), '', array( 'response' => 500 ) );
		}
		$path = $directory . DIRECTORY_SEPARATOR . $file;
		$real_path = realpath( $path );
		if ( false === $real_path || ! is_file( $real_path ) || dirname( $real_path ) !== realpath( $directory ) ) {
			wp_die( esc_html__( 'Backup archive not found.', 'secure-login-guard' ), '', array( 'response' => 404 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Length: ' . (string) filesize( $real_path ) );
		header( 'Content-Disposition: attachment; filename="' . $file . '"' );
		readfile( $real_path );
		exit;
	}

	private static function create_backup() {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'slg_zip_missing', __( 'The PHP ZipArchive extension is required for database + file backups. Ask your host to enable it.', 'secure-login-guard' ) );
		}
		$directory = self::backup_directory();
		if ( is_wp_error( $directory ) ) {
			return $directory;
		}
		$temporary_sql = tempnam( sys_get_temp_dir(), 'slg-db-' );
		if ( false === $temporary_sql ) {
			return new WP_Error( 'slg_temp_failed', __( 'A temporary database export file could not be created.', 'secure-login-guard' ) );
		}
		$stream = fopen( $temporary_sql, 'wb' );
		if ( false === $stream ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_temp_open_failed', __( 'The temporary database export file could not be opened.', 'secure-login-guard' ) );
		}
		$dump = self::write_database_dump( $stream );
		$closed = fclose( $stream );
		if ( ! $closed && ! is_wp_error( $dump ) ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_db_close_failed', __( 'The temporary database export could not be finalized.', 'secure-login-guard' ) );
		}
		if ( is_wp_error( $dump ) ) {
			unlink( $temporary_sql );
			return $dump;
		}

		$filename = 'slg-backup-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 3 ) ) . '.zip';
		$archive_path = $directory . DIRECTORY_SEPARATOR . $filename;
		$archive = new ZipArchive();
		$opened = $archive->open( $archive_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );
		if ( true !== $opened ) {
			unlink( $temporary_sql );
			return new WP_Error( 'slg_zip_open_failed', __( 'The backup archive could not be created in the private directory.', 'secure-login-guard' ) );
		}
		if ( ! $archive->addFile( $temporary_sql, 'database.sql' ) ) {
			$archive->close();
			unlink( $temporary_sql );
			unlink( $archive_path );
			return new WP_Error( 'slg_zip_database_failed', __( 'The database export could not be added to the backup archive.', 'secure-login-guard' ) );
		}

		$file_result = self::add_site_files( $archive );
		if ( is_wp_error( $file_result ) ) {
			$archive->close();
			unlink( $temporary_sql );
			unlink( $archive_path );
			return $file_result;
		}
		if ( ! $archive->close() ) {
			unlink( $temporary_sql );
			unlink( $archive_path );
			return new WP_Error( 'slg_zip_close_failed', __( 'The backup archive could not be finalized.', 'secure-login-guard' ) );
		}
		unlink( $temporary_sql );
		if ( ! chmod( $archive_path, 0600 ) ) {
			unlink( $archive_path );
			return new WP_Error( 'slg_archive_permissions', __( 'The completed backup archive permissions could not be restricted.', 'secure-login-guard' ) );
		}
		self::apply_retention( $directory );
		return $archive_path;
	}

	private static function write_database_dump( $stream ) {
		global $wpdb;
		if ( ! self::write_all( $stream, "-- Security Guard database backup\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n" ) ) {
			return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'secure-login-guard' ) );
		}
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		if ( ! is_array( $tables ) ) {
			return new WP_Error( 'slg_db_tables_failed', __( 'Could not list database tables for backup.', 'secure-login-guard' ) );
		}
		foreach ( $tables as $table ) {
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			$create = $wpdb->get_row( "SHOW CREATE TABLE {$table_sql}", ARRAY_N );
			if ( ! is_array( $create ) || ! isset( $create[1] ) ) {
				return new WP_Error( 'slg_db_schema_failed', __( 'Could not read a database table definition.', 'secure-login-guard' ) );
			}
			if ( ! self::write_all( $stream, "\nDROP TABLE IF EXISTS {$table_sql};\n" . $create[1] . ";\n" ) ) {
				return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'secure-login-guard' ) );
			}
			$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table_sql}", 0 );
			if ( ! is_array( $columns ) ) {
				return new WP_Error( 'slg_db_columns_failed', __( 'Could not read database table columns.', 'secure-login-guard' ) );
			}
			if ( ! $columns ) {
				continue;
			}
			$column_sql = implode( ', ', array_map( static function ( $column ) {
				return '`' . str_replace( '`', '``', $column ) . '`';
			}, $columns ) );
			$offset = 0;
			do {
				$rows = $wpdb->get_results( "SELECT * FROM {$table_sql} LIMIT 200 OFFSET " . absint( $offset ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					return new WP_Error( 'slg_db_rows_failed', __( 'Could not read rows from a database table.', 'secure-login-guard' ) );
				}
				foreach ( $rows as $row ) {
					$values = array();
					foreach ( $columns as $column ) {
						$value = $row[ $column ];
						$values[] = null === $value ? 'NULL' : "'" . $wpdb->_real_escape( $value ) . "'";
					}
					if ( ! self::write_all( $stream, 'INSERT INTO ' . $table_sql . ' (' . $column_sql . ') VALUES (' . implode( ', ', $values ) . ");\n" ) ) {
						return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be written.', 'secure-login-guard' ) );
					}
				}
				$offset += count( $rows );
			} while ( count( $rows ) === 200 );
		}
		if ( ! self::write_all( $stream, "\nSET FOREIGN_KEY_CHECKS=1;\n" ) ) {
			return new WP_Error( 'slg_db_write_failed', __( 'The database export could not be finalized.', 'secure-login-guard' ) );
		}
		return true;
	}

	private static function write_all( $stream, $contents ) {
		$length = strlen( $contents );
		$written = 0;
		while ( $written < $length ) {
			$result = fwrite( $stream, substr( $contents, $written ) );
			if ( false === $result || 0 === $result ) {
				return false;
			}
			$written += $result;
		}
		return true;
	}

	private static function add_site_files( $archive ) {
		$root = realpath( ABSPATH );
		if ( false === $root ) {
			return new WP_Error( 'slg_files_root_missing', __( 'The WordPress directory could not be resolved for backup.', 'secure-login-guard' ) );
		}
		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
			$count = 0;
			foreach ( $iterator as $file ) {
				if ( $file->isLink() || ! $file->isFile() ) {
					continue;
				}
				$path = $file->getRealPath();
				if ( false === $path || 0 !== strpos( $path, $root . DIRECTORY_SEPARATOR ) ) {
					continue;
				}
				$relative = substr( $path, strlen( $root ) + 1 );
				if ( preg_match( '#^wp-content/cache(?:/|$)#', str_replace( DIRECTORY_SEPARATOR, '/', $relative ) ) ) {
					continue;
				}
				if ( ++$count > self::MAX_ARCHIVE_FILES ) {
					return new WP_Error( 'slg_file_limit', __( 'The site contains more files than this MVP backup limit supports. Use a host backup solution for this site.', 'secure-login-guard' ) );
				}
				if ( ! $archive->addFile( $path, str_replace( DIRECTORY_SEPARATOR, '/', $relative ) ) ) {
					return new WP_Error( 'slg_file_add_failed', __( 'A site file could not be added to the backup archive.', 'secure-login-guard' ) );
				}
			}
		} catch ( UnexpectedValueException $error ) {
			return new WP_Error( 'slg_file_scan_failed', __( 'The site files could not be completely scanned for backup. Check filesystem permissions.', 'secure-login-guard' ) );
		}
		return true;
	}

	private static function backup_directory() {
		$document_root = isset( $_SERVER['DOCUMENT_ROOT'] ) && is_string( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( wp_unslash( $_SERVER['DOCUMENT_ROOT'] ) ) : false;
		if ( false === $document_root ) {
			return new WP_Error( 'slg_docroot_unknown', __( 'The web server document root could not be determined. Secure backup storage cannot be verified.', 'secure-login-guard' ) );
		}
		$directory = dirname( $document_root ) . DIRECTORY_SEPARATOR . '.secure-login-guard-' . substr( hash( 'sha256', home_url() ), 0, 12 );
		if ( ! is_dir( $directory ) && ! wp_mkdir_p( $directory ) ) {
			return new WP_Error( 'slg_backup_dir_create_failed', __( 'A private backup directory could not be created outside the web root.', 'secure-login-guard' ) );
		}
		$real_directory = realpath( $directory );
		if ( false === $real_directory || 0 === strpos( $real_directory . DIRECTORY_SEPARATOR, trailingslashit( $document_root ) ) ) {
			return new WP_Error( 'slg_backup_dir_public', __( 'The configured backup directory is inside the public web root. No backup was written.', 'secure-login-guard' ) );
		}
		if ( ! is_writable( $real_directory ) || ! @chmod( $real_directory, 0700 ) ) {
			return new WP_Error( 'slg_backup_dir_permissions', __( 'The private backup directory is not writable or its permissions could not be restricted.', 'secure-login-guard' ) );
		}
		return $real_directory;
	}

	private static function apply_retention( $directory ) {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		$keep = isset( $settings['backup_retention'] ) ? min( 30, max( 1, absint( $settings['backup_retention'] ) ) ) : 5;
		$files = self::backup_files( $directory );
		usort( $files, static function ( $first, $second ) {
			return filemtime( $second ) <=> filemtime( $first );
		} );
		foreach ( array_slice( $files, $keep ) as $old_file ) {
			if ( ! unlink( $old_file ) ) {
				error_log( 'Security Guard could not remove an expired backup archive.' );
			}
		}
	}

	private static function save_status( $success, $message ) {
		update_option(
			'slg_backup_last_result',
			array(
				'time' => gmdate( 'Y-m-d H:i:s' ),
				'success' => (bool) $success,
				'message' => sanitize_text_field( $message ),
			),
			false
		);
	}

	private static function backup_files( $directory ) {
		$files = glob( $directory . DIRECTORY_SEPARATOR . 'slg-backup-*.zip' );
		if ( ! is_array( $files ) ) {
			return array();
		}
		return array_values(
			array_filter( $files, static function ( $path ) {
				return is_file( $path ) && preg_match( '/^slg-backup-\d{8}-\d{6}-[a-f0-9]{6}\.zip$/', basename( $path ) );
			} )
		);
	}
}
