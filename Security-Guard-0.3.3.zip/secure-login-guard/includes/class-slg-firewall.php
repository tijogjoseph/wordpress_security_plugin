<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard_Firewall {
	const TABLE_SUFFIX = 'slg_firewall_events';
	const BLOCK_SECONDS = 30 * MINUTE_IN_SECONDS;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'inspect_request' ), 0 );
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_time datetime NOT NULL,
			ip_hash char(64) NOT NULL,
			request_method varchar(16) NOT NULL,
			request_path varchar(255) NOT NULL,
			rule_code varchar(40) NOT NULL,
			PRIMARY KEY  (id),
			KEY event_time (event_time)
		) {$charset_collate};";
		dbDelta( $sql );
	}

	public static function inspect_request() {
		$settings = get_option( Secure_Login_Guard::OPTION_NAME, array() );
		if ( isset( $settings['firewall_enabled'] ) && ! absint( $settings['firewall_enabled'] ) ) {
			return;
		}

		$ip = self::client_ip();
		if ( 'unknown' !== $ip ) {
			$login_block = get_transient( self::ip_transient_key( $ip ) );
			if ( is_array( $login_block ) && isset( $login_block['blocked_until'] ) && absint( $login_block['blocked_until'] ) > time() ) {
				wp_die( esc_html__( 'Access is temporarily limited after repeated failed sign-in attempts.', 'secure-login-guard' ), '', array( 'response' => 429 ) );
			}
			if ( get_transient( self::firewall_block_key( $ip ) ) ) {
				wp_die( esc_html__( 'This request is temporarily blocked by the site security firewall.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
			}
		}

		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : '';
		$rule = self::inspect_method( $method );
		if ( $rule ) {
			self::block_request( $ip, $method, $rule );
		}

		$payload = self::request_payload();
		$rule = self::match_payload( $payload );
		if ( $rule ) {
			self::block_request( $ip, $method, $rule );
		}
	}

	private static function inspect_method( $method ) {
		if ( '' === $method || ! preg_match( '/^[A-Z]{1,16}$/', $method ) ) {
			return 'invalid_method';
		}
		if ( ! in_array( $method, array( 'GET', 'POST', 'HEAD', 'PUT', 'PATCH', 'DELETE', 'OPTIONS' ), true ) ) {
			return 'unsupported_method';
		}
		return '';
	}

	private static function request_payload() {
		$parts = array();
		$content_length = isset( $_SERVER['CONTENT_LENGTH'] ) ? absint( $_SERVER['CONTENT_LENGTH'] ) : 0;
		if ( 0 === $content_length || $content_length <= 65536 ) {
			$body = file_get_contents( 'php://input', false, null, 0, 32768 );
			if ( false !== $body ) {
				$parts[] = substr( $body, 0, 32768 );
			}
		}
		$parts[] = substr( (string) wp_json_encode( $_POST ), 0, 16384 );
		$parts[] = substr( (string) wp_json_encode( $_GET ), 0, 8192 );
		$parts[] = isset( $_SERVER['REQUEST_URI'] ) ? substr( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), 0, 4096 ) : '';
		$header_parts = array();
		if ( function_exists( 'getallheaders' ) ) {
			$headers = getallheaders();
			if ( is_array( $headers ) ) {
				foreach ( $headers as $name => $value ) {
					if ( ! preg_match( '/^(cookie|authorization|proxy-authorization)$/i', (string) $name ) ) {
						$header_parts[] = (string) $name . ': ' . (string) $value;
					}
				}
			}
		}
		foreach ( $_SERVER as $name => $value ) {
			if ( 0 !== strpos( (string) $name, 'HTTP_' ) || ! is_string( $value ) ) {
				continue;
			}
			$header_name = strtolower( substr( $name, 5 ) );
			if ( in_array( $header_name, array( 'cookie', 'authorization', 'proxy-authorization' ), true ) ) {
				continue;
			}
			$header_parts[] = $header_name . ': ' . $value;
		}
		foreach ( array( 'CONTENT_TYPE', 'CONTENT_LENGTH' ) as $name ) {
			if ( isset( $_SERVER[ $name ] ) && is_string( $_SERVER[ $name ] ) ) {
				$header_parts[] = strtolower( str_replace( '_', '-', $name ) ) . ': ' . $_SERVER[ $name ];
			}
		}
		$parts[] = substr( implode( "\n", $header_parts ), 0, 8192 );
		$payload = implode( "\n", array_filter( $parts, 'is_string' ) );
		return rawurldecode( rawurldecode( $payload ) );
	}

	private static function match_payload( $payload ) {
		$rules = array(
			'xss_script_element' => '/<\s*script\b/i',
			'xss_event_handler' => '/\bon(?:error|load|click|mouseover|focus)\s*=/i',
			'xss_javascript_url' => '/javascript\s*:/i',
			'sqli_union_select' => '/\bunion\s+(?:all\s+)?select\b/i',
			'sqli_timing_function' => '/\b(?:sleep|benchmark)\s*\(/i',
			'sqli_system_schema' => '/\binformation_schema\b/i',
			'sqli_tautology' => '/[\'"]\s*(?:or|and)\s+(?:1\s*=\s*1|[\'"][^\'"]{1,32}[\'"]\s*=\s*[\'"][^\'"]{1,32}[\'"])/i',
			'path_traversal' => '/\.\.[\/\\\\]/',
		);
		foreach ( $rules as $code => $pattern ) {
			if ( preg_match( $pattern, $payload ) ) {
				return $code;
			}
		}
		return '';
	}

	private static function block_request( $ip, $method, $rule ) {
		if ( 'unknown' !== $ip ) {
			set_transient( self::firewall_block_key( $ip ), 1, self::BLOCK_SECONDS );
		}
		self::log_event( $ip, $method, $rule );
		wp_die( esc_html__( 'The request was blocked by the site security firewall.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
	}

	private static function log_event( $ip, $method, $rule ) {
		global $wpdb;
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$path = (string) wp_parse_url( $path, PHP_URL_PATH );
		$path = preg_replace( '/[A-Za-z0-9_-]{32,}/', '[redacted]', $path );
		$path = substr( sanitize_text_field( $path ), 0, 255 );
		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$result = $wpdb->insert(
			$table,
			array(
				'event_time' => current_time( 'mysql', true ),
				'ip_hash' => hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ),
				'request_method' => substr( $method, 0, 16 ),
				'request_path' => $path,
				'rule_code' => $rule,
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
		if ( false === $result ) {
			error_log( 'Security Guard could not write a firewall event record.' );
			return;
		}
		if ( 0 === (int) $wpdb->insert_id % 100 ) {
			$wpdb->query( "DELETE FROM {$table} WHERE id NOT IN (SELECT id FROM (SELECT id FROM {$table} ORDER BY id DESC LIMIT 2000) recent)" );
		}
	}

	public static function render_admin_log() {
		$events = self::get_admin_events();
		if ( false === $events ) {
			echo '<p>' . esc_html__( 'Firewall event records are currently unavailable.', 'secure-login-guard' ) . '</p>';
			return;
		}
		if ( ! $events ) {
			echo '<p>' . esc_html__( 'No firewall events recorded.', 'secure-login-guard' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'UTC time', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'IP fingerprint', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Method', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Path', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Rule', 'secure-login-guard' ) . '</th></tr></thead><tbody>';
		foreach ( $events as $event ) {
			echo '<tr><td>' . esc_html( $event['event_time'] ) . '</td><td><code>' . esc_html( substr( $event['ip_hash'], 0, 12 ) ) . '</code></td><td>' . esc_html( $event['request_method'] ) . '</td><td><code>' . esc_html( $event['request_path'] ) . '</code></td><td>' . esc_html( $event['rule_code'] ) . '</td></tr>';
		}
		echo '</tbody></table><p class="description">' . esc_html__( 'Request bodies, header values, and raw IP addresses are not stored. IP fingerprints are keyed hashes for correlation.', 'secure-login-guard' ) . '</p>';
	}

	public static function get_admin_events() {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$events = $wpdb->get_results( "SELECT event_time, ip_hash, request_method, request_path, rule_code FROM {$table} ORDER BY id DESC LIMIT 25", ARRAY_A );
		if ( ! is_array( $events ) ) {
			return false;
		}

		foreach ( $events as &$event ) {
			$event['ip_hash'] = substr( $event['ip_hash'], 0, 12 );
		}
		unset( $event );

		return $events;
	}

	private static function client_ip() {
		if ( empty( $_SERVER['REMOTE_ADDR'] ) || ! is_string( $_SERVER['REMOTE_ADDR'] ) ) {
			return 'unknown';
		}
		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : 'unknown';
	}

	private static function ip_transient_key( $ip ) {
		return 'slg_' . hash_hmac( 'sha256', 'ip|' . $ip, wp_salt( 'auth' ) );
	}

	private static function firewall_block_key( $ip ) {
		return 'slg_waf_' . hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}
}
