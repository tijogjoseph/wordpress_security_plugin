<?php
/**
 * Plugin Name: Security Guard
 * Description: Adds configurable WordPress security protections.
 * Version: 0.3.3
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: secure-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Secure_Login_Guard {
	const OPTION_NAME = 'secure_login_guard_settings';
	const SETTINGS_PAGE = 'secure-login-guard';
	private static $settings_page_hook = '';

	/**
	 * Register WordPress hooks.
	 */
	public static function init() {
		require_once __DIR__ . '/includes/class-slg-firewall.php';
		require_once __DIR__ . '/includes/class-slg-backups.php';
		Secure_Login_Guard_Firewall::init();
		Secure_Login_Guard_Backups::init();
		add_filter( 'authenticate', array( __CLASS__, 'check_lockout' ), 30, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'check_login_captcha' ), 98, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'check_two_factor' ), 99, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'record_failure' ) );
		add_action( 'wp_login', array( __CLASS__, 'clear_login_failures' ), 10, 2 );
		add_action( 'login_form_middle', array( __CLASS__, 'render_login_2fa_field' ) );
		add_action( 'login_form', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'register_form', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'enqueue_captcha_script' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'render_2fa_profile' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'render_2fa_profile' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_2fa_profile' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_2fa_profile' ) );
		add_filter( 'registration_errors', array( __CLASS__, 'validate_registration_password' ), 10, 3 );
		add_filter( 'registration_errors', array( __CLASS__, 'validate_registration_captcha' ), 20, 3 );
		add_action( 'user_profile_update_errors', array( __CLASS__, 'validate_profile_password' ), 10, 3 );
		add_action( 'validate_password_reset', array( __CLASS__, 'validate_reset_password' ), 10, 2 );
		add_action( 'comment_form_after_fields', array( __CLASS__, 'render_comment_honeypot' ) );
		add_action( 'comment_form_logged_in_after', array( __CLASS__, 'render_comment_honeypot' ) );
		add_action( 'comment_form_after_fields', array( __CLASS__, 'render_captcha_field' ) );
		add_action( 'comment_form_logged_in_after', array( __CLASS__, 'render_captcha_field' ) );
		add_filter( 'pre_comment_approved', array( __CLASS__, 'mark_honeypot_comment_as_spam' ), 10, 2 );
		add_filter( 'preprocess_comment', array( __CLASS__, 'check_comment_captcha' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_captcha_script' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_inactivity_script' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_inactivity_script' ) );
		add_action( 'wp_ajax_slg_activity', array( __CLASS__, 'record_activity' ) );
		add_action( 'admin_post_slg_download_backup', array( __CLASS__, 'download_database_backup' ) );
		add_action( 'admin_post_slg_scan_database', array( __CLASS__, 'run_database_scan' ) );
		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ), -10 );
		add_action( 'register_form', array( __CLASS__, 'render_registration_honeypot' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'add_settings_link' ) );
	}

	/**
	 * Install default settings without overwriting existing values.
	 */
	public static function activate() {
		if ( false === get_option( self::OPTION_NAME ) ) {
			add_option( self::OPTION_NAME, self::default_settings() );
		}
		Secure_Login_Guard_Firewall::install();
		Secure_Login_Guard_Backups::activate();
		update_option( 'slg_version', '0.3.2', false );
	}

	public static function deactivate() {
		Secure_Login_Guard_Backups::deactivate();
	}

	public static function maybe_upgrade() {
		if ( version_compare( get_option( 'slg_version', '0.0.0' ), '0.3.2', '<' ) ) {
			Secure_Login_Guard_Firewall::install();
			Secure_Login_Guard_Backups::activate();
			update_option( 'slg_version', '0.3.2', false );
		}
	}

	private static function default_settings() {
		return array(
			'failures_per_login' => 5,
			'failures_per_ip'    => 20,
			'window_minutes'     => 15,
			'lockout_minutes'    => 15,
			'inactivity_minutes' => 30,
			'minimum_password_length' => 12,
			'firewall_enabled' => 1,
			'captcha_site_key' => '',
			'captcha_secret_key' => '',
			'backup_retention' => 5,
		);
	}

	private static function settings() {
		return wp_parse_args( get_option( self::OPTION_NAME, array() ), self::default_settings() );
	}

	/**
	 * Stop authentication when the corresponding rolling window is locked.
	 *
	 * @param WP_User|WP_Error|null $user     Authentication result so far.
	 * @param string                $username Submitted username.
	 * @param string                $password Submitted password.
	 * @return WP_User|WP_Error|null
	 */
	public static function check_lockout( $user, $username, $password ) {
		unset( $password );

		if ( $user instanceof WP_User ) {
			return $user;
		}

		$ip = self::client_ip();
		$login_state = self::get_state( self::login_key( $username, $ip ) );
		$ip_state = self::get_state( self::ip_key( $ip ) );
		$now = time();

		if ( $login_state['blocked_until'] > $now || $ip_state['blocked_until'] > $now ) {
			return new WP_Error(
				'slg_rate_limited',
				__( 'Too many failed sign-in attempts. Please wait before trying again.', 'secure-login-guard' )
			);
		}

		return $user;
	}

	/**
	 * Record a failed login against the username/IP and, when available, the IP.
	 *
	 * @param string $username Submitted username.
	 */
	public static function record_failure( $username ) {
		$ip = self::client_ip();
		$settings = self::settings();
		$now = time();
		$window = absint( $settings['window_minutes'] ) * MINUTE_IN_SECONDS;
		$lockout = absint( $settings['lockout_minutes'] ) * MINUTE_IN_SECONDS;

		self::add_failure(
			self::login_key( $username, $ip ),
			absint( $settings['failures_per_login'] ),
			$window,
			$lockout,
			$now
		);

		if ( 'unknown' !== $ip ) {
			self::add_failure(
				self::ip_key( $ip ),
				absint( $settings['failures_per_ip'] ),
				$window,
				$lockout,
				$now
			);
		}
	}

	/**
	 * Clear the username-specific counter after a successful login.
	 *
	 * The IP-wide counter is deliberately retained to avoid making password
	 * spraying easier when another user on the same address signs in.
	 *
	 * @param string  $user_login User login.
	 * @param WP_User $user       Authenticated user.
	 */
	public static function clear_login_failures( $user_login, $user ) {
		unset( $user );
		delete_transient( self::login_key( $user_login, self::client_ip() ) );
	}

	private static function add_failure( $key, $limit, $window, $lockout, $now ) {
		$state = self::get_state( $key );

		if ( $state['blocked_until'] > $now ) {
			return;
		}

		$state['failures'][] = $now;
		$state['failures'] = array_values(
			array_filter(
				$state['failures'],
				static function ( $timestamp ) use ( $now, $window ) {
					return $timestamp > $now - $window;
				}
			)
		);

		if ( count( $state['failures'] ) >= $limit ) {
			$state['blocked_until'] = $now + $lockout;
		}

		set_transient( $key, $state, max( $window, $lockout ) + MINUTE_IN_SECONDS );
	}

	private static function get_state( $key ) {
		$state = get_transient( $key );

		if ( ! is_array( $state ) ) {
			return array(
				'failures'      => array(),
				'blocked_until' => 0,
			);
		}

		return array(
			'failures'      => isset( $state['failures'] ) && is_array( $state['failures'] ) ? $state['failures'] : array(),
			'blocked_until' => isset( $state['blocked_until'] ) ? absint( $state['blocked_until'] ) : 0,
		);
	}

	private static function client_ip() {
		if ( empty( $_SERVER['REMOTE_ADDR'] ) || ! is_string( $_SERVER['REMOTE_ADDR'] ) ) {
			return 'unknown';
		}

		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : 'unknown';
	}

	private static function login_key( $username, $ip ) {
		$normalized_username = is_scalar( $username ) ? strtolower( trim( (string) $username ) ) : '';
		return self::transient_key( 'login', $normalized_username . '|' . $ip );
	}

	private static function ip_key( $ip ) {
		return self::transient_key( 'ip', $ip );
	}

	private static function transient_key( $scope, $value ) {
		return 'slg_' . hash_hmac( 'sha256', $scope . '|' . $value, wp_salt( 'auth' ) );
	}

	public static function register_settings() {
		register_setting(
			'secure_login_guard',
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => self::default_settings(),
			)
		);
	}

	public static function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();

		return array(
			'failures_per_login' => self::bounded_int( $input, 'failures_per_login', 5, 3, 20 ),
			'failures_per_ip'    => self::bounded_int( $input, 'failures_per_ip', 20, 10, 100 ),
			'window_minutes'     => self::bounded_int( $input, 'window_minutes', 15, 5, 1440 ),
			'lockout_minutes'    => self::bounded_int( $input, 'lockout_minutes', 15, 1, 1440 ),
			'inactivity_minutes' => self::bounded_int( $input, 'inactivity_minutes', 30, 5, 1440 ),
			'minimum_password_length' => self::bounded_int( $input, 'minimum_password_length', 12, 10, 64 ),
			'firewall_enabled' => isset( $input['firewall_enabled'] ) && is_scalar( $input['firewall_enabled'] ) && '1' === (string) $input['firewall_enabled'] ? 1 : 0,
			'captcha_site_key' => isset( $input['captcha_site_key'] ) && is_string( $input['captcha_site_key'] ) ? sanitize_text_field( $input['captcha_site_key'] ) : '',
			'captcha_secret_key' => self::retained_secret( $input, 'captcha_secret_key' ),
			'backup_retention' => self::bounded_int( $input, 'backup_retention', 5, 1, 30 ),
		);
	}

	private static function retained_secret( $input, $key ) {
		if ( isset( $input[ $key ] ) && is_string( $input[ $key ] ) && '' !== trim( $input[ $key ] ) ) {
			return sanitize_text_field( $input[ $key ] );
		}
		$current = get_option( self::OPTION_NAME, array() );
		return isset( $current[ $key ] ) ? $current[ $key ] : '';
	}

	private static function bounded_int( $input, $key, $default, $minimum, $maximum ) {
		if ( ! isset( $input[ $key ] ) || ! is_numeric( $input[ $key ] ) ) {
			return $default;
		}

		return min( $maximum, max( $minimum, absint( $input[ $key ] ) ) );
	}

	public static function add_settings_page() {
		self::$settings_page_hook = add_options_page(
			__( 'Security Guard', 'secure-login-guard' ),
			__( 'Security Guard', 'secure-login-guard' ),
			'manage_options',
			self::SETTINGS_PAGE,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	public static function enqueue_admin_assets( $hook ) {
		if ( self::$settings_page_hook !== $hook ) {
			return;
		}
		wp_enqueue_style(
			'secure-login-guard-admin',
			plugins_url( 'assets/admin.css', __FILE__ ),
			array(),
			'0.3.2'
		);
		wp_enqueue_script(
			'secure-login-guard-admin',
			plugins_url( 'assets/admin.js', __FILE__ ),
			array( 'wp-element' ),
			'0.3.2',
			true
		);
		$settings = self::settings();
		$settings = array_intersect_key(
			$settings,
			array_flip(
				array(
					'failures_per_login',
					'failures_per_ip',
					'window_minutes',
					'lockout_minutes',
					'inactivity_minutes',
					'minimum_password_length',
					'firewall_enabled',
					'captcha_site_key',
					'backup_retention',
				)
			)
		);
		wp_localize_script(
			'secure-login-guard-admin',
			'SLGAdmin',
			array(
				'settings' => $settings,
				'captchaConfigured' => ! empty( self::settings()['captcha_secret_key'] ),
				'backup' => Secure_Login_Guard_Backups::get_admin_data(),
				'checks' => self::get_security_checks(),
				'scan' => self::get_database_scan_results(),
				'firewallEvents' => Secure_Login_Guard_Firewall::get_admin_events(),
				'urls' => array(
					'options' => admin_url( 'options.php' ),
					'adminPost' => admin_url( 'admin-post.php' ),
					'settingsNonce' => wp_create_nonce( 'secure_login_guard-options' ),
					'scanNonce' => wp_create_nonce( 'slg_scan_database' ),
					'downloadBackupNonce' => wp_create_nonce( 'slg_download_backup' ),
					'runBackupNonce' => wp_create_nonce( 'slg_run_backup' ),
				),
				'text' => self::admin_text(),
			)
		);
	}

	private static function admin_text() {
		return array(
			'brand' => __( 'Security Guard', 'secure-login-guard' ),
			'pageDescription' => __( 'Your site protection at a glance. Review status and manage your security controls below.', 'secure-login-guard' ),
			'protection' => __( 'Protection settings', 'secure-login-guard' ),
			'protectionDescription' => __( 'Tune login safeguards and spam prevention.', 'secure-login-guard' ),
			'failuresPerLogin' => __( 'Failures per username and IP', 'secure-login-guard' ),
			'failuresPerIp' => __( 'Failures per IP address', 'secure-login-guard' ),
			'windowMinutes' => __( 'Counting window (minutes)', 'secure-login-guard' ),
			'lockoutMinutes' => __( 'Lockout duration (minutes)', 'secure-login-guard' ),
			'inactivityMinutes' => __( 'Inactivity logout (minutes)', 'secure-login-guard' ),
			'passwordLength' => __( 'Minimum password length', 'secure-login-guard' ),
			'passwordDescription' => __( 'New or changed passwords must meet this length and include at least three character classes: lowercase, uppercase, number, or symbol.', 'secure-login-guard' ),
			'firewallDescription' => __( 'Inspect requests and temporarily block high-confidence malicious patterns', 'secure-login-guard' ),
			'siteKey' => __( 'Cloudflare Turnstile site key', 'secure-login-guard' ),
			'secretKey' => __( 'Cloudflare Turnstile secret key', 'secure-login-guard' ),
			'configuredKeepKey' => __( 'Configured; leave blank to keep current key', 'secure-login-guard' ),
			'notConfigured' => __( 'Not configured', 'secure-login-guard' ),
			'backupRetention' => __( 'Scheduled backup retention', 'secure-login-guard' ),
			'retentionDescription' => __( 'Keep this many successful database + file backup archives.', 'secure-login-guard' ),
			'ipNote' => __( 'The IP address is taken only from the web server REMOTE_ADDR value. If your site is behind a proxy, configure the proxy/web server to set this value correctly; forwarded headers are intentionally not trusted.', 'secure-login-guard' ),
			'twoFactor' => __( 'Two-factor authentication', 'secure-login-guard' ),
			'twoFactorDescription' => __( 'Users can enable authenticator-app TOTP (compatible with Google Authenticator and Microsoft Authenticator) and recovery codes from their own profile under Users > Profile. Email OTP is available as a fallback for users with TOTP enabled.', 'secure-login-guard' ),
			'smsNote' => __( 'SMS OTP is not included because it requires a provider account, credentials, and delivery policy.', 'secure-login-guard' ),
			'backups' => __( 'Backups and disaster recovery', 'secure-login-guard' ),
			'backupDescription' => __( 'Weekly database + file backups are scheduled with WordPress Cron. Archives are kept in a private directory outside the web root; the plugin will report an error rather than use a public folder if secure storage is unavailable.', 'secure-login-guard' ),
			'runBackup' => __( 'Run database + file backup now', 'secure-login-guard' ),
			'availableArchives' => __( 'Available backup archives', 'secure-login-guard' ),
			'download' => __( 'Download', 'secure-login-guard' ),
			'manualBackupDescription' => __( 'Manual database-only download is also available. Backups contain sensitive data. Test restoration and keep a separate off-site copy.', 'secure-login-guard' ),
			'downloadDatabase' => __( 'Download database backup', 'secure-login-guard' ),
			'securityChecks' => __( 'Security checks', 'secure-login-guard' ),
			'checksDescription' => __( 'These checks report configuration signals; they do not change permissions, database settings, or block traffic. Ask your host before changing server-level settings.', 'secure-login-guard' ),
			'storedContentScan' => __( 'Stored content scan', 'secure-login-guard' ),
			'scanDescription' => __( 'On-demand scan of core posts, comments, and options for a small set of suspicious SQL/XSS markers. Results are advisory and show fingerprints, not stored content.', 'secure-login-guard' ),
			'scanButton' => __( 'Scan core database content', 'secure-login-guard' ),
			'firewallEvents' => __( 'Firewall events', 'secure-login-guard' ),
			'recentActivity' => __( 'Recent activity', 'secure-login-guard' ),
			'active' => __( 'Active', 'secure-login-guard' ),
			'disabled' => __( 'Disabled', 'secure-login-guard' ),
			'configured' => __( 'Turnstile configured', 'secure-login-guard' ),
			'setupRecommended' => __( 'Setup recommended', 'secure-login-guard' ),
			'backupHealthy' => __( 'Backup healthy', 'secure-login-guard' ),
			'backupAttention' => __( 'Backup needs attention', 'secure-login-guard' ),
			'backupSucceeded' => __( 'Last backup succeeded', 'secure-login-guard' ),
			'backupFailed' => __( 'Last backup failed', 'secure-login-guard' ),
			'nextBackup' => __( 'Next scheduled backup: %s UTC.', 'secure-login-guard' ),
			'requestFirewall' => __( 'Request firewall', 'secure-login-guard' ),
			'captcha' => __( 'CAPTCHA', 'secure-login-guard' ),
			'backupCard' => __( 'Backups', 'secure-login-guard' ),
			'twoFactorCard' => __( 'Two-factor auth', 'secure-login-guard' ),
			'userManaged' => __( 'User-managed', 'secure-login-guard' ),
			'perUser' => __( 'Per user', 'secure-login-guard' ),
			'reportOnly' => __( 'Report only', 'secure-login-guard' ),
			'saveSettings' => __( 'Save settings', 'secure-login-guard' ),
			'protectionNav' => __( 'Protection', 'secure-login-guard' ),
			'twoFactorNav' => __( 'Two-factor', 'secure-login-guard' ),
			'backupsNav' => __( 'Backups', 'secure-login-guard' ),
			'checksNav' => __( 'Security checks', 'secure-login-guard' ),
			'eventsNav' => __( 'Firewall events', 'secure-login-guard' ),
			'statusOverview' => __( 'Security status overview', 'secure-login-guard' ),
			'sections' => __( 'Dashboard sections', 'secure-login-guard' ),
			'eyebrowSite' => __( 'SITE SECURITY', 'secure-login-guard' ),
			'eyebrowProtection' => __( 'ACCESS & PREVENTION', 'secure-login-guard' ),
			'eyebrowAccount' => __( 'ACCOUNT SECURITY', 'secure-login-guard' ),
			'eyebrowRecovery' => __( 'RECOVERY', 'secure-login-guard' ),
			'eyebrowHealth' => __( 'SITE HEALTH', 'secure-login-guard' ),
			'eyebrowFirewall' => __( 'FIREWALL', 'secure-login-guard' ),
			'check' => __( 'Check', 'secure-login-guard' ),
			'result' => __( 'Result', 'secure-login-guard' ),
			'noScan' => __( 'No configured suspicious markers were found in the scanned core tables.', 'secure-login-guard' ),
			'scanAt' => __( 'Scan completed at %s UTC.', 'secure-login-guard' ),
			'scanTruncated' => __( 'The display limit was reached; not all matching rows may be shown.', 'secure-login-guard' ),
			'table' => __( 'Table', 'secure-login-guard' ),
			'row' => __( 'Row', 'secure-login-guard' ),
			'column' => __( 'Column', 'secure-login-guard' ),
			'marker' => __( 'Marker', 'secure-login-guard' ),
			'fingerprint' => __( 'Fingerprint', 'secure-login-guard' ),
			'scanCaution' => __( 'Markers can appear in legitimate content. Review each row in context; this scan does not modify data.', 'secure-login-guard' ),
			'noEvents' => __( 'No firewall events recorded.', 'secure-login-guard' ),
			'eventsUnavailable' => __( 'Firewall event records are currently unavailable.', 'secure-login-guard' ),
			'utcTime' => __( 'UTC time', 'secure-login-guard' ),
			'ipFingerprint' => __( 'IP fingerprint', 'secure-login-guard' ),
			'method' => __( 'Method', 'secure-login-guard' ),
			'path' => __( 'Path', 'secure-login-guard' ),
			'rule' => __( 'Rule', 'secure-login-guard' ),
			'privacyNote' => __( 'Request bodies, header values, and raw IP addresses are not stored. IP fingerprints are keyed hashes for correlation.', 'secure-login-guard' ),
			'backupFolder' => __( 'Private backup directory:', 'secure-login-guard' ),
		);
	}

	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = self::settings();
		$captcha_configured = ! empty( $settings['captcha_site_key'] ) && ! empty( $settings['captcha_secret_key'] );
		$backup_status = get_option( 'slg_backup_last_result', array() );
		$backup_label = is_array( $backup_status ) && ! empty( $backup_status['success'] )
			? __( 'Backup healthy', 'secure-login-guard' )
			: __( 'Backup needs attention', 'secure-login-guard' );
		?>
		<div id="slg-dashboard-root" class="wrap slg-dashboard"><p><?php esc_html_e( 'The dashboard could not load. Reload the page or enable JavaScript.', 'secure-login-guard' ); ?></p></div>
		<noscript>
		<div class="wrap slg-dashboard">
			<header class="slg-header">
				<div>
					<p class="slg-eyebrow"><?php esc_html_e( 'SITE SECURITY', 'secure-login-guard' ); ?></p>
					<h1><?php esc_html_e( 'Security Guard', 'secure-login-guard' ); ?></h1>
					<p><?php esc_html_e( 'Your site protection at a glance. Review status and manage your security controls below.', 'secure-login-guard' ); ?></p>
				</div>
				<span class="slg-version"><?php esc_html_e( 'MVP 0.3.2', 'secure-login-guard' ); ?></span>
			</header>

			<div class="slg-status-grid" aria-label="<?php esc_attr_e( 'Security status overview', 'secure-login-guard' ); ?>">
				<a class="slg-status-card" href="#slg-protection">
					<span class="slg-status-icon slg-icon-shield" aria-hidden="true">S</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Request firewall', 'secure-login-guard' ); ?></strong><span><?php echo ! empty( $settings['firewall_enabled'] ) ? esc_html__( 'Active', 'secure-login-guard' ) : esc_html__( 'Disabled', 'secure-login-guard' ); ?></span></span>
					<span class="slg-status-dot <?php echo ! empty( $settings['firewall_enabled'] ) ? 'is-good' : 'is-muted'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-protection">
					<span class="slg-status-icon slg-icon-captcha" aria-hidden="true">C</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'CAPTCHA', 'secure-login-guard' ); ?></strong><span><?php echo $captcha_configured ? esc_html__( 'Turnstile configured', 'secure-login-guard' ) : esc_html__( 'Setup recommended', 'secure-login-guard' ); ?></span></span>
					<span class="slg-status-dot <?php echo $captcha_configured ? 'is-good' : 'is-warning'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-backups">
					<span class="slg-status-icon slg-icon-backup" aria-hidden="true">B</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Backups', 'secure-login-guard' ); ?></strong><span><?php echo esc_html( $backup_label ); ?></span></span>
					<span class="slg-status-dot <?php echo is_array( $backup_status ) && ! empty( $backup_status['success'] ) ? 'is-good' : 'is-warning'; ?>"></span>
				</a>
				<a class="slg-status-card" href="#slg-two-factor">
					<span class="slg-status-icon slg-icon-2fa" aria-hidden="true">2F</span>
					<span class="slg-status-copy"><strong><?php esc_html_e( 'Two-factor auth', 'secure-login-guard' ); ?></strong><span><?php esc_html_e( 'User-managed', 'secure-login-guard' ); ?></span></span>
					<span class="slg-status-dot is-info"></span>
				</a>
			</div>

			<nav class="slg-nav" aria-label="<?php esc_attr_e( 'Dashboard sections', 'secure-login-guard' ); ?>">
				<a href="#slg-protection"><?php esc_html_e( 'Protection', 'secure-login-guard' ); ?></a>
				<a href="#slg-two-factor"><?php esc_html_e( 'Two-factor', 'secure-login-guard' ); ?></a>
				<a href="#slg-backups"><?php esc_html_e( 'Backups', 'secure-login-guard' ); ?></a>
				<a href="#slg-audit"><?php esc_html_e( 'Security checks', 'secure-login-guard' ); ?></a>
				<a href="#slg-events"><?php esc_html_e( 'Firewall events', 'secure-login-guard' ); ?></a>
			</nav>

			<section class="slg-panel" id="slg-protection">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'ACCESS & PREVENTION', 'secure-login-guard' ); ?></p><h2><?php esc_html_e( 'Protection settings', 'secure-login-guard' ); ?></h2></div>
					<p><?php esc_html_e( 'Tune login safeguards and spam prevention.', 'secure-login-guard' ); ?></p>
				</div>
			<form action="options.php" method="post">
				<?php settings_fields( 'secure_login_guard' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="slg-failures-per-login"><?php esc_html_e( 'Failures per username and IP', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-failures-per-login" type="number" min="3" max="20" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[failures_per_login]" value="<?php echo esc_attr( $settings['failures_per_login'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-failures-per-ip"><?php esc_html_e( 'Failures per IP address', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-failures-per-ip" type="number" min="10" max="100" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[failures_per_ip]" value="<?php echo esc_attr( $settings['failures_per_ip'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-window-minutes"><?php esc_html_e( 'Counting window (minutes)', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-window-minutes" type="number" min="5" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[window_minutes]" value="<?php echo esc_attr( $settings['window_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-lockout-minutes"><?php esc_html_e( 'Lockout duration (minutes)', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-lockout-minutes" type="number" min="1" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[lockout_minutes]" value="<?php echo esc_attr( $settings['lockout_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-inactivity-minutes"><?php esc_html_e( 'Inactivity logout (minutes)', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-inactivity-minutes" type="number" min="5" max="1440" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[inactivity_minutes]" value="<?php echo esc_attr( $settings['inactivity_minutes'] ); ?>" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-password-length"><?php esc_html_e( 'Minimum password length', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-password-length" type="number" min="10" max="64" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[minimum_password_length]" value="<?php echo esc_attr( $settings['minimum_password_length'] ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'New or changed passwords must meet this length and include at least three character classes: lowercase, uppercase, number, or symbol.', 'secure-login-guard' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Request firewall', 'secure-login-guard' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[firewall_enabled]" value="1" <?php checked( $settings['firewall_enabled'], 1 ); ?>> <?php esc_html_e( 'Inspect requests and temporarily block high-confidence malicious patterns', 'secure-login-guard' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-turnstile-site-key"><?php esc_html_e( 'Cloudflare Turnstile site key', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-turnstile-site-key" type="text" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[captcha_site_key]" value="<?php echo esc_attr( $settings['captcha_site_key'] ); ?>" class="regular-text" autocomplete="off"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-turnstile-secret-key"><?php esc_html_e( 'Cloudflare Turnstile secret key', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-turnstile-secret-key" type="password" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[captcha_secret_key]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr( $settings['captcha_secret_key'] ? __( 'Configured; leave blank to keep current key', 'secure-login-guard' ) : __( 'Not configured', 'secure-login-guard' ) ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="slg-backup-retention"><?php esc_html_e( 'Scheduled backup retention', 'secure-login-guard' ); ?></label></th>
						<td><input id="slg-backup-retention" type="number" min="1" max="30" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[backup_retention]" value="<?php echo esc_attr( $settings['backup_retention'] ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Keep this many successful database + file backup archives.', 'secure-login-guard' ); ?></p></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<p class="description"><?php esc_html_e( 'The IP address is taken only from the web server REMOTE_ADDR value. If your site is behind a proxy, configure the proxy/web server to set this value correctly; forwarded headers are intentionally not trusted.', 'secure-login-guard' ); ?></p>
			</section>

			<section class="slg-panel" id="slg-two-factor">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'ACCOUNT SECURITY', 'secure-login-guard' ); ?></p><h2><?php esc_html_e( 'Two-factor authentication', 'secure-login-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Per user', 'secure-login-guard' ); ?></span>
				</div>
			<p><?php esc_html_e( 'Users can enable authenticator-app TOTP (compatible with Google Authenticator and Microsoft Authenticator) and recovery codes from their own profile under Users > Profile. Email OTP is available as a fallback for users with TOTP enabled.', 'secure-login-guard' ); ?></p>
			<p><?php esc_html_e( 'SMS OTP is not included because it requires a provider account, credentials, and delivery policy.', 'secure-login-guard' ); ?></p>
			</section>

			<section class="slg-panel" id="slg-backups">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'RECOVERY', 'secure-login-guard' ); ?></p><h2><?php esc_html_e( 'Backups and disaster recovery', 'secure-login-guard' ); ?></h2></div>
					<span class="slg-pill <?php echo is_array( $backup_status ) && ! empty( $backup_status['success'] ) ? 'slg-pill-good' : 'slg-pill-warning'; ?>"><?php echo esc_html( $backup_label ); ?></span>
				</div>
			<p><?php esc_html_e( 'Weekly database + file backups are scheduled with WordPress Cron. Archives are kept in a private directory outside the web root; the plugin will report an error rather than use a public folder if secure storage is unavailable.', 'secure-login-guard' ); ?></p>
			<?php Secure_Login_Guard_Backups::render_admin_section(); ?>
			<p><?php esc_html_e( 'Manual database-only download is also available. Backups contain sensitive data. Test restoration and keep a separate off-site copy.', 'secure-login-guard' ); ?></p>
			<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
				<input type="hidden" name="action" value="slg_download_backup">
				<?php wp_nonce_field( 'slg_download_backup' ); ?>
				<?php submit_button( __( 'Download database backup', 'secure-login-guard' ), 'secondary', 'submit', false ); ?>
			</form>
			</section>

			<section class="slg-panel" id="slg-audit">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'SITE HEALTH', 'secure-login-guard' ); ?></p><h2><?php esc_html_e( 'Security checks', 'secure-login-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Report only', 'secure-login-guard' ); ?></span>
				</div>
			<p><?php esc_html_e( 'These checks report configuration signals; they do not change permissions, database settings, or block traffic. Ask your host before changing server-level settings.', 'secure-login-guard' ); ?></p>
			<?php self::render_security_checks(); ?>
			<h3><?php esc_html_e( 'Stored content scan', 'secure-login-guard' ); ?></h3>
			<p><?php esc_html_e( 'On-demand scan of core posts, comments, and options for a small set of suspicious SQL/XSS markers. Results are advisory and show fingerprints, not stored content.', 'secure-login-guard' ); ?></p>
			<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
				<input type="hidden" name="action" value="slg_scan_database">
				<?php wp_nonce_field( 'slg_scan_database' ); ?>
				<?php submit_button( __( 'Scan core database content', 'secure-login-guard' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php self::render_database_scan_results(); ?>
			</section>

			<section class="slg-panel" id="slg-events">
				<div class="slg-panel-heading">
					<div><p class="slg-eyebrow"><?php esc_html_e( 'MONITORING', 'secure-login-guard' ); ?></p><h2><?php esc_html_e( 'Firewall events', 'secure-login-guard' ); ?></h2></div>
					<span class="slg-pill slg-pill-info"><?php esc_html_e( 'Recent activity', 'secure-login-guard' ); ?></span>
				</div>
			<?php Secure_Login_Guard_Firewall::render_admin_log(); ?>
			</section>
		</div>
		</noscript>
		<?php
	}

	public static function render_login_2fa_field() {
		?>
		<p>
			<label for="slg-totp-code"><?php esc_html_e( 'Authenticator or recovery code', 'secure-login-guard' ); ?><br>
				<input type="text" name="slg_totp_code" id="slg-totp-code" class="input" value="" autocomplete="one-time-code" inputmode="numeric">
			</label>
		</p>
		<p class="description"><?php esc_html_e( 'Enter an authenticator or recovery code. Leave blank to receive a one-time email code if email delivery is available.', 'secure-login-guard' ); ?></p>
		<?php
	}

	public static function check_two_factor( $user, $username, $password ) {
		unset( $username, $password );

		if (
			! $user instanceof WP_User
			|| ! isset( $_POST['log'], $_POST['pwd'] )
			|| ! get_user_meta( $user->ID, 'slg_2fa_enabled', true )
		) {
			return $user;
		}

		$code = self::posted_text( 'slg_totp_code' );
		$secret = get_user_meta( $user->ID, 'slg_2fa_secret', true );
		$step = self::verify_totp( $secret, $code );

		if ( false !== $step ) {
			$last_step = absint( get_user_meta( $user->ID, 'slg_2fa_last_step', true ) );
			if ( $step <= $last_step ) {
				return new WP_Error( 'slg_2fa_reused', __( 'That authentication code has already been used. Please try the next code.', 'secure-login-guard' ) );
			}
			update_user_meta( $user->ID, 'slg_2fa_last_step', $step );
			return $user;
		}

		if ( self::consume_recovery_code( $user->ID, $code ) || self::verify_email_otp( $user->ID, $code ) ) {
			return $user;
		}

		if ( '' === $code ) {
			$sent = self::issue_email_otp( $user );
			if ( is_wp_error( $sent ) ) {
				return $sent;
			}
			return new WP_Error( 'slg_email_otp_sent', __( 'A one-time code was sent to the email address on your account. Enter it with your password to continue.', 'secure-login-guard' ) );
		}

		return new WP_Error( 'slg_2fa_invalid', __( 'The authenticator or recovery code was not accepted.', 'secure-login-guard' ) );
	}

	private static function issue_email_otp( $user ) {
		$cooldown_key = 'slg_email_cooldown_' . absint( $user->ID );
		if ( get_transient( $cooldown_key ) ) {
			return new WP_Error( 'slg_email_otp_cooldown', __( 'A code was sent recently. Check your email and wait before requesting another.', 'secure-login-guard' ) );
		}
		$code = (string) random_int( 100000, 999999 );
		$sent = wp_mail(
			$user->user_email,
			__( 'Your Security Guard sign-in code', 'secure-login-guard' ),
			sprintf(
				/* translators: %s is a one-time login code. */
				__( 'Your one-time sign-in code is %s. It expires in 10 minutes. If you did not try to sign in, you can ignore this email.', 'secure-login-guard' ),
				$code
			)
		);
		if ( ! $sent ) {
			return new WP_Error( 'slg_email_otp_delivery_failed', __( 'The one-time code could not be emailed. Use your authenticator or recovery code, or contact the site administrator.', 'secure-login-guard' ) );
		}
		set_transient(
			'slg_email_otp_' . absint( $user->ID ),
			array(
				'hash' => wp_hash_password( $code ),
				'attempts' => 0,
				'expires' => time() + 10 * MINUTE_IN_SECONDS,
			),
			10 * MINUTE_IN_SECONDS
		);
		set_transient( $cooldown_key, 1, MINUTE_IN_SECONDS );
		return true;
	}

	private static function posted_text( $key ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) {
			return '';
		}
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}

	private static function verify_email_otp( $user_id, $code ) {
		if ( ! is_string( $code ) || ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}
		$key = 'slg_email_otp_' . absint( $user_id );
		$record = get_transient( $key );
		if (
			! is_array( $record )
			|| ! isset( $record['hash'], $record['attempts'], $record['expires'] )
			|| absint( $record['attempts'] ) >= 5
			|| absint( $record['expires'] ) <= time()
		) {
			delete_transient( $key );
			return false;
		}
		if ( wp_check_password( $code, $record['hash'] ) ) {
			delete_transient( $key );
			return true;
		}
		$record['attempts'] = absint( $record['attempts'] ) + 1;
		set_transient( $key, $record, max( 1, absint( $record['expires'] ) - time() ) );
		return false;
	}

	public static function render_captcha_field() {
		$settings = self::settings();
		if ( empty( $settings['captcha_site_key'] ) || empty( $settings['captcha_secret_key'] ) ) {
			return;
		}
		?>
		<div class="cf-turnstile" data-sitekey="<?php echo esc_attr( $settings['captcha_site_key'] ); ?>"></div>
		<?php
	}

	public static function enqueue_captcha_script() {
		$settings = self::settings();
		if ( ! empty( $settings['captcha_site_key'] ) && ! empty( $settings['captcha_secret_key'] ) ) {
			wp_enqueue_script( 'slg-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true );
		}
	}

	public static function check_login_captcha( $user, $username, $password ) {
		unset( $username, $password );
		if ( ! $user instanceof WP_User || ! isset( $_POST['log'], $_POST['pwd'] ) ) {
			return $user;
		}
		$check = self::verify_captcha();
		return is_wp_error( $check ) ? $check : $user;
	}

	public static function validate_registration_captcha( $errors, $sanitized_user_login, $user_email ) {
		unset( $sanitized_user_login, $user_email );
		$check = self::verify_captcha();
		if ( is_wp_error( $check ) ) {
			$errors->add( 'slg_registration_captcha', $check->get_error_message() );
		}
		if ( '' !== self::posted_text( 'slg_registration_website' ) ) {
			$errors->add( 'slg_registration_honeypot', __( 'Registration could not be accepted.', 'secure-login-guard' ) );
		}
		return $errors;
	}

	public static function check_comment_captcha( $commentdata ) {
		if ( ! isset( $_POST['comment_post_ID'] ) ) {
			return $commentdata;
		}
		$check = self::verify_captcha();
		if ( is_wp_error( $check ) ) {
			wp_die( esc_html( $check->get_error_message() ), '', array( 'response' => 403 ) );
		}
		return $commentdata;
	}

	public static function render_registration_honeypot() {
		?>
		<p aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden;">
			<label for="slg-registration-website"><?php esc_html_e( 'Leave this field empty', 'secure-login-guard' ); ?></label>
			<input type="text" id="slg-registration-website" name="slg_registration_website" value="" tabindex="-1" autocomplete="off">
		</p>
		<?php
	}

	private static function verify_captcha() {
		$settings = self::settings();
		if ( empty( $settings['captcha_site_key'] ) || empty( $settings['captcha_secret_key'] ) ) {
			return true;
		}
		$token = self::posted_text( 'cf-turnstile-response' );
		if ( '' === $token ) {
			return new WP_Error( 'slg_captcha_missing', __( 'Complete the CAPTCHA challenge to continue.', 'secure-login-guard' ) );
		}
		$request_body = array(
			'secret' => $settings['captcha_secret_key'],
			'response' => $token,
		);
		$ip = self::client_ip();
		if ( 'unknown' !== $ip ) {
			$request_body['remoteip'] = $ip;
		}
		$response = wp_remote_post(
			'https://challenges.cloudflare.com/turnstile/v0/siteverify',
			array(
				'timeout' => 5,
				'body' => $request_body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'slg_captcha_unavailable', __( 'CAPTCHA verification is unavailable. Please try again later.', 'secure-login-guard' ) );
		}
		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'slg_captcha_unavailable', __( 'CAPTCHA verification is unavailable. Please try again later.', 'secure-login-guard' ) );
		}
		$result = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $result ) || empty( $result['success'] ) ) {
			return new WP_Error( 'slg_captcha_invalid', __( 'CAPTCHA verification failed. Please try again.', 'secure-login-guard' ) );
		}
		$expected_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$verified_host = isset( $result['hostname'] ) ? strtolower( (string) $result['hostname'] ) : '';
		if ( '' === $expected_host || ! hash_equals( $expected_host, $verified_host ) ) {
			return new WP_Error( 'slg_captcha_invalid', __( 'CAPTCHA verification failed. Please try again.', 'secure-login-guard' ) );
		}
		return true;
	}

	public static function render_2fa_profile( $user ) {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		$enabled = (bool) get_user_meta( $user->ID, 'slg_2fa_enabled', true );
		$pending_secret = get_user_meta( $user->ID, 'slg_2fa_pending_secret', true );
		$recovery_codes = get_transient( 'slg_recovery_show_' . absint( $user->ID ) );
		if ( false !== $recovery_codes ) {
			delete_transient( 'slg_recovery_show_' . absint( $user->ID ) );
		}
		?>
		<h2><?php esc_html_e( 'Security Guard: Two-factor authentication', 'secure-login-guard' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><?php esc_html_e( 'Authenticator app', 'secure-login-guard' ); ?></th>
				<td>
					<?php if ( $enabled ) : ?>
						<p><?php esc_html_e( 'Two-factor authentication is enabled for this account.', 'secure-login-guard' ); ?></p>
						<p><label for="slg-manage-code"><?php esc_html_e( 'Current authenticator or recovery code (required for your own account)', 'secure-login-guard' ); ?></label>
							<input type="text" id="slg-manage-code" name="slg_2fa_manage_code" autocomplete="one-time-code"></p>
					<?php elseif ( $pending_secret ) : ?>
						<p><?php esc_html_e( 'Add this secret to a TOTP-compatible authenticator app, then enter a current code to finish setup.', 'secure-login-guard' ); ?></p>
						<p><code><?php echo esc_html( $pending_secret ); ?></code></p>
						<p><label for="slg-confirm-code"><?php esc_html_e( 'Authenticator code', 'secure-login-guard' ); ?></label>
							<input type="text" id="slg-confirm-code" name="slg_2fa_code" inputmode="numeric" autocomplete="one-time-code"></p>
					<?php else : ?>
						<p><?php esc_html_e( 'Not enabled.', 'secure-login-guard' ); ?></p>
					<?php endif; ?>
					<?php if ( is_array( $recovery_codes ) && $recovery_codes ) : ?>
						<div class="notice notice-warning inline"><p><?php esc_html_e( 'Save these recovery codes now. They are shown only once.', 'secure-login-guard' ); ?></p>
							<p><code><?php echo esc_html( implode( '  ', $recovery_codes ) ); ?></code></p></div>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php wp_nonce_field( 'slg_2fa_' . $user->ID, 'slg_2fa_nonce' ); ?>
		<?php if ( $enabled ) : ?>
			<p><button type="submit" class="button" name="slg_2fa_action" value="regenerate"><?php esc_html_e( 'Generate new recovery codes', 'secure-login-guard' ); ?></button>
				<button type="submit" class="button" name="slg_2fa_action" value="disable"><?php esc_html_e( 'Disable two-factor authentication', 'secure-login-guard' ); ?></button></p>
		<?php elseif ( $pending_secret ) : ?>
			<p><button type="submit" class="button button-primary" name="slg_2fa_action" value="confirm"><?php esc_html_e( 'Confirm and enable two-factor authentication', 'secure-login-guard' ); ?></button>
				<button type="submit" class="button" name="slg_2fa_action" value="cancel"><?php esc_html_e( 'Cancel setup', 'secure-login-guard' ); ?></button></p>
		<?php else : ?>
			<p><button type="submit" class="button" name="slg_2fa_action" value="start"><?php esc_html_e( 'Set up two-factor authentication', 'secure-login-guard' ); ?></button></p>
		<?php endif; ?>
		<?php
	}

	public static function save_2fa_profile( $user_id ) {
		if ( empty( $_POST['slg_2fa_action'] ) || ! is_string( $_POST['slg_2fa_action'] ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_user', $user_id ) || ! isset( $_POST['slg_2fa_nonce'] ) ) {
			return;
		}
		check_admin_referer( 'slg_2fa_' . $user_id, 'slg_2fa_nonce' );

		$action = sanitize_key( wp_unslash( $_POST['slg_2fa_action'] ) );

		if (
			$user_id === get_current_user_id()
			&& get_user_meta( $user_id, 'slg_2fa_enabled', true )
			&& in_array( $action, array( 'disable', 'regenerate' ), true )
			&& ! self::verify_user_2fa_code( $user_id, self::posted_text( 'slg_2fa_manage_code' ) )
		) {
			return;
		}

		if ( 'start' === $action && ! get_user_meta( $user_id, 'slg_2fa_enabled', true ) ) {
			update_user_meta( $user_id, 'slg_2fa_pending_secret', self::base32_encode( random_bytes( 20 ) ) );
		} elseif ( 'confirm' === $action ) {
			$secret = get_user_meta( $user_id, 'slg_2fa_pending_secret', true );
			$code = self::posted_text( 'slg_2fa_code' );
			$step = self::verify_totp( $secret, $code );
			if ( false !== $step ) {
				update_user_meta( $user_id, 'slg_2fa_secret', $secret );
				update_user_meta( $user_id, 'slg_2fa_enabled', 1 );
				update_user_meta( $user_id, 'slg_2fa_last_step', $step );
				delete_user_meta( $user_id, 'slg_2fa_pending_secret' );
				self::create_recovery_codes( $user_id );
			}
		} elseif ( 'disable' === $action ) {
			delete_user_meta( $user_id, 'slg_2fa_enabled' );
			delete_user_meta( $user_id, 'slg_2fa_secret' );
			delete_user_meta( $user_id, 'slg_2fa_recovery_codes' );
			delete_user_meta( $user_id, 'slg_2fa_last_step' );
		} elseif ( 'cancel' === $action ) {
			delete_user_meta( $user_id, 'slg_2fa_pending_secret' );
		} elseif ( 'regenerate' === $action && get_user_meta( $user_id, 'slg_2fa_enabled', true ) ) {
			self::create_recovery_codes( $user_id );
		}
	}

	private static function verify_user_2fa_code( $user_id, $code ) {
		$step = self::verify_totp( get_user_meta( $user_id, 'slg_2fa_secret', true ), $code );
		if ( false !== $step ) {
			$last_step = absint( get_user_meta( $user_id, 'slg_2fa_last_step', true ) );
			if ( $step <= $last_step ) {
				return false;
			}
			update_user_meta( $user_id, 'slg_2fa_last_step', $step );
			return true;
		}
		return self::consume_recovery_code( $user_id, $code );
	}

	private static function create_recovery_codes( $user_id ) {
		$codes = array();
		$hashes = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$code = strtoupper( bin2hex( random_bytes( 6 ) ) );
			$codes[] = $code;
			$hashes[] = wp_hash_password( $code );
		}
		update_user_meta( $user_id, 'slg_2fa_recovery_codes', $hashes );
		set_transient( 'slg_recovery_show_' . absint( $user_id ), $codes, 5 * MINUTE_IN_SECONDS );
	}

	private static function consume_recovery_code( $user_id, $code ) {
		$code = strtoupper( preg_replace( '/[^A-F0-9]/', '', $code ) );
		if ( 12 !== strlen( $code ) ) {
			return false;
		}
		$hashes = get_user_meta( $user_id, 'slg_2fa_recovery_codes', true );
		if ( ! is_array( $hashes ) ) {
			return false;
		}
		foreach ( $hashes as $index => $hash ) {
			if ( wp_check_password( $code, $hash ) ) {
				unset( $hashes[ $index ] );
				update_user_meta( $user_id, 'slg_2fa_recovery_codes', array_values( $hashes ) );
				return true;
			}
		}
		return false;
	}

	private static function valid_user_2fa_code( $user_id, $code ) {
		$step = self::verify_totp( get_user_meta( $user_id, 'slg_2fa_secret', true ), $code );
		if ( false !== $step ) {
			return $step > absint( get_user_meta( $user_id, 'slg_2fa_last_step', true ) );
		}
		$normalized = strtoupper( preg_replace( '/[^A-F0-9]/', '', $code ) );
		$hashes = get_user_meta( $user_id, 'slg_2fa_recovery_codes', true );
		if ( 12 !== strlen( $normalized ) || ! is_array( $hashes ) ) {
			return false;
		}
		foreach ( $hashes as $hash ) {
			if ( wp_check_password( $normalized, $hash ) ) {
				return true;
			}
		}
		return false;
	}

	private static function verify_totp( $secret, $code ) {
		$code = preg_replace( '/\s+/', '', (string) $code );
		if ( ! is_string( $secret ) || '' === $secret || ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}
		$binary_secret = self::base32_decode( $secret );
		if ( false === $binary_secret || '' === $binary_secret ) {
			return false;
		}
		$current_step = (int) floor( time() / 30 );
		for ( $offset = -1; $offset <= 1; $offset++ ) {
			$step = $current_step + $offset;
			if ( $step < 0 ) {
				continue;
			}
			$counter = pack( 'N2', 0, $step );
			$hash = hash_hmac( 'sha1', $counter, $binary_secret, true );
			$offset_byte = ord( $hash[19] ) & 0x0f;
			$number = ( ( ord( $hash[ $offset_byte ] ) & 0x7f ) << 24 )
				| ( ( ord( $hash[ $offset_byte + 1 ] ) & 0xff ) << 16 )
				| ( ( ord( $hash[ $offset_byte + 2 ] ) & 0xff ) << 8 )
				| ( ord( $hash[ $offset_byte + 3 ] ) & 0xff );
			if ( hash_equals( sprintf( '%06d', $number % 1000000 ), $code ) ) {
				return $step;
			}
		}
		return false;
	}

	private static function base32_encode( $data ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$bits = '';
		foreach ( str_split( $data ) as $character ) {
			$bits .= str_pad( decbin( ord( $character ) ), 8, '0', STR_PAD_LEFT );
		}
		$encoded = '';
		foreach ( str_split( $bits, 5 ) as $chunk ) {
			if ( strlen( $chunk ) < 5 ) {
				$chunk = str_pad( $chunk, 5, '0', STR_PAD_RIGHT );
			}
			$encoded .= $alphabet[ bindec( $chunk ) ];
		}
		return $encoded;
	}

	private static function base32_decode( $encoded ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$encoded = strtoupper( rtrim( $encoded, '=' ) );
		$bits = '';
		foreach ( str_split( $encoded ) as $character ) {
			$value = strpos( $alphabet, $character );
			if ( false === $value ) {
				return false;
			}
			$bits .= str_pad( decbin( $value ), 5, '0', STR_PAD_LEFT );
		}
		$decoded = '';
		foreach ( str_split( $bits, 8 ) as $byte ) {
			if ( 8 === strlen( $byte ) ) {
				$decoded .= chr( bindec( $byte ) );
			}
		}
		return $decoded;
	}

	public static function validate_registration_password( $errors, $sanitized_user_login, $user_email ) {
		unset( $sanitized_user_login, $user_email );
		$password = isset( $_POST['user_pass'] ) ? wp_unslash( $_POST['user_pass'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
		return $errors;
	}

	public static function validate_profile_password( $errors, $update, $user ) {
		$password = isset( $_POST['pass1'] ) ? wp_unslash( $_POST['pass1'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
		if ( empty( $_POST['slg_2fa_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['slg_2fa_action'] ) );
		if ( 'confirm' === $action ) {
			$secret = get_user_meta( $user->ID, 'slg_2fa_pending_secret', true );
			$code = self::posted_text( 'slg_2fa_code' );
			if ( false === self::verify_totp( $secret, $code ) ) {
				$errors->add( 'slg_2fa_invalid_setup_code', __( 'Enter a valid code from your authenticator app to enable two-factor authentication.', 'secure-login-guard' ) );
			}
		} elseif (
			$user->ID === get_current_user_id()
			&& get_user_meta( $user->ID, 'slg_2fa_enabled', true )
			&& in_array( $action, array( 'disable', 'regenerate' ), true )
		) {
			$code = self::posted_text( 'slg_2fa_manage_code' );
			if ( ! self::valid_user_2fa_code( $user->ID, $code ) ) {
				$errors->add( 'slg_2fa_invalid_manage_code', __( 'Enter a valid, unused authenticator or recovery code to change two-factor settings.', 'secure-login-guard' ) );
			}
		}
	}

	public static function validate_reset_password( $errors, $user ) {
		unset( $user );
		$password = isset( $_POST['pass1'] ) ? wp_unslash( $_POST['pass1'] ) : '';
		if ( '' !== $password && ! self::strong_password( $password ) ) {
			$errors->add( 'slg_weak_password', self::password_error_message() );
		}
	}

	private static function strong_password( $password ) {
		if ( ! is_string( $password ) ) {
			return false;
		}
		$length = preg_match_all( '/./us', $password, $matches );
		$length = false === $length ? strlen( $password ) : $length;
		if ( $length < absint( self::settings()['minimum_password_length'] ) ) {
			return false;
		}
		$classes = 0;
		$classes += (bool) preg_match( '/[a-z]/', $password );
		$classes += (bool) preg_match( '/[A-Z]/', $password );
		$classes += (bool) preg_match( '/[0-9]/', $password );
		$classes += (bool) preg_match( '/[^a-zA-Z0-9]/', $password );
		return $classes >= 3;
	}

	private static function password_error_message() {
		return sprintf(
			/* translators: %d is the configured minimum password length. */
			__( 'Choose a password with at least %d characters and at least three of these: lowercase, uppercase, number, or symbol.', 'secure-login-guard' ),
			absint( self::settings()['minimum_password_length'] )
		);
	}

	public static function render_comment_honeypot() {
		?>
		<p aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden;">
			<label for="slg-website"><?php esc_html_e( 'Leave this field empty', 'secure-login-guard' ); ?></label>
			<input type="text" id="slg-website" name="slg_website" value="" tabindex="-1" autocomplete="off">
		</p>
		<?php
	}

	public static function mark_honeypot_comment_as_spam( $approved, $commentdata ) {
		unset( $commentdata );
		if ( '' !== self::posted_text( 'slg_website' ) ) {
			return 'spam';
		}
		return $approved;
	}

	public static function enqueue_inactivity_script() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$timeout = absint( self::settings()['inactivity_minutes'] ) * MINUTE_IN_SECONDS;
		wp_register_script( 'slg-inactivity', plugins_url( 'assets/inactivity.js', __FILE__ ), array(), '0.3.2', true );
		wp_enqueue_script( 'slg-inactivity' );
		wp_localize_script(
			'slg-inactivity',
			'SLGActivity',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'slg_activity' ),
				'timeoutMs' => $timeout * 1000,
				'loginUrl' => wp_login_url(),
				'warningText' => __( 'You will be signed out soon due to inactivity. Move the pointer or press a key to stay signed in.', 'secure-login-guard' ),
			)
		);
	}

	public static function record_activity() {
		check_ajax_referer( 'slg_activity', 'nonce' );
		$user_id = get_current_user_id();
		$token = wp_get_session_token();
		if ( ! $user_id || '' === $token ) {
			wp_send_json_error( array( 'message' => 'No active session.' ), 401 );
		}
		$key = self::session_activity_key( $user_id, $token );
		$now = time();
		$timeout = absint( self::settings()['inactivity_minutes'] ) * MINUTE_IN_SECONDS;
		$last_activity = get_transient( $key );
		if ( false !== $last_activity && $now - absint( $last_activity ) >= $timeout ) {
			delete_transient( $key );
			wp_logout();
			wp_send_json_success( array( 'logout' => true ) );
		}
		if ( false === $last_activity || '1' === self::posted_text( 'active' ) ) {
			set_transient( $key, $now, YEAR_IN_SECONDS );
		}
		wp_send_json_success( array( 'logout' => false ) );
	}

	private static function session_activity_key( $user_id, $token ) {
		return 'slg_act_' . hash_hmac( 'sha256', absint( $user_id ) . '|' . $token, wp_salt( 'auth' ) );
	}

	public static function download_database_backup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to download this backup.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_download_backup' );
		global $wpdb;

		nocache_headers();
		header( 'Content-Type: application/sql; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wordpress-database-' . gmdate( 'Y-m-d-His' ) . '.sql"' );
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		echo "-- Database backup generated by Security Guard.\n";
		echo "-- Contains sensitive site data. Store securely.\n\n";
		echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		if ( ! is_array( $tables ) ) {
			wp_die( esc_html__( 'Could not list database tables for backup.', 'secure-login-guard' ) );
		}
		foreach ( $tables as $table ) {
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			$create = $wpdb->get_row( "SHOW CREATE TABLE {$table_sql}", ARRAY_N );
			if ( ! is_array( $create ) || ! isset( $create[1] ) ) {
				wp_die( esc_html__( 'Could not read a database table definition.', 'secure-login-guard' ) );
			}
			echo "\nDROP TABLE IF EXISTS {$table_sql};\n" . $create[1] . ";\n";
			$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table_sql}", 0 );
			if ( ! is_array( $columns ) || ! $columns ) {
				wp_die( esc_html__( 'Could not read the columns for a database table.', 'secure-login-guard' ) );
			}
			$column_sql = implode( ', ', array_map( static function ( $column ) {
				return '`' . str_replace( '`', '``', $column ) . '`';
			}, $columns ) );
			$offset = 0;
			do {
				$rows = $wpdb->get_results( "SELECT * FROM {$table_sql} LIMIT 200 OFFSET " . absint( $offset ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					wp_die( esc_html__( 'Could not read rows from a database table.', 'secure-login-guard' ) );
				}
				if ( ! is_array( $rows ) || ! $rows ) {
					break;
				}
				foreach ( $rows as $row ) {
					$values = array();
					foreach ( $columns as $column ) {
						$value = $row[ $column ];
						$values[] = null === $value ? 'NULL' : "'" . $wpdb->_real_escape( $value ) . "'";
					}
					echo 'INSERT INTO ' . $table_sql . ' (' . $column_sql . ') VALUES (' . implode( ', ', $values ) . ");\n";
				}
				$offset += count( $rows );
			} while ( count( $rows ) === 200 );
		}
		echo "\nSET FOREIGN_KEY_CHECKS=1;\n";
		exit;
	}

	public static function render_security_checks() {
		$checks = self::get_security_checks();

		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Check', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Result', 'secure-login-guard' ) . '</th></tr></thead><tbody>';
		foreach ( $checks as $check ) {
			echo '<tr><td>' . esc_html( $check['label'] ) . '</td><td>' . esc_html( $check['passed'] ? $check['success'] : $check['failure'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function get_security_checks() {
		global $wpdb;
		$checks = array();
		$checks[] = array( 'HTTPS for the site URL', 0 === strpos( home_url(), 'https://' ), 'HTTPS is enabled for the site URL.', 'Site URL is not HTTPS.' );
		$checks[] = array( 'XML-RPC exposure', ! apply_filters( 'xmlrpc_enabled', true ), 'XML-RPC is disabled by configuration.', 'XML-RPC appears enabled; disable it at the host or with a trusted security control if unused.' );
		$checks[] = array( 'Dashboard file editor', defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT, 'The built-in plugin/theme editor is disabled.', 'The built-in plugin/theme editor is available; consider defining DISALLOW_FILE_EDIT in wp-config.php.' );
		$checks[] = array( 'Debug mode', ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ), 'WordPress debug mode is off.', 'WP_DEBUG is enabled; avoid exposing debug output on a public site.' );
		$checks[] = self::permission_check( 'wp-content directory', WP_CONTENT_DIR );
		$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( untrailingslashit( ABSPATH ) ) . '/wp-config.php';
		$checks[] = self::permission_check( 'wp-config.php', $config );
		$ssl = $wpdb->get_row( "SHOW STATUS LIKE 'Ssl_cipher'", ARRAY_N );
		$checks[] = array( 'Database connection TLS', is_array( $ssl ) && ! empty( $ssl[1] ), 'A TLS cipher is reported for the database connection.', 'Database TLS was not detected or could not be confirmed; ask your host about encrypted DB connections.' );
		if ( 'wp_' === $wpdb->prefix ) {
			$checks[] = array( 'Database table prefix', false, 'A non-default table prefix is in use.', 'The default wp_ table prefix is in use. Changing it is operationally risky and is not a substitute for access controls.' );
		} else {
			$checks[] = array( 'Database table prefix', true, 'A non-default table prefix is in use.', 'The default wp_ table prefix is in use.' );
		}

		$result = array();
		foreach ( $checks as $check ) {
			$result[] = array(
				'label' => $check[0],
				'passed' => (bool) $check[1],
				'success' => $check[2],
				'failure' => $check[3],
			);
		}

		return $result;
	}

	public static function run_database_scan() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to scan the database.', 'secure-login-guard' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'slg_scan_database' );
		global $wpdb;
		$targets = array(
			array( $wpdb->posts, 'ID', array( 'post_title', 'post_content', 'post_excerpt' ) ),
			array( $wpdb->comments, 'comment_ID', array( 'comment_content' ) ),
			array( $wpdb->options, 'option_id', array( 'option_value' ) ),
			array( $wpdb->usermeta, 'umeta_id', array( 'meta_key', 'meta_value' ) ),
		);
		$markers = array(
			'xss_script_element' => '%<script%',
			'xss_javascript_url' => '%javascript:%',
			'xss_event_handler' => '%onerror=%',
			'sqli_union_select' => '%union select%',
			'sqli_system_schema' => '%information_schema%',
		);
		$results = array();
		$truncated = false;
		foreach ( $targets as $target ) {
			list( $table, $id_column, $columns ) = $target;
			$table_sql = '`' . str_replace( '`', '``', $table ) . '`';
			foreach ( $columns as $column ) {
				$column_sql = '`' . str_replace( '`', '``', $column ) . '`';
				$where = array();
				$values = array();
				foreach ( $markers as $marker ) {
					$where[] = "{$column_sql} LIKE %s";
					$values[] = $marker;
				}
				$query = "SELECT `" . str_replace( '`', '``', $id_column ) . "` AS row_id, {$column_sql} AS data FROM {$table_sql} WHERE (" . implode( ' OR ', $where ) . ') LIMIT 100';
				$rows = $wpdb->get_results( $wpdb->prepare( $query, $values ), ARRAY_A );
				if ( ! is_array( $rows ) ) {
					set_transient( 'slg_db_scan_' . get_current_user_id(), array( 'error' => __( 'The database scan could not read core content tables.', 'secure-login-guard' ) ), 10 * MINUTE_IN_SECONDS );
					wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) );
					exit;
				}
				foreach ( $rows as $row ) {
					$matched_rule = '';
					foreach ( $markers as $rule => $marker ) {
						if ( false !== stripos( isset( $row['data'] ) ? (string) $row['data'] : '', trim( $marker, '%' ) ) ) {
							$matched_rule = $rule;
							break;
						}
					}
					$results[] = array(
						'table' => $table,
						'row_id' => absint( $row['row_id'] ),
						'column' => $column,
						'rule' => $matched_rule ? $matched_rule : 'suspicious_marker',
						'fingerprint' => substr( hash( 'sha256', (string) $row['data'] ), 0, 16 ),
					);
					if ( count( $results ) >= 250 ) {
						$truncated = true;
						break 2;
					}
				}
			}
		}
		set_transient(
			'slg_db_scan_' . get_current_user_id(),
			array(
				'results' => $results,
				'truncated' => $truncated,
				'scanned_at' => current_time( 'mysql', true ),
			),
			10 * MINUTE_IN_SECONDS
		);
		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) );
		exit;
	}

	private static function get_database_scan_results( $consume = false ) {
		$key = 'slg_db_scan_' . get_current_user_id();
		$scan = get_transient( $key );
		if ( ! is_array( $scan ) ) {
			return null;
		}
		if ( $consume ) {
			delete_transient( $key );
		}

		return $scan;
	}

	private static function render_database_scan_results() {
		$scan = self::get_database_scan_results( true );
		if ( ! is_array( $scan ) ) {
			return;
		}
		if ( isset( $scan['error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $scan['error'] ) . '</p></div>';
			return;
		}
		echo '<p>' . esc_html( sprintf( __( 'Scan completed at %s UTC.', 'secure-login-guard' ), $scan['scanned_at'] ) ) . '</p>';
		if ( ! empty( $scan['truncated'] ) ) {
			echo '<p class="description">' . esc_html__( 'The display limit was reached; not all matching rows may be shown.', 'secure-login-guard' ) . '</p>';
		}
		if ( empty( $scan['results'] ) ) {
			echo '<p>' . esc_html__( 'No configured suspicious markers were found in the scanned core tables.', 'secure-login-guard' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Table', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Row', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Column', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Marker', 'secure-login-guard' ) . '</th><th>' . esc_html__( 'Fingerprint', 'secure-login-guard' ) . '</th></tr></thead><tbody>';
		foreach ( $scan['results'] as $result ) {
			echo '<tr><td>' . esc_html( $result['table'] ) . '</td><td>' . esc_html( $result['row_id'] ) . '</td><td>' . esc_html( $result['column'] ) . '</td><td>' . esc_html( $result['rule'] ) . '</td><td><code>' . esc_html( $result['fingerprint'] ) . '</code></td></tr>';
		}
		echo '</tbody></table><p class="description">' . esc_html__( 'Markers can appear in legitimate content. Review each row in context; this scan does not modify data.', 'secure-login-guard' ) . '</p>';
	}

	private static function permission_check( $label, $path ) {
		if ( ! file_exists( $path ) ) {
			return array( $label . ' permissions', false, '', 'Could not inspect this path; verify its location and permissions with your host.' );
		}
		$permissions = @fileperms( $path );
		if ( false === $permissions ) {
			return array( $label . ' permissions', false, '', 'Could not read permissions; verify them with your host.' );
		}
		$mode = $permissions & 0777;
		$recommended = 'wp-config.php' === $label ? '0600 or 0640' : ( is_dir( $path ) ? '0755 or 0750' : '0644 or 0640' );
		$group_or_world_writable = 0 !== ( $mode & 0022 );
		if ( $group_or_world_writable ) {
			return array( $label . ' permissions', false, '', sprintf( 'Current mode is %04o; review with your host. A typical target is %s. No automatic change was made.', $mode, $recommended ) );
		}
		return array( $label . ' permissions', true, sprintf( 'Current mode is %04o; typical target is %s.', $mode, $recommended ), '' );
	}

	public static function add_settings_link( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'options-general.php?page=' . self::SETTINGS_PAGE ) ),
			esc_html__( 'Settings', 'secure-login-guard' )
		);

		array_unshift( $links, $settings_link );
		return $links;
	}
}

register_activation_hook( __FILE__, array( 'Secure_Login_Guard', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Secure_Login_Guard', 'deactivate' ) );
Secure_Login_Guard::init();
