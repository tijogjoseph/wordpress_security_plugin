(function () {
	'use strict';

	var config = window.SLGActivity;
	if (!config) {
		return;
	}

	var hasActivity = true;
	var lastActivity = Date.now();
	var warning;

	function hideWarning() {
		if (warning) {
			warning.remove();
			warning = null;
		}
	}

	function recordLocalActivity() {
		hasActivity = true;
		lastActivity = Date.now();
		hideWarning();
	}

	[ 'pointerdown', 'keydown', 'touchstart', 'scroll' ].forEach( function ( eventName ) {
		document.addEventListener( eventName, recordLocalActivity, { passive: true } );
	} );

	function checkSession() {
		var idleFor = Date.now() - lastActivity;
		if ( idleFor >= config.timeoutMs - 60000 && idleFor < config.timeoutMs && ! warning ) {
			warning = document.createElement( 'div' );
			warning.setAttribute( 'role', 'status' );
			warning.textContent = config.warningText;
			warning.style.cssText = 'position:fixed;z-index:999999;top:0;left:0;right:0;padding:12px;background:#fff3cd;color:#332701;text-align:center';
			document.body.appendChild( warning );
		}

		var active = hasActivity;
		hasActivity = false;
		fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams( {
				action: 'slg_activity',
				nonce: config.nonce,
				active: active ? '1' : '0'
			} )
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( response ) {
				if ( response.success && response.data && response.data.logout ) {
					window.location = config.loginUrl;
				}
			} )
			.catch( function ( error ) {
				console.error( 'Security Guard could not check session activity.', error );
			} );
	}

	checkSession();
	window.setInterval( checkSession, 60000 );
})();
