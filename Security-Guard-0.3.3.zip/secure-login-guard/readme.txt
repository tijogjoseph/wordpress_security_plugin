=== Security Guard ===
Contributors: secure-login-guard
Tags: security, login, firewall, two-factor, backup, rate-limit
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.3.3
License: GPL-2.0-or-later

Adds login protection and site security checks to WordPress.

== Description ==

Features:

* Configurable failed-login rate limits by username/IP pair and by IP address.
* Optional per-user TOTP two-factor authentication and one-time recovery codes.
* Configurable inactivity logout for active browser sessions.
* Server-side password strength checks on WordPress registration, profile, and
  password-reset flows supported by core.
* A honeypot for comments made through the standard WordPress comment form.
* Cloudflare Turnstile for login, registration, and standard comment forms when keys are configured.
* Heuristic request filtering for common high-confidence SQL injection, XSS, traversal, and unsupported-method patterns.
* Temporary IP blocks and privacy-conscious firewall event records.
* Weekly database + site file ZIP backups, private local storage, and configurable retention.
* Manual database-only SQL download.
* Report-only file/database checks and an on-demand scan of common core content tables.
* Dashboard-style admin page with status cards and section navigation.

The admin dashboard UI uses React from WordPress's bundled `wp-element` package.
Security checks, settings validation, backup operations, and privileged actions
remain server-side in PHP; the dashboard submits through WordPress's Settings
API and authenticated admin-post handlers.

Login counters and temporary blocks are stored as WordPress transients.
Transient keys are HMAC-hashed. Firewall logs retain a keyed IP fingerprint,
request method, redacted path, rule code, and time; request bodies, raw IP
addresses, and header values are not logged.

== Installation ==

1. In WordPress, go to Plugins > Add New Plugin > Upload Plugin and select the
   installable secure-login-guard.zip package. The ZIP must contain the
   secure-login-guard folder at its top level, with
   secure-login-guard/secure-login-guard.php inside it.
   Alternatively, copy the secure-login-guard folder into wp-content/plugins/.
2. Activate Security Guard in the WordPress Plugins screen.
3. Configure limits and review checks under Settings > Security Guard.
4. Configure Turnstile keys under Settings > Security Guard to enable CAPTCHA.
5. Users may enable TOTP and generate recovery codes under Users > Profile.

== Important ==

The IP address is read only from the web server REMOTE_ADDR value. Forwarded
headers are not trusted because clients can spoof them. If the site is behind
a reverse proxy, configure the proxy/web server to provide the correct
REMOTE_ADDR value before enabling IP-based limits.

Sites behind a shared NAT may see multiple users sharing an IP-based limit.
Tune the limits to suit the site and ensure administrators have an alternative
recovery path before deployment.

Two-factor enrollment is optional per user. Users must save the recovery codes
shown after enrollment or regeneration; the codes are displayed once. Test
recovery before requiring 2FA operationally. TOTP requires the server clock to
be reasonably accurate. TOTP works with Google Authenticator, Microsoft
Authenticator, and compatible apps. Email OTP is offered as a fallback after
the password is verified. SMS OTP is not included because it requires a
third-party provider account and credentials.

Inactivity logout uses periodic authenticated browser requests and JavaScript
activity listeners, with a brief warning before logout. It requires JavaScript
and a browser tab on the site; a network failure is logged to the browser
console and prevents the activity check from completing.

Password checks require a configured minimum length (12 by default) and at
least three of lowercase, uppercase, number, and symbol. Passwords created by
custom plugins, external identity providers, or APIs may not use the core
flows covered by these checks.

The comment and registration honeypots apply to standard WordPress forms.
Turnstile verification is also applied to those forms once both keys are set.
Custom form plugins need their own spam controls.

Scheduled backups run weekly through WordPress Cron and include the database
and regular site files. WordPress Cron is traffic-triggered; low-traffic sites
should configure a real server cron to call wp-cron.php. The plugin requires
PHP ZipArchive and a writable private directory outside the web root, derived
from the server document root. It fails visibly rather than storing archives
in a public directory. The default retention is five successful archives;
cache files are excluded and sites above the 25,000-file MVP limit are refused.
Archives contain sensitive user data and site code. Download them securely,
keep an off-site copy, and test restoration. This MVP does not automate restore.

The request firewall uses bounded heuristic inspection of methods, headers,
URL parameters, and a limited portion of request bodies. It may block
legitimate requests containing script or SQL-like text and does not inspect
uploaded file contents. Review event records and disable the firewall if it
interferes with site content or plugins. It is not a replacement for a
maintained host/network WAF. Temporary IP blocks use only REMOTE_ADDR and can
affect users sharing a NAT; forwarded headers are never trusted.

File permissions are reported with typical targets, not changed automatically.
Database scanning is on-demand and limited to common WordPress posts,
comments, options, and user metadata; markers can occur in legitimate content
and require manual review. Neither report is a complete audit.

Turnstile requires valid site and secret keys from Cloudflare. When configured,
verification fails closed if the provider is unavailable, and the request IP
may be sent to Cloudflare for verification. SMS OTP is deferred.
The security checks are advisory; the plugin does not automatically alter
server permissions or database settings.

== Changelog ==

= 0.3.2 =
* Renamed the plugin and admin dashboard to Security Guard.
= 0.3.1 =
* Redesigned the admin page as a responsive security dashboard.
= 0.3.0 =
* Added optional TOTP two-factor authentication and recovery codes.
* Added email OTP fallback, Turnstile support, and registration spam controls.
* Added heuristic request firewall, temporary IP blocking, and event records.
* Added scheduled database + file backups with private storage and retention.
* Added advisory stored-content scanning and file-permission recommendations.
* Retained inactivity logout, password rules, and failed-login rate limiting.
